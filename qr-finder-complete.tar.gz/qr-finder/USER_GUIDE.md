# Guida Utente QR Finder

## Indice
1. [Registrazione](#registrazione)
2. [Aggiungere un Oggetto](#aggiungere-un-oggetto)
3. [Acquistare un'Etichetta](#acquistare-unetichetta)
4. [Tracciare un Oggetto](#tracciare-un-oggetto)
5. [Ricevere Notifiche](#ricevere-notifiche)
6. [Visualizzare la Mappa](#visualizzare-la-mappa)
7. [FAQ](#faq)

---

## Registrazione

1. Vai su [qr-finder.com](https://qr-finder.com)
2. Clicca su "Registrati" in alto a destra
3. Compila il form con:
   - Nome e cognome
   - Email valida
   - Password (minimo 8 caratteri)
   - Numero di telefono (opzionale)
4. Accetta i termini di servizio
5. Clicca su "Registrati"
6. Controlla la tua email e clicca sul link di verifica

---

## Aggiungere un Oggetto

1. Accedi alla tua dashboard
2. Clicca su "+ Aggiungi Oggetto"
3. Inserisci:
   - **Nome**: Es. "Chiavi di casa"
   - **Categoria**: Seleziona la categoria appropriata
   - **Descrizione**: (Opzionale) Aggiungi dettagli utili
4. Clicca su "Genera QR Code"
5. Il QR code verrà generato automaticamente

---

## Acquistare un'Etichetta

1. Dalla dashboard, clicca su "Acquista" sull'oggetto desiderato
2. Inserisci i dati della carta di credito
3. Clicca su "Paga Ora" (€5.00)
4. Dopo il pagamento, potrai scaricare il QR code
5. Stampa l'etichetta e attaccala all'oggetto

### Consigli per la Stampa
- Usa carta adesiva resistente all'acqua
- Stampa a 300 DPI per una migliore qualità
- Proteggi l'etichetta con nastro trasparente

---

## Tracciare un Oggetto

Quando qualcuno trova il tuo oggetto:

1. Scannerizza il QR code con qualsiasi smartphone
2. Verrà reindirizzato alla pagina di QR Finder
3. Può:
   - **Condividere la posizione**: Cliccando su "Condividi la tua posizione"
   - **Contattarti**: Compilando il form con il suo messaggio

Tu riceverai:
- Una notifica email immediata
- Una notifica sulla dashboard
- La posizione esatta sulla mappa (se condivisa)

---

## Ricevere Notifiche

### Notifiche Email
Riceverai un'email quando:
- Qualcuno scannerizza il tuo QR code
- Qualcuno ti contatta tramite il form
- Completi un acquisto

### Notifiche sul Sito
1. Clicca sulla campanella 🔔 in alto a destra
2. Visualizza tutte le notifiche
3. Clicca su una notifica per leggerla
4. Clicca su "Segna tutte come lette" per pulire

---

## Visualizzare la Mappa

### Mappa Generale
1. Dalla dashboard, scorri fino alla sezione "Mappa Oggetti"
2. Visualizza tutti i tuoi oggetti tracciati
3. Clicca su un marker per vedere i dettagli

### Mappa di un Singolo Oggetto
1. Dalla dashboard, clicca su "Mappa" sull'oggetto
2. Oppure vai su "Dettaglio Oggetto" → "Mappa"
3. Visualizza la cronologia completa delle posizioni
4. Ogni punto rappresenta una scansione del QR code

---

## FAQ

### D: Quanto costa il servizio?
**R**: La registrazione e l'uso base sono gratuiti. Le etichette fisiche costano €5.00 ciascuna.

### D: Posso usare QR Finder senza acquistare etichette?
**R**: Sì, puoi generare QR code digitali gratuitamente, ma non potrai scaricarli o stamparli.

### D: Quanti oggetti posso registrare?
**R**: Con l'account gratuito fino a 3 oggetti. Con le etichette acquistate, oggetti illimitati.

### D: I miei dati sono sicuri?
**R**: Sì, usiamo crittografia per le password e non condividiamo i tuoi dati personali con i trovanti.

### D: Cosa vedono i trovanti quando scannerizzano il QR?
**R**: Vedono solo il nome dell'oggetto e la categoria, non i tuoi dati personali.

### D: Posso modificare un oggetto dopo averlo creato?
**R**: Sì, vai sulla dashboard, clicca sull'oggetto e modifica i dettagli.

### D: Cosa succede se cancello un oggetto?
**R**: L'oggetto viene disattivato e il QR code non funzionerà più.

### D: Posso avere un rimborso?
**R**: Contatta il supporto entro 14 giorni dall'acquisto per valutare il rimborso.

### D: Il QR code scade?
**R**: No, i QR code non hanno scadenza. Rimangono attivi finché non cancelli l'oggetto.

### D: Posso usare QR Finder per il mio animale domestico?
**R**: Sì, seleziona la categoria "Animale" quando crei l'oggetto.

---

## Supporto

Hai bisogno di aiuto? Contattaci:
- Email: support@qr-finder.com
- Orari: Lun-Ven 9:00-18:00

---

## Suggerimenti per l'Uso

### Oggetti Consigliati
- Chiavi (casa, auto, ufficio)
- Smartphone e tablet
- Biciclette e monopattini
- Portafogli e borse
- Laptop e zaini
- Animali domestici (collare)
- Valigie e bagagli
- Attrezzature sportive

### Posizionamento delle Etichette
- Posiziona l'etichetta in un punto visibile
- Evita superfici curve che possono distorcere il QR
- Proteggi l'etichetta dall'acqua e dal sole
- Per biciclette, usa un portachiavi QR resistente

---

*Ultimo aggiornamento: Febbraio 2024*
