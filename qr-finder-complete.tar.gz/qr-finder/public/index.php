<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use QrFinder\Router;
use QrFinder\Utils\Database;
use QrFinder\Services\QrCodeService;
use QrFinder\Services\EmailService;
use QrFinder\Services\StripeService;
use QrFinder\Services\NotificationService;
use QrFinder\Controllers\AuthController;
use QrFinder\Controllers\ObjectController;
use QrFinder\Controllers\TrackingController;
use QrFinder\Controllers\NotificationController;
use QrFinder\Controllers\PaymentController;
use QrFinder\Controllers\AdminController;
use QrFinder\Middleware\AdminMiddleware;

// Load configuration
$config = require __DIR__ . '/../config/config.php';

// Initialize database
$db = new Database($config['database']);

// Initialize services
$qrCodeService = new QrCodeService(
    $config['app']['url'],
    $config['qr']['size'],
    $config['qr']['margin']
);

$emailService = new EmailService($config['mail']);
$stripeService = new StripeService($config['stripe']);
$notificationService = new NotificationService($emailService, $db, $config);

// Initialize router
$router = new Router();

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Auth routes
$router->post('/api/auth/register', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->register();
});

$router->post('/api/auth/login', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->login();
});

$router->post('/api/auth/logout', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->logout();
});

$router->get('/api/auth/me', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->getCurrentUser();
});

$router->put('/api/auth/profile', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->updateProfile();
});

$router->get('/api/auth/verify-email', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->verifyEmail();
});

$router->post('/api/auth/forgot-password', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->forgotPassword();
});

$router->post('/api/auth/reset-password', function() use ($db, $notificationService, $config) {
    $controller = new AuthController($db, $notificationService, $config);
    $controller->resetPassword();
});

// Object routes
$router->get('/api/objects', function() use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->index();
});

$router->post('/api/objects', function() use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->create();
});

$router->get('/api/objects/{id}', function($id) use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->show((int)$id);
});

$router->put('/api/objects/{id}', function($id) use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->update((int)$id);
});

$router->delete('/api/objects/{id}', function($id) use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->delete((int)$id);
});

$router->post('/api/objects/{id}/payment-intent', function($id) use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->createPaymentIntent((int)$id);
});

$router->get('/api/objects/{id}/download', function($id) use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->downloadQrCode((int)$id);
});

$router->get('/api/objects/{id}/map', function($id) use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->getMapData((int)$id);
});

$router->get('/api/objects/locations/all', function() use ($db, $qrCodeService, $stripeService, $notificationService, $config) {
    $controller = new ObjectController($db, $qrCodeService, $stripeService, $notificationService, $config);
    $controller->getLocations();
});

// Notification routes
$router->get('/api/notifications', function() use ($db, $notificationService) {
    $controller = new NotificationController($db, $notificationService);
    $controller->index();
});

$router->get('/api/notifications/all', function() use ($db, $notificationService) {
    $controller = new NotificationController($db, $notificationService);
    $controller->getAll();
});

$router->get('/api/notifications/unread-count', function() use ($db, $notificationService) {
    $controller = new NotificationController($db, $notificationService);
    $controller->getUnreadCount();
});

$router->post('/api/notifications/{id}/read', function($id) use ($db, $notificationService) {
    $controller = new NotificationController($db, $notificationService);
    $controller->markAsRead((int)$id);
});

$router->post('/api/notifications/read-all', function() use ($db, $notificationService) {
    $controller = new NotificationController($db, $notificationService);
    $controller->markAllAsRead();
});

$router->delete('/api/notifications/{id}', function($id) use ($db, $notificationService) {
    $controller = new NotificationController($db, $notificationService);
    $controller->delete((int)$id);
});

// Payment routes
$router->post('/api/webhooks/stripe', function() use ($db, $stripeService, $notificationService) {
    $controller = new PaymentController($db, $stripeService, $notificationService);
    $controller->handleWebhook();
});

$router->get('/api/payments/history', function() use ($db, $stripeService, $notificationService) {
    $controller = new PaymentController($db, $stripeService, $notificationService);
    $controller->getPaymentHistory();
});

$router->get('/api/payments/{paymentIntentId}/status', function($paymentIntentId) use ($db, $stripeService, $notificationService) {
    $controller = new PaymentController($db, $stripeService, $notificationService);
    $controller->getPaymentStatus($paymentIntentId);
});

$router->post('/api/payments/{id}/refund', function($id) use ($db, $stripeService, $notificationService) {
    $controller = new PaymentController($db, $stripeService, $notificationService);
    $controller->createRefund((int)$id);
});

// Public tracking routes
$router->get('/r/{shortCode}', function($shortCode) use ($db, $notificationService) {
    $controller = new TrackingController($db, $notificationService);
    $controller->showTrackingPage($shortCode);
});

$router->post('/r/{shortCode}', function($shortCode) use ($db, $notificationService) {
    $controller = new TrackingController($db, $notificationService);
    $controller->track($shortCode);
});

$router->post('/r/{shortCode}/contact', function($shortCode) use ($db, $notificationService) {
    $controller = new TrackingController($db, $notificationService);
    $controller->submitContactForm($shortCode);
});

// Static file serving for QR codes
$router->get('/storage/qr_codes/{filename}', function($filename) {
    $filePath = __DIR__ . '/../storage/qr_codes/' . basename($filename);
    if (file_exists($filePath)) {
        header('Content-Type: image/png');
        readfile($filePath);
    } else {
        http_response_code(404);
        echo 'File not found';
    }
});

// Serve frontend
$router->get('/', function() {
    include __DIR__ . '/../templates/index.php';
});

$router->get('/login', function() {
    include __DIR__ . '/../templates/login.php';
});

$router->get('/register', function() {
    include __DIR__ . '/../templates/register.php';
});

$router->get('/dashboard', function() {
    include __DIR__ . '/../templates/dashboard.php';
});

$router->get('/dashboard/objects/{id}', function($id) {
    $_GET['object_id'] = $id;
    include __DIR__ . '/../templates/object_detail.php';
});

$router->get('/verify-email', function() {
    include __DIR__ . '/../templates/verify_email.php';
});

$router->get('/reset-password', function() {
    include __DIR__ . '/../templates/reset_password.php';
});

// Admin routes
$router->get('/admin', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->dashboard();
});

$router->get('/admin/users', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->users();
});

$router->get('/admin/qrcodes', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->qrCodes();
});

$router->get('/admin/pages', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->pages();
});

$router->get('/admin/newsletter', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->newsletter();
});

$router->get('/admin/messages', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->messages();
});

$router->get('/admin/seo', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->seo();
});

$router->get('/admin/branding', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->branding();
});

$router->get('/admin/smtp', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->smtp();
});

$router->get('/admin/profile', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->profile();
});

// Admin API routes
$router->get('/api/admin/statistics', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getStatistics();
});

$router->get('/api/admin/users', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getUsers();
});

$router->get('/api/admin/users/{id}', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getUser((int)$id);
});

$router->put('/api/admin/users/{id}', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updateUser((int)$id);
});

$router->delete('/api/admin/users/{id}', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->deleteUser((int)$id);
});

$router->get('/api/admin/qrcodes', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getQrCodes();
});

$router->get('/api/admin/qrcodes/{id}/preview', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getQrCodePreview((int)$id);
});

$router->get('/api/admin/seo', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getSeoSettings();
});

$router->put('/api/admin/seo', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updateSeo();
});

$router->put('/api/admin/branding', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updateBranding();
});

$router->post('/api/admin/branding/upload-logo', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->uploadLogo();
});

$router->put('/api/admin/smtp', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updateSmtp();
});

$router->post('/api/admin/smtp/test', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->testSmtp();
});

$router->get('/api/admin/newsletter/subscribers', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getNewsletterSubscribers();
});

$router->post('/api/admin/newsletter/send', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->sendNewsletter();
});

$router->get('/api/admin/pages', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getPages();
});

$router->get('/api/admin/pages/{id}', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getPage((int)$id);
});

$router->post('/api/admin/pages', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->createPage();
});

$router->put('/api/admin/pages/{id}', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updatePage((int)$id);
});

$router->delete('/api/admin/pages/{id}', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->deletePage((int)$id);
});

$router->get('/api/admin/messages', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->getMessages();
});

$router->post('/api/admin/messages/{id}/read', function($id) use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->markMessageRead((int)$id);
});

$router->put('/api/admin/profile', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updateProfile();
});

$router->post('/api/admin/profile/verification-code', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->sendVerificationCode();
});

$router->put('/api/admin/profile/password', function() use ($db, $config) {
    $controller = new AdminController($db, $config);
    $controller->updatePassword();
});

// Static pages
$router->get('/page/{slug}', function($slug) use ($db) {
    $sql = "SELECT * FROM pages WHERE slug = :slug AND is_published = TRUE";
    $page = $db->queryOne($sql, [':slug' => $slug]);
    
    if ($page) {
        include __DIR__ . '/../templates/page.php';
    } else {
        http_response_code(404);
        echo 'Pagina non trovata';
    }
});

// Dispatch the request
$router->dispatch();
