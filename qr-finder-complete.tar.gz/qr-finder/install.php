<?php
/**
 * QR Finder - Installation Script
 * 
 * This script helps with the initial setup of QR Finder.
 * Run this script from the command line: php install.php
 */

if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.\n");
}

echo "================================\n";
echo "  QR Finder - Installation\n";
echo "================================\n\n";

// Check PHP version
if (PHP_VERSION_ID < 80100) {
    die("Error: PHP 8.1 or higher is required. You have " . PHP_VERSION . "\n");
}
echo "✓ PHP version check passed (" . PHP_VERSION . ")\n";

// Check required extensions
$requiredExtensions = ['pdo', 'pdo_mysql', 'gd', 'mbstring', 'openssl', 'json'];
$missingExtensions = [];

foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) {
        $missingExtensions[] = $ext;
    }
}

if (!empty($missingExtensions)) {
    die("Error: Missing required PHP extensions: " . implode(', ', $missingExtensions) . "\n");
}
echo "✓ Required PHP extensions are installed\n";

// Check if Composer is installed
$composerInstalled = shell_exec('which composer') !== null;
if (!$composerInstalled) {
    echo "⚠ Warning: Composer not found in PATH. You'll need to install dependencies manually.\n";
} else {
    echo "✓ Composer is installed\n";
}

// Check if .env file exists
if (file_exists('.env')) {
    echo "⚠ .env file already exists. Skipping creation.\n";
} else {
    echo "\n--- Database Configuration ---\n";
    $dbHost = readline("Database host [localhost]: ") ?: 'localhost';
    $dbName = readline("Database name [qrfinder]: ") ?: 'qrfinder';
    $dbUser = readline("Database user [root]: ") ?: 'root';
    $dbPass = readline("Database password: ");
    
    echo "\n--- Application Configuration ---\n";
    $appUrl = readline("Application URL [https://qr-finder.com]: ") ?: 'https://qr-finder.com';
    
    echo "\n--- JWT Configuration ---\n";
    $jwtSecret = bin2hex(random_bytes(32));
    echo "Generated JWT secret: $jwtSecret\n";
    
    echo "\n--- Stripe Configuration ---\n";
    $stripePk = readline("Stripe Publishable Key: ");
    $stripeSk = readline("Stripe Secret Key: ");
    $stripeWs = readline("Stripe Webhook Secret: ");
    
    echo "\n--- Email Configuration ---\n";
    $mailHost = readline("SMTP Host [smtp.gmail.com]: ") ?: 'smtp.gmail.com';
    $mailPort = readline("SMTP Port [587]: ") ?: '587';
    $mailUser = readline("SMTP Username: ");
    $mailPass = readline("SMTP Password: ");
    
    // Create .env file
    $envContent = <<<ENV
# Database Configuration
DB_HOST={$dbHost}
DB_NAME={$dbName}
DB_USER={$dbUser}
DB_PASS={$dbPass}
DB_CHARSET=utf8mb4

# Application Configuration
APP_ENV=production
APP_DEBUG=false
APP_URL={$appUrl}
APP_NAME="QR Finder"

# JWT Configuration
JWT_SECRET={$jwtSecret}
JWT_EXPIRE=86400

# Stripe Configuration
STRIPE_PUBLISHABLE_KEY={$stripePk}
STRIPE_SECRET_KEY={$stripeSk}
STRIPE_WEBHOOK_SECRET={$stripeWs}

# Email Configuration (SMTP)
MAIL_HOST={$mailHost}
MAIL_PORT={$mailPort}
MAIL_USERNAME={$mailUser}
MAIL_PASSWORD={$mailPass}
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@qr-finder.com
MAIL_FROM_NAME="QR Finder"

# QR Code Configuration
QR_CODE_SIZE=300
QR_CODE_MARGIN=10

# Pricing
LABEL_PRICE_CENTS=500
CURRENCY=eur
ENV;
    
    file_put_contents('.env', $envContent);
    echo "\n✓ .env file created successfully\n";
}

// Create storage directories
$directories = [
    'storage/qr_codes',
    'storage/logs'
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        echo "✓ Created directory: $dir\n";
    }
}

// Check database connection
echo "\n--- Database Setup ---\n";

if (file_exists('.env')) {
    $env = parse_ini_file('.env');
    
    try {
        $pdo = new PDO(
            "mysql:host={$env['DB_HOST']};charset=utf8mb4",
            $env['DB_USER'],
            $env['DB_PASS'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        echo "✓ Database connection successful\n";
        
        // Create database if not exists
        $pdo->exec("CREATE DATABASE IF NOT EXISTS {$env['DB_NAME']} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "✓ Database '{$env['DB_NAME']}' created or already exists\n";
        
        // Import schema
        $pdo->exec("USE {$env['DB_NAME']}");
        $schema = file_get_contents('database/schema.sql');
        
        // Remove CREATE DATABASE statement since we already created it
        $schema = preg_replace('/CREATE DATABASE.*?;/s', '', $schema);
        $schema = preg_replace('/USE \w+;/', '', $schema);
        
        $pdo->exec($schema);
        echo "✓ Database schema imported successfully\n";
        
    } catch (PDOException $e) {
        echo "⚠ Database connection failed: " . $e->getMessage() . "\n";
        echo "  You'll need to manually create the database and import schema.sql\n";
    }
}

// Install Composer dependencies
if ($composerInstalled) {
    echo "\n--- Installing Composer Dependencies ---\n";
    echo "Running: composer install\n";
    passthru('composer install --no-dev --optimize-autoloader 2>&1', $returnCode);
    
    if ($returnCode === 0) {
        echo "✓ Dependencies installed successfully\n";
    } else {
        echo "⚠ Failed to install dependencies. Run 'composer install' manually.\n";
    }
}

echo "\n================================\n";
echo "  Installation Complete!\n";
echo "================================\n\n";

echo "Next steps:\n";
echo "1. Configure your web server to point to the 'public' directory\n";
echo "2. Set up Stripe webhook to: {$appUrl}/api/webhooks/stripe\n";
echo "3. Ensure 'storage' directory is writable by the web server\n";
echo "4. Access your application at: {$appUrl}\n\n";

echo "For more information, see README.md\n";
