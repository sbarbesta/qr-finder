<?php

declare(strict_types=1);

namespace QrFinder\Middleware;

use QrFinder\Models\User;
use QrFinder\Utils\Database;

class AdminMiddleware
{
    private Database $db;
    private User $userModel;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->userModel = new User($db);
    }

    public function handle(): bool
    {
        $user = $this->getCurrentUser();
        
        if (!$user || !$user['is_admin']) {
            if ($this->isApiRequest()) {
                http_response_code(403);
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => 'Accesso negato. Richiesti privilegi amministratore.']);
                return false;
            } else {
                header('Location: /login');
                exit;
            }
        }
        
        return true;
    }

    public function handleApi(): bool
    {
        $user = $this->getCurrentUser();
        
        if (!$user || !$user['is_admin']) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Accesso negato. Richiesti privilegi amministratore.']);
            return false;
        }
        
        return true;
    }

    private function getCurrentUser(): ?array
    {
        // Check Authorization header
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);
        
        // Check session
        if (!$token && isset($_SESSION['admin_token'])) {
            $token = $_SESSION['admin_token'];
        }
        
        // Check cookie
        if (!$token && isset($_COOKIE['admin_token'])) {
            $token = $_COOKIE['admin_token'];
        }
        
        if (!$token) {
            return null;
        }
        
        $session = $this->userModel->validateSession($token);
        
        if (!$session) {
            return null;
        }
        
        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name'],
            'is_admin' => $session['is_admin'] ?? false
        ];
    }

    private function isApiRequest(): bool
    {
        return strpos($_SERVER['REQUEST_URI'], '/api/') === 0 ||
               (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) ||
               (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest');
    }
}
