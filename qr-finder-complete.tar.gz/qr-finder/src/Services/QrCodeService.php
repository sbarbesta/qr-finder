<?php

declare(strict_types=1);

namespace QrFinder\Services;

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\ErrorCorrectionLevel;

class QrCodeService
{
    private string $baseUrl;
    private int $size;
    private int $margin;
    private string $storagePath;

    public function __construct(string $baseUrl, int $size = 300, int $margin = 10)
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->size = $size;
        $this->margin = $margin;
        $this->storagePath = __DIR__ . '/../../storage/qr_codes/';
        
        if (!is_dir($this->storagePath)) {
            mkdir($this->storagePath, 0755, true);
        }
    }

    public function generate(string $shortCode, ?string $customPath = null): array
    {
        $shortUrl = $this->baseUrl . '/r/' . $shortCode;
        $filename = $customPath ?? $shortCode . '.png';
        $fullPath = $this->storagePath . $filename;

        $qrCode = new QrCode($shortUrl);
        $qrCode->setSize($this->size);
        $qrCode->setMargin($this->margin);
        $qrCode->setErrorCorrectionLevel(ErrorCorrectionLevel::High);
        $qrCode->setForegroundColor(new Color(0, 0, 0));
        $qrCode->setBackgroundColor(new Color(255, 255, 255));

        $writer = new PngWriter();
        $result = $writer->write($qrCode);

        // Save the QR code
        file_put_contents($fullPath, $result->getString());

        return [
            'path' => $fullPath,
            'url' => $shortUrl,
            'filename' => $filename,
            'dataUri' => $result->getDataUri()
        ];
    }

    public function generateWithLabel(string $shortCode, string $objectName, string $category = 'other'): array
    {
        $qrResult = $this->generate($shortCode);
        
        // Create a labeled version with text
        $labeledFilename = $shortCode . '_labeled.png';
        $labeledPath = $this->storagePath . $labeledFilename;
        
        $this->createLabeledQrCode($qrResult['path'], $labeledPath, $objectName, $category);
        
        return [
            'path' => $labeledPath,
            'filename' => $labeledFilename,
            'original' => $qrResult
        ];
    }

    private function createLabeledQrCode(string $qrPath, string $outputPath, string $objectName, string $category): void
    {
        // Load QR code image
        $qrImage = imagecreatefrompng($qrPath);
        $qrWidth = imagesx($qrImage);
        $qrHeight = imagesy($qrImage);

        // Create new image with space for text
        $labelHeight = 80;
        $newHeight = $qrHeight + $labelHeight;
        $newImage = imagecreatetruecolor($qrWidth, $newHeight);

        // Colors
        $white = imagecolorallocate($newImage, 255, 255, 255);
        $black = imagecolorallocate($newImage, 0, 0, 0);
        $blue = imagecolorallocate($newImage, 37, 99, 235);

        // Fill background
        imagefilledrectangle($newImage, 0, 0, $qrWidth, $newHeight, $white);

        // Copy QR code
        imagecopy($newImage, $qrImage, 0, 0, 0, 0, $qrWidth, $qrHeight);

        // Add text
        $font = 5; // Built-in font
        $text = 'QR-Finder.com';
        $textWidth = imagefontwidth($font) * strlen($text);
        $textX = ($qrWidth - $textWidth) / 2;
        imagestring($newImage, $font, (int)$textX, $qrHeight + 10, $text, $blue);

        // Add object name
        $objectText = substr($objectName, 0, 30);
        $objectWidth = imagefontwidth($font) * strlen($objectText);
        $objectX = ($qrWidth - $objectWidth) / 2;
        imagestring($newImage, $font, (int)$objectX, $qrHeight + 30, $objectText, $black);

        // Add category
        $categoryText = ucfirst($category);
        $catWidth = imagefontwidth($font) * strlen($categoryText);
        $catX = ($qrWidth - $catWidth) / 2;
        imagestring($newImage, $font, (int)$catX, $qrHeight + 50, $categoryText, $black);

        // Save image
        imagepng($newImage, $outputPath);

        // Clean up
        imagedestroy($qrImage);
        imagedestroy($newImage);
    }

    public function getQrCodePath(string $filename): string
    {
        return $this->storagePath . $filename;
    }

    public function getQrCodeUrl(string $filename): string
    {
        return $this->baseUrl . '/storage/qr_codes/' . $filename;
    }

    public function deleteQrCode(string $filename): bool
    {
        $path = $this->storagePath . $filename;
        if (file_exists($path)) {
            return unlink($path);
        }
        return false;
    }

    public function generatePrintablePdf(array $objects): string
    {
        // This would generate a PDF with multiple QR codes for printing
        // For now, return a placeholder
        return $this->storagePath . 'printable.pdf';
    }
}
