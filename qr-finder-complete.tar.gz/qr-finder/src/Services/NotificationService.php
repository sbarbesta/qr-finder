<?php

declare(strict_types=1);

namespace QrFinder\Services;

use QrFinder\Models\Notification;
use QrFinder\Models\QrScan;
use QrFinder\Utils\Database;

class NotificationService
{
    private EmailService $emailService;
    private Notification $notificationModel;
    private QrScan $qrScanModel;
    private array $config;

    public function __construct(
        EmailService $emailService,
        Database $db,
        array $config
    ) {
        $this->emailService = $emailService;
        $this->notificationModel = new Notification($db);
        $this->qrScanModel = new QrScan($db);
        $this->config = $config;
    }

    public function notifyObjectFound(array $object, array $scanData): bool
    {
        $userId = $object['user_id'];
        $objectId = $object['id'];
        $scanId = $scanData['id'];

        // Format location string
        $location = 'Posizione sconosciuta';
        if (!empty($scanData['latitude']) && !empty($scanData['longitude'])) {
            $location = sprintf('%.4f, %.4f', $scanData['latitude'], $scanData['longitude']);
        }

        // Create in-app notification
        $notificationId = $this->notificationModel->createObjectFoundNotification(
            $userId,
            $objectId,
            $scanId,
            array_merge($scanData, ['object_name' => $object['name']])
        );

        // Send email notification
        $emailSent = $this->emailService->sendTemplate(
            $object['user_email'],
            'object_found',
            [
                'first_name' => $object['first_name'],
                'object_name' => $object['name'],
                'scanned_at' => date('d/m/Y H:i', strtotime($scanData['scanned_at'])),
                'location' => $location,
                'map_url' => $this->config['app_url'] . '/dashboard/objects/' . $objectId . '/map'
            ]
        );

        // Mark scan as notification sent
        if ($emailSent) {
            $this->qrScanModel->markNotificationSent($scanId);
        }

        return $emailSent;
    }

    public function sendWelcomeEmail(array $user): bool
    {
        return $this->emailService->sendTemplate(
            $user['email'],
            'welcome',
            [
                'first_name' => $user['first_name'],
                'dashboard_url' => $this->config['app_url'] . '/dashboard'
            ]
        );
    }

    public function sendVerificationEmail(array $user, string $token): bool
    {
        $verificationUrl = $this->config['app_url'] . '/verify-email?token=' . $token;

        return $this->emailService->sendTemplate(
            $user['email'],
            'verification',
            [
                'first_name' => $user['first_name'],
                'verification_url' => $verificationUrl
            ]
        );
    }

    public function sendPasswordResetEmail(array $user, string $token): bool
    {
        $resetUrl = $this->config['app_url'] . '/reset-password?token=' . $token;

        return $this->emailService->sendTemplate(
            $user['email'],
            'password_reset',
            [
                'first_name' => $user['first_name'],
                'reset_url' => $resetUrl
            ]
        );
    }

    public function sendLabelPurchasedEmail(array $user, array $object): bool
    {
        return $this->emailService->sendTemplate(
            $user['email'],
            'label_purchased',
            [
                'first_name' => $user['first_name'],
                'object_name' => $object['name'],
                'download_url' => $this->config['app_url'] . '/dashboard/objects/' . $object['id'] . '/download'
            ]
        );
    }

    public function processPendingNotifications(): int
    {
        $pendingScans = $this->qrScanModel->getScansNeedingNotification(0);
        $processed = 0;

        foreach ($pendingScans as $scan) {
            // Get object details
            $objectModel = new \QrFinder\Models\Object($this->notificationModel->db);
            $object = $objectModel->findById($scan['object_id']);

            if ($object) {
                if ($this->notifyObjectFound($object, $scan)) {
                    $processed++;
                }
            }
        }

        return $processed;
    }

    public function getUnreadNotifications(int $userId): array
    {
        return $this->notificationModel->findByUserId($userId, true);
    }

    public function getUnreadCount(int $userId): int
    {
        return $this->notificationModel->getUnreadCount($userId);
    }

    public function markAsRead(int $notificationId, int $userId): bool
    {
        return $this->notificationModel->markAsRead($notificationId, $userId);
    }

    public function markAllAsRead(int $userId): int
    {
        return $this->notificationModel->markAllAsRead($userId);
    }
}
