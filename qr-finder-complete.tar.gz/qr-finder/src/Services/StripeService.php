<?php

declare(strict_types=1);

namespace QrFinder\Services;

use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\Customer;
use Stripe\Webhook;
use Stripe\Exception\ApiErrorException;

class StripeService
{
    private string $secretKey;
    private string $webhookSecret;
    private string $publishableKey;

    public function __construct(array $config)
    {
        $this->secretKey = $config['secret_key'];
        $this->webhookSecret = $config['webhook_secret'];
        $this->publishableKey = $config['publishable_key'];
        Stripe::setApiKey($this->secretKey);
    }

    public function getPublishableKey(): string
    {
        return $this->publishableKey;
    }

    public function createPaymentIntent(int $amountCents, string $currency = 'eur', array $metadata = []): array
    {
        try {
            $paymentIntent = PaymentIntent::create([
                'amount' => $amountCents,
                'currency' => $currency,
                'automatic_payment_methods' => [
                    'enabled' => true,
                ],
                'metadata' => $metadata,
            ]);

            return [
                'success' => true,
                'client_secret' => $paymentIntent->client_secret,
                'payment_intent_id' => $paymentIntent->id,
            ];
        } catch (ApiErrorException $e) {
            error_log("Stripe PaymentIntent creation failed: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    public function retrievePaymentIntent(string $paymentIntentId): ?PaymentIntent
    {
        try {
            return PaymentIntent::retrieve($paymentIntentId);
        } catch (ApiErrorException $e) {
            error_log("Stripe PaymentIntent retrieval failed: " . $e->getMessage());
            return null;
        }
    }

    public function createCustomer(string $email, string $name = null): array
    {
        try {
            $customer = Customer::create([
                'email' => $email,
                'name' => $name,
            ]);

            return [
                'success' => true,
                'customer_id' => $customer->id,
            ];
        } catch (ApiErrorException $e) {
            error_log("Stripe Customer creation failed: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }

    public function constructEvent(string $payload, string $sigHeader): ?\Stripe\Event
    {
        try {
            return Webhook::constructEvent($payload, $sigHeader, $this->webhookSecret);
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            error_log("Stripe webhook signature verification failed: " . $e->getMessage());
            return null;
        } catch (\UnexpectedValueException $e) {
            error_log("Stripe webhook invalid payload: " . $e->getMessage());
            return null;
        }
    }

    public function handleWebhook(\Stripe\Event $event): array
    {
        $result = ['handled' => false, 'type' => $event->type];

        switch ($event->type) {
            case 'payment_intent.succeeded':
                $paymentIntent = $event->data->object;
                $result['payment_intent_id'] = $paymentIntent->id;
                $result['status'] = 'succeeded';
                $result['handled'] = true;
                break;

            case 'payment_intent.payment_failed':
                $paymentIntent = $event->data->object;
                $result['payment_intent_id'] = $paymentIntent->id;
                $result['status'] = 'failed';
                $result['error'] = $paymentIntent->last_payment_error->message ?? 'Unknown error';
                $result['handled'] = true;
                break;

            case 'charge.refunded':
                $charge = $event->data->object;
                $result['charge_id'] = $charge->id;
                $result['status'] = 'refunded';
                $result['handled'] = true;
                break;
        }

        return $result;
    }

    public function refund(string $paymentIntentId): array
    {
        try {
            $refund = \Stripe\Refund::create([
                'payment_intent' => $paymentIntentId,
            ]);

            return [
                'success' => true,
                'refund_id' => $refund->id,
                'status' => $refund->status,
            ];
        } catch (ApiErrorException $e) {
            error_log("Stripe refund failed: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
}
