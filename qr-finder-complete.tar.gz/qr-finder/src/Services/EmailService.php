<?php

declare(strict_types=1);

namespace QrFinder\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

class EmailService
{
    private array $config;
    private PHPMailer $mailer;

    public function __construct(array $config)
    {
        $this->config = $config;
        $this->mailer = new PHPMailer(true);
        $this->setupMailer();
    }

    private function setupMailer(): void
    {
        try {
            $this->mailer->isSMTP();
            $this->mailer->Host = $this->config['host'];
            $this->mailer->SMTPAuth = true;
            $this->mailer->Username = $this->config['username'];
            $this->mailer->Password = $this->config['password'];
            $this->mailer->SMTPSecure = $this->config['encryption'] === 'tls' ? PHPMailer::ENCRYPTION_STARTTLS : PHPMailer::ENCRYPTION_SMTPS;
            $this->mailer->Port = $this->config['port'];
            $this->mailer->CharSet = 'UTF-8';
            $this->mailer->setFrom($this->config['from_address'], $this->config['from_name']);
        } catch (PHPMailerException $e) {
            error_log("Email setup failed: " . $e->getMessage());
        }
    }

    public function send(string $to, string $subject, string $body, bool $isHtml = true): bool
    {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->addAddress($to);
            $this->mailer->isHTML($isHtml);
            $this->mailer->Subject = $subject;
            $this->mailer->Body = $body;
            $this->mailer->AltBody = strip_tags($body);

            return $this->mailer->send();
        } catch (PHPMailerException $e) {
            error_log("Email sending failed: " . $e->getMessage());
            return false;
        }
    }

    public function sendTemplate(string $to, string $template, array $data = []): bool
    {
        $templates = $this->getTemplates();
        
        if (!isset($templates[$template])) {
            error_log("Email template not found: " . $template);
            return false;
        }

        $templateData = $templates[$template];
        $subject = $this->replacePlaceholders($templateData['subject'], $data);
        $body = $this->replacePlaceholders($templateData['body'], $data);

        return $this->send($to, $subject, $body, true);
    }

    private function getTemplates(): array
    {
        return [
            'verification' => [
                'subject' => 'Verifica il tuo account QR Finder',
                'body' => $this->getVerificationTemplate()
            ],
            'password_reset' => [
                'subject' => 'Reimposta la tua password QR Finder',
                'body' => $this->getPasswordResetTemplate()
            ],
            'object_found' => [
                'subject' => 'Il tuo oggetto è stato trovato!',
                'body' => $this->getObjectFoundTemplate()
            ],
            'welcome' => [
                'subject' => 'Benvenuto su QR Finder!',
                'body' => $this->getWelcomeTemplate()
            ],
            'label_purchased' => [
                'subject' => 'Le tue etichette QR sono pronte!',
                'body' => $this->getLabelPurchasedTemplate()
            ]
        ];
    }

    private function replacePlaceholders(string $template, array $data): string
    {
        foreach ($data as $key => $value) {
            $template = str_replace('{{' . $key . '}}', htmlspecialchars((string)$value), $template);
        }
        return $template;
    }

    private function getVerificationTemplate(): string
    {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
                .content { background: #f9fafb; padding: 20px; margin: 20px 0; }
                .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                .footer { text-align: center; color: #6b7280; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>QR Finder</h1>
                </div>
                <div class="content">
                    <h2>Ciao {{first_name}},</h2>
                    <p>Grazie per esserti registrato su QR Finder! Per completare la registrazione, verifica il tuo indirizzo email cliccando sul pulsante qui sotto:</p>
                    <p style="text-align: center;">
                        <a href="{{verification_url}}" class="button">Verifica Email</a>
                    </p>
                    <p>Oppure copia e incolla questo link nel tuo browser:</p>
                    <p>{{verification_url}}</p>
                </div>
                <div class="footer">
                    <p>Se non hai richiesto questa registrazione, ignora questa email.</p>
                    <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
                </div>
            </div>
        </body>
        </html>';
    }

    private function getPasswordResetTemplate(): string
    {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
                .content { background: #f9fafb; padding: 20px; margin: 20px 0; }
                .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                .footer { text-align: center; color: #6b7280; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>QR Finder</h1>
                </div>
                <div class="content">
                    <h2>Ciao {{first_name}},</h2>
                    <p>Hai richiesto di reimpostare la tua password. Clicca sul pulsante qui sotto per procedere:</p>
                    <p style="text-align: center;">
                        <a href="{{reset_url}}" class="button">Reimposta Password</a>
                    </p>
                    <p>Questo link scadrà tra 1 ora.</p>
                    <p>Se non hai richiesto questa operazione, ignora questa email.</p>
                </div>
                <div class="footer">
                    <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
                </div>
            </div>
        </body>
        </html>';
    }

    private function getObjectFoundTemplate(): string
    {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #10b981; color: white; padding: 20px; text-align: center; }
                .content { background: #f9fafb; padding: 20px; margin: 20px 0; }
                .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                .info-box { background: white; padding: 15px; margin: 10px 0; border-left: 4px solid #10b981; }
                .footer { text-align: center; color: #6b7280; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Oggetto Trovato!</h1>
                </div>
                <div class="content">
                    <h2>Buone notizie, {{first_name}}!</h2>
                    <p>Il tuo oggetto <strong>{{object_name}}</strong> è stato trovato!</p>
                    
                    <div class="info-box">
                        <h3>Dettagli del ritrovamento:</h3>
                        <p><strong>Data e ora:</strong> {{scanned_at}}</p>
                        <p><strong>Posizione:</strong> {{location}}</p>
                    </div>
                    
                    <p style="text-align: center;">
                        <a href="{{map_url}}" class="button">Vedi sulla Mappa</a>
                    </p>
                    
                    <p>Accedi al tuo account per vedere la posizione esatta e gestire il ritrovamento.</p>
                </div>
                <div class="footer">
                    <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
                </div>
            </div>
        </body>
        </html>';
    }

    private function getWelcomeTemplate(): string
    {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
                .content { background: #f9fafb; padding: 20px; margin: 20px 0; }
                .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                .footer { text-align: center; color: #6b7280; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Benvenuto su QR Finder!</h1>
                </div>
                <div class="content">
                    <h2>Ciao {{first_name}},</h2>
                    <p>Grazie per esserti registrato su QR Finder! Siamo felici di averti con noi.</p>
                    <p>Con QR Finder puoi:</p>
                    <ul>
                        <li>Registrare i tuoi oggetti personali</li>
                        <li>Generare QR code univoci</li>
                        <li>Tracciare la posizione dei tuoi oggetti se persi</li>
                        <li>Ricevere notifiche quando vengono trovati</li>
                    </ul>
                    <p style="text-align: center;">
                        <a href="{{dashboard_url}}" class="button">Vai alla Dashboard</a>
                    </p>
                </div>
                <div class="footer">
                    <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
                </div>
            </div>
        </body>
        </html>';
    }

    private function getLabelPurchasedTemplate(): string
    {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
                .content { background: #f9fafb; padding: 20px; margin: 20px 0; }
                .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                .footer { text-align: center; color: #6b7280; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Etichette Pronte!</h1>
                </div>
                <div class="content">
                    <h2>Ciao {{first_name}},</h2>
                    <p>Grazie per il tuo acquisto! Le etichette QR per <strong>{{object_name}}</strong> sono pronte per essere stampate.</p>
                    <p style="text-align: center;">
                        <a href="{{download_url}}" class="button">Scarica Etichette</a>
                    </p>
                    <p>Puoi anche accedere alla tua dashboard per gestire tutti i tuoi oggetti.</p>
                </div>
                <div class="footer">
                    <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
                </div>
            </div>
        </body>
        </html>';
    }
}
