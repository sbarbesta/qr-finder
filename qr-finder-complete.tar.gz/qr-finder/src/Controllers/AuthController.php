<?php

declare(strict_types=1);

namespace QrFinder\Controllers;

use QrFinder\Models\User;
use QrFinder\Services\NotificationService;
use QrFinder\Utils\Database;

class AuthController
{
    private User $userModel;
    private NotificationService $notificationService;
    private array $config;

    public function __construct(Database $db, NotificationService $notificationService, array $config)
    {
        $this->userModel = new User($db);
        $this->notificationService = $notificationService;
        $this->config = $config;
    }

    public function register(): void
    {
        header('Content-Type: application/json');

        try {
            $data = json_decode(file_get_contents('php://input'), true);

            if (!$data) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Dati non validi']);
                return;
            }

            // Validation
            $errors = $this->validateRegistrationData($data);
            if (!empty($errors)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'errors' => $errors]);
                return;
            }

            // Check if email exists
            if ($this->userModel->findByEmail($data['email'])) {
                http_response_code(409);
                echo json_encode(['success' => false, 'error' => 'Email già registrata']);
                return;
            }

            // Create user
            $userId = $this->userModel->create([
                'email' => $data['email'],
                'password' => $data['password'],
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'phone' => $data['phone'] ?? null
            ]);

            $user = $this->userModel->findById($userId);

            // Send verification email
            $userFull = $this->userModel->findByEmail($data['email']);
            $this->notificationService->sendVerificationEmail($userFull, $userFull['verification_token']);

            // Create session
            $sessionToken = $this->userModel->createSession(
                $userId,
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null
            );

            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'Registrazione completata. Controlla la tua email per verificare l\'account.',
                'data' => [
                    'user' => $user,
                    'session_token' => $sessionToken
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Registration error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante la registrazione']);
        }
    }

    public function login(): void
    {
        header('Content-Type: application/json');

        try {
            $data = json_decode(file_get_contents('php://input'), true);

            if (!$data || empty($data['email']) || empty($data['password'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Email e password richieste']);
                return;
            }

            $user = $this->userModel->validateCredentials($data['email'], $data['password']);

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Credenziali non valide']);
                return;
            }

            // Create session
            $sessionToken = $this->userModel->createSession(
                $user['id'],
                $_SERVER['REMOTE_ADDR'] ?? null,
                $_SERVER['HTTP_USER_AGENT'] ?? null
            );

            http_response_code(200);
            echo json_encode([
                'success' => true,
                'data' => [
                    'user' => $user,
                    'session_token' => $sessionToken
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Login error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante il login']);
        }
    }

    public function logout(): void
    {
        header('Content-Type: application/json');

        try {
            $headers = getallheaders();
            $token = $headers['Authorization'] ?? '';
            $token = str_replace('Bearer ', '', $token);

            if ($token) {
                $this->userModel->deleteSession($token);
            }

            echo json_encode(['success' => true, 'message' => 'Logout effettuato']);

        } catch (\Exception $e) {
            error_log("Logout error: " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Errore durante il logout']);
        }
    }

    public function verifyEmail(): void
    {
        header('Content-Type: application/json');

        try {
            $token = $_GET['token'] ?? '';

            if (!$token) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Token mancante']);
                return;
            }

            $user = $this->userModel->findByVerificationToken($token);

            if (!$user) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Token non valido']);
                return;
            }

            $this->userModel->verifyEmail($user['id']);

            // Send welcome email
            $this->notificationService->sendWelcomeEmail($user);

            echo json_encode([
                'success' => true,
                'message' => 'Email verificata con successo!'
            ]);

        } catch (\Exception $e) {
            error_log("Email verification error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante la verifica']);
        }
    }

    public function forgotPassword(): void
    {
        header('Content-Type: application/json');

        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $email = $data['email'] ?? '';

            if (!$email) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Email richiesta']);
                return;
            }

            $user = $this->userModel->findByEmail($email);

            if ($user) {
                $token = bin2hex(random_bytes(32));
                $this->userModel->setResetToken($user['id'], $token);
                $this->notificationService->sendPasswordResetEmail($user, $token);
            }

            // Always return success to prevent email enumeration
            echo json_encode([
                'success' => true,
                'message' => 'Se l\'email è registrata, riceverai le istruzioni per reimpostare la password.'
            ]);

        } catch (\Exception $e) {
            error_log("Forgot password error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante la richiesta']);
        }
    }

    public function resetPassword(): void
    {
        header('Content-Type: application/json');

        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $token = $data['token'] ?? '';
            $password = $data['password'] ?? '';

            if (!$token || !$password) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Token e password richiesti']);
                return;
            }

            if (strlen($password) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'La password deve essere di almeno 8 caratteri']);
                return;
            }

            $user = $this->userModel->findByResetToken($token);

            if (!$user) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Token non valido o scaduto']);
                return;
            }

            $this->userModel->updatePassword($user['id'], $password);

            echo json_encode([
                'success' => true,
                'message' => 'Password reimpostata con successo!'
            ]);

        } catch (\Exception $e) {
            error_log("Reset password error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante il reset della password']);
        }
    }

    public function getCurrentUser(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            echo json_encode([
                'success' => true,
                'data' => $user
            ]);

        } catch (\Exception $e) {
            error_log("Get current user error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function updateProfile(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $data = json_decode(file_get_contents('php://input'), true);

            $allowedFields = ['first_name', 'last_name', 'phone'];
            $updateData = array_intersect_key($data, array_flip($allowedFields));

            if (empty($updateData)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Nessun dato da aggiornare']);
                return;
            }

            $this->userModel->update($user['id'], $updateData);
            $updatedUser = $this->userModel->findById($user['id']);

            echo json_encode([
                'success' => true,
                'data' => $updatedUser
            ]);

        } catch (\Exception $e) {
            error_log("Update profile error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'aggiornamento']);
        }
    }

    private function validateRegistrationData(array $data): array
    {
        $errors = [];

        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email non valida';
        }

        if (empty($data['password']) || strlen($data['password']) < 8) {
            $errors['password'] = 'La password deve essere di almeno 8 caratteri';
        }

        if (empty($data['first_name'])) {
            $errors['first_name'] = 'Nome richiesto';
        }

        if (empty($data['last_name'])) {
            $errors['last_name'] = 'Cognome richiesto';
        }

        return $errors;
    }

    private function getAuthenticatedUser(): ?array
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);

        if (!$token) {
            return null;
        }

        $session = $this->userModel->validateSession($token);

        if (!$session) {
            return null;
        }

        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name'],
            'email_verified' => $session['email_verified']
        ];
    }
}
