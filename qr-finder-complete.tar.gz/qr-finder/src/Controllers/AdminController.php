<?php

declare(strict_types=1);

namespace QrFinder\Controllers;

use QrFinder\Models\User;
use QrFinder\Models\Object;
use QrFinder\Models\QrScan;
use QrFinder\Models\Payment;
use QrFinder\Services\EmailService;
use QrFinder\Services\QrCodeService;
use QrFinder\Utils\Database;

class AdminController
{
    private Database $db;
    private User $userModel;
    private Object $objectModel;
    private QrScan $qrScanModel;
    private Payment $paymentModel;
    private EmailService $emailService;
    private array $config;

    public function __construct(Database $db, array $config)
    {
        $this->db = $db;
        $this->userModel = new User($db);
        $this->objectModel = new Object($db);
        $this->qrScanModel = new QrScan($db);
        $this->paymentModel = new Payment($db);
        $this->config = $config;
        
        $emailConfig = $this->getSmtpSettings();
        $this->emailService = new EmailService($emailConfig);
    }

    // ==================== DASHBOARD & STATISTICS ====================

    public function dashboard(): void
    {
        $this->requireAdmin();
        
        $stats = [
            'total_users' => $this->getTotalUsers(),
            'total_objects' => $this->getTotalObjects(),
            'total_qr_codes' => $this->getTotalQrCodes(),
            'total_payments' => $this->getTotalPayments(),
            'total_revenue' => $this->getTotalRevenue(),
            'new_users_today' => $this->getNewUsersToday(),
            'new_users_this_week' => $this->getNewUsersThisWeek(),
            'new_users_this_month' => $this->getNewUsersThisMonth(),
            'scans_today' => $this->getScansToday(),
            'scans_this_month' => $this->getScansThisMonth(),
        ];
        
        $this->render('admin/dashboard', ['stats' => $stats]);
    }

    public function getStatistics(): void
    {
        $this->requireAdminApi();
        
        header('Content-Type: application/json');
        
        $period = $_GET['period'] ?? 'month';
        
        $data = [
            'user_growth' => $this->getUserGrowthData($period),
            'qr_generation' => $this->getQrGenerationData($period),
            'scans_over_time' => $this->getScansOverTimeData($period),
            'revenue_over_time' => $this->getRevenueOverTimeData($period),
            'top_countries' => $this->getTopCountries(),
            'top_cities' => $this->getTopCities(),
        ];
        
        echo json_encode(['success' => true, 'data' => $data]);
    }

    // ==================== USER MANAGEMENT ====================

    public function users(): void
    {
        $this->requireAdmin();
        $countries = $this->getAllCountries();
        $this->render('admin/users', ['countries' => $countries]);
    }

    public function getUsers(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $filters = [
            'search' => $_GET['search'] ?? '',
            'first_name' => $_GET['first_name'] ?? '',
            'last_name' => $_GET['last_name'] ?? '',
            'city' => $_GET['city'] ?? '',
            'country' => $_GET['country'] ?? '',
            'email' => $_GET['email'] ?? '',
            'nickname' => $_GET['nickname'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to' => $_GET['date_to'] ?? '',
        ];
        
        $page = (int)($_GET['page'] ?? 1);
        $perPage = (int)($_GET['per_page'] ?? 20);
        
        $result = $this->searchUsers($filters, $page, $perPage);
        
        echo json_encode(['success' => true, 'data' => $result]);
    }

    public function getUser(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $user = $this->userModel->findById($id);
        
        if (!$user) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Utente non trovato']);
            return;
        }
        
        // Get additional user data
        $user['objects'] = $this->objectModel->findByUserId($id);
        $user['payments'] = $this->paymentModel->findByUserId($id);
        
        echo json_encode(['success' => true, 'data' => $user]);
    }

    public function updateUser(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $allowedFields = ['first_name', 'last_name', 'nickname', 'email', 'phone', 
                         'city', 'province', 'country_code', 'postal_code', 'address',
                         'is_active', 'newsletter_subscribed', 'language'];
        
        $updateData = array_intersect_key($data, array_flip($allowedFields));
        
        if (empty($updateData)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Nessun dato da aggiornare']);
            return;
        }
        
        $success = $this->userModel->update($id, $updateData);
        
        if ($success) {
            $this->logActivity('update_user', 'user', $id, null, $updateData);
            echo json_encode(['success' => true, 'message' => 'Utente aggiornato']);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'aggiornamento']);
        }
    }

    public function deleteUser(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        // Prevent self-deletion
        $currentUser = $this->getCurrentUser();
        if ($currentUser['id'] === $id) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Non puoi eliminare il tuo account']);
            return;
        }
        
        $success = $this->userModel->delete($id);
        
        if ($success) {
            $this->logActivity('delete_user', 'user', $id, null, null);
            echo json_encode(['success' => true, 'message' => 'Utente eliminato']);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'eliminazione']);
        }
    }

    // ==================== QR CODE MANAGEMENT ====================

    public function qrCodes(): void
    {
        $this->requireAdmin();
        $countries = $this->getAllCountries();
        $users = $this->getAllUsersBasic();
        $this->render('admin/qr_codes', ['countries' => $countries, 'users' => $users]);
    }

    public function getQrCodes(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $filters = [
            'date_from' => $_GET['date_from'] ?? '',
            'date_to' => $_GET['date_to'] ?? '',
            'user_id' => $_GET['user_id'] ?? '',
            'city' => $_GET['city'] ?? '',
            'province' => $_GET['province'] ?? '',
            'country' => $_GET['country'] ?? '',
            'has_scans' => $_GET['has_scans'] ?? '',
            'label_purchased' => $_GET['label_purchased'] ?? '',
        ];
        
        $page = (int)($_GET['page'] ?? 1);
        $perPage = (int)($_GET['per_page'] ?? 20);
        
        $result = $this->searchQrCodes($filters, $page, $perPage);
        
        echo json_encode(['success' => true, 'data' => $result]);
    }

    public function getQrCodePreview(int $id): void
    {
        $this->requireAdminApi();
        
        $object = $this->objectModel->findById($id);
        
        if (!$object || !$object['qr_code_path']) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'QR code non trovato']);
            return;
        }
        
        $path = __DIR__ . '/../../storage/qr_codes/' . $object['qr_code_path'];
        
        if (!file_exists($path)) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'File non trovato']);
            return;
        }
        
        header('Content-Type: image/png');
        readfile($path);
        exit;
    }

    // ==================== ADMIN PROFILE ====================

    public function profile(): void
    {
        $this->requireAdmin();
        $this->render('admin/profile');
    }

    public function updateProfile(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $currentUser = $this->getCurrentUser();
        $data = json_decode(file_get_contents('php://input'), true);
        
        // If password is being changed, require verification code
        if (!empty($data['password'])) {
            if (empty($data['verification_code'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Codice di verifica richiesto']);
                return;
            }
            
            if (!$this->verifyAdminCode($currentUser['id'], $data['verification_code'])) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Codice di verifica non valido']);
                return;
            }
            
            // Update password
            $this->userModel->updatePassword($currentUser['id'], $data['password']);
        }
        
        // Update other fields
        $allowedFields = ['first_name', 'last_name', 'nickname', 'email', 'phone', 
                         'city', 'province', 'country_code', 'avatar'];
        $updateData = array_intersect_key($data, array_flip($allowedFields));
        
        if (!empty($updateData)) {
            $this->userModel->update($currentUser['id'], $updateData);
        }
        
        echo json_encode(['success' => true, 'message' => 'Profilo aggiornato']);
    }

    public function sendVerificationCode(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $currentUser = $this->getCurrentUser();
        $code = sprintf('%05d', random_int(0, 99999));
        
        // Store code in database
        $sql = "UPDATE admin_profiles SET verification_code = :code, verification_code_expires = DATE_ADD(NOW(), INTERVAL 10 MINUTE) WHERE user_id = :user_id";
        $this->db->execute($sql, [':code' => $code, ':user_id' => $currentUser['id']]);
        
        // Send email
        $sent = $this->emailService->sendTemplate(
            $currentUser['email'],
            'admin_verification',
            ['code' => $code, 'first_name' => $currentUser['first_name']]
        );
        
        if ($sent) {
            echo json_encode(['success' => true, 'message' => 'Codice inviato via email']);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'invio dell\'email']);
        }
    }

    // ==================== SEO SETTINGS ====================

    public function seo(): void
    {
        $this->requireAdmin();
        $settings = $this->getSeoSettings();
        $this->render('admin/seo', ['settings' => $settings]);
    }

    public function updateSeo(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $settings = [
            'seo_title_it', 'seo_title_en',
            'seo_description_it', 'seo_description_en',
            'seo_keywords_it', 'seo_keywords_en'
        ];
        
        foreach ($settings as $key) {
            if (isset($data[$key])) {
                $this->updateSetting($key, $data[$key], 'seo');
            }
        }
        
        $this->logActivity('update_seo', 'settings', null, null, $data);
        echo json_encode(['success' => true, 'message' => 'Impostazioni SEO aggiornate']);
    }

    // ==================== BRANDING SETTINGS ====================

    public function branding(): void
    {
        $this->requireAdmin();
        $settings = $this->getBrandingSettings();
        $this->render('admin/branding', ['settings' => $settings]);
    }

    public function updateBranding(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $settings = [
            'primary_color', 'secondary_color', 'background_color',
            'text_color', 'link_color', 'footer_background', 'footer_text_color'
        ];
        
        foreach ($settings as $key) {
            if (isset($data[$key])) {
                $this->updateSetting($key, $data[$key], 'branding');
            }
        }
        
        $this->logActivity('update_branding', 'settings', null, null, $data);
        echo json_encode(['success' => true, 'message' => 'Impostazioni grafiche aggiornate']);
    }

    public function uploadLogo(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        if (!isset($_FILES['logo']) || $_FILES['logo']['error'] !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Nessun file caricato']);
            return;
        }
        
        $file = $_FILES['logo'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/svg+xml'];
        
        if (!in_array($file['type'], $allowedTypes)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Formato non supportato']);
            return;
        }
        
        $filename = 'logo_' . time() . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
        $uploadPath = __DIR__ . '/../../storage/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $this->updateSetting('site_logo', $filename, 'branding');
            echo json_encode(['success' => true, 'filename' => $filename]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante il caricamento']);
        }
    }

    // ==================== SMTP SETTINGS ====================

    public function smtp(): void
    {
        $this->requireAdmin();
        $settings = $this->getSmtpSettings();
        $this->render('admin/smtp', ['settings' => $settings]);
    }

    public function updateSmtp(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $settings = [
            'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password',
            'smtp_encryption', 'smtp_from_email', 'smtp_from_name', 'smtp_auth'
        ];
        
        foreach ($settings as $key) {
            if (isset($data[$key])) {
                $this->updateSetting($key, $data[$key], 'email');
            }
        }
        
        $this->logActivity('update_smtp', 'settings', null, null, ['host' => $data['smtp_host'] ?? '']);
        echo json_encode(['success' => true, 'message' => 'Impostazioni SMTP aggiornate']);
    }

    public function testSmtp(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        $testEmail = $data['test_email'] ?? '';
        
        if (!filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Email non valida']);
            return;
        }
        
        // Create temporary email service with new settings
        $emailConfig = [
            'host' => $data['smtp_host'] ?? $this->config['mail']['host'],
            'port' => (int)($data['smtp_port'] ?? $this->config['mail']['port']),
            'username' => $data['smtp_username'] ?? $this->config['mail']['username'],
            'password' => $data['smtp_password'] ?? $this->config['mail']['password'],
            'encryption' => $data['smtp_encryption'] ?? $this->config['mail']['encryption'],
            'from_address' => $data['smtp_from_email'] ?? $this->config['mail']['from_address'],
            'from_name' => $data['smtp_from_name'] ?? $this->config['mail']['from_name'],
        ];
        
        $emailService = new EmailService($emailConfig);
        
        $sent = $emailService->send(
            $testEmail,
            'Test SMTP - QR Finder',
            '<h2>Test SMTP</h2><p>Questa è una email di test dal pannello admin di QR Finder.</p><p>Se ricevi questa email, la configurazione SMTP funziona correttamente!</p>',
            true
        );
        
        if ($sent) {
            echo json_encode(['success' => true, 'message' => 'Email di test inviata con successo']);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Impossibile inviare l\'email di test']);
        }
    }

    // ==================== NEWSLETTER ====================

    public function newsletter(): void
    {
        $this->requireAdmin();
        $subscribers = $this->getNewsletterSubscribersCount();
        $campaigns = $this->getNewsletterCampaigns();
        $this->render('admin/newsletter', ['subscribers' => $subscribers, 'campaigns' => $campaigns]);
    }

    public function getNewsletterSubscribers(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $page = (int)($_GET['page'] ?? 1);
        $perPage = (int)($_GET['per_page'] ?? 50);
        $search = $_GET['search'] ?? '';
        
        $result = $this->getSubscribersList($search, $page, $perPage);
        
        echo json_encode(['success' => true, 'data' => $result]);
    }

    public function sendNewsletter(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (empty($data['subject_it']) || empty($data['content_it'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Oggetto e contenuto richiesti']);
            return;
        }
        
        $currentUser = $this->getCurrentUser();
        
        // Save campaign
        $sql = "INSERT INTO newsletter_campaigns (subject_it, subject_en, content_it, content_en, sent_by, status) 
                VALUES (:subject_it, :subject_en, :content_it, :content_en, :sent_by, 'sending')";
        $this->db->execute($sql, [
            ':subject_it' => $data['subject_it'],
            ':subject_en' => $data['subject_en'] ?? $data['subject_it'],
            ':content_it' => $data['content_it'],
            ':content_en' => $data['content_en'] ?? $data['content_it'],
            ':sent_by' => $currentUser['id']
        ]);
        $campaignId = $this->db->lastInsertId();
        
        // Get active subscribers
        $subscribers = $this->db->query("SELECT * FROM newsletter_subscribers WHERE is_active = TRUE");
        
        $sent = 0;
        $failed = 0;
        
        foreach ($subscribers as $subscriber) {
            $language = $subscriber['language'] ?? 'it';
            $subject = $language === 'en' ? ($data['subject_en'] ?? $data['subject_it']) : $data['subject_it'];
            $content = $language === 'en' ? ($data['content_en'] ?? $data['content_it']) : $data['content_it'];
            
            // Add unsubscribe link
            $unsubscribeUrl = $this->config['app']['url'] . '/unsubscribe?token=' . ($subscriber['unsubscribe_token'] ?? '');
            $content .= '<hr><p style="font-size:12px;color:#666;"><a href="' . $unsubscribeUrl . '">Unsubscribe</a></p>';
            
            $emailSent = $this->emailService->send($subscriber['email'], $subject, $content, true);
            
            if ($emailSent) {
                $sent++;
            } else {
                $failed++;
            }
            
            // Small delay to avoid overwhelming the SMTP server
            usleep(100000); // 100ms
        }
        
        // Update campaign
        $sql = "UPDATE newsletter_campaigns SET status = 'sent', sent_at = NOW(), recipients_count = :count WHERE id = :id";
        $this->db->execute($sql, [':count' => $sent, ':id' => $campaignId]);
        
        $this->logActivity('send_newsletter', 'newsletter', $campaignId, null, ['sent' => $sent, 'failed' => $failed]);
        
        echo json_encode([
            'success' => true, 
            'message' => "Newsletter inviata a {$sent} iscritti" . ($failed > 0 ? " ({$failed} falliti)" : '')
        ]);
    }

    // ==================== STATIC PAGES ====================

    public function pages(): void
    {
        $this->requireAdmin();
        $pages = $this->getAllPages();
        $this->render('admin/pages', ['pages' => $pages]);
    }

    public function getPage(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $page = $this->getPageById($id);
        
        if (!$page) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Pagina non trovata']);
            return;
        }
        
        echo json_encode(['success' => true, 'data' => $page]);
    }

    public function createPage(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        $currentUser = $this->getCurrentUser();
        
        $sql = "INSERT INTO pages (slug, title_it, title_en, content_it, content_en, meta_description_it, meta_description_en, show_in_footer, footer_order, created_by) 
                VALUES (:slug, :title_it, :title_en, :content_it, :content_en, :meta_description_it, :meta_description_en, :show_in_footer, :footer_order, :created_by)";
        
        $this->db->execute($sql, [
            ':slug' => $this->slugify($data['title_it']),
            ':title_it' => $data['title_it'],
            ':title_en' => $data['title_en'] ?? $data['title_it'],
            ':content_it' => $data['content_it'] ?? '',
            ':content_en' => $data['content_en'] ?? '',
            ':meta_description_it' => $data['meta_description_it'] ?? '',
            ':meta_description_en' => $data['meta_description_en'] ?? '',
            ':show_in_footer' => $data['show_in_footer'] ?? true,
            ':footer_order' => $data['footer_order'] ?? 0,
            ':created_by' => $currentUser['id']
        ]);
        
        $pageId = $this->db->lastInsertId();
        $this->logActivity('create_page', 'page', $pageId, null, ['title' => $data['title_it']]);
        
        echo json_encode(['success' => true, 'message' => 'Pagina creata', 'id' => $pageId]);
    }

    public function updatePage(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $data = json_decode(file_get_contents('php://input'), true);
        $currentUser = $this->getCurrentUser();
        
        $oldPage = $this->getPageById($id);
        
        $sql = "UPDATE pages SET 
                title_it = :title_it, title_en = :title_en,
                content_it = :content_it, content_en = :content_en,
                meta_description_it = :meta_description_it, meta_description_en = :meta_description_en,
                is_published = :is_published, show_in_footer = :show_in_footer, footer_order = :footer_order,
                updated_by = :updated_by, updated_at = NOW()
                WHERE id = :id";
        
        $this->db->execute($sql, [
            ':id' => $id,
            ':title_it' => $data['title_it'],
            ':title_en' => $data['title_en'] ?? $data['title_it'],
            ':content_it' => $data['content_it'] ?? '',
            ':content_en' => $data['content_en'] ?? '',
            ':meta_description_it' => $data['meta_description_it'] ?? '',
            ':meta_description_en' => $data['meta_description_en'] ?? '',
            ':is_published' => $data['is_published'] ?? true,
            ':show_in_footer' => $data['show_in_footer'] ?? true,
            ':footer_order' => $data['footer_order'] ?? 0,
            ':updated_by' => $currentUser['id']
        ]);
        
        $this->logActivity('update_page', 'page', $id, $oldPage, $data);
        
        echo json_encode(['success' => true, 'message' => 'Pagina aggiornata']);
    }

    public function deletePage(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $sql = "DELETE FROM pages WHERE id = :id";
        $this->db->execute($sql, [':id' => $id]);
        
        $this->logActivity('delete_page', 'page', $id, null, null);
        
        echo json_encode(['success' => true, 'message' => 'Pagina eliminata']);
    }

    // ==================== CONTACT MESSAGES ====================

    public function messages(): void
    {
        $this->requireAdmin();
        $messages = $this->getContactMessages();
        $this->render('admin/messages', ['messages' => $messages]);
    }

    public function getMessages(): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $page = (int)($_GET['page'] ?? 1);
        $perPage = (int)($_GET['per_page'] ?? 20);
        $unreadOnly = filter_var($_GET['unread'] ?? false, FILTER_VALIDATE_BOOLEAN);
        
        $result = $this->getContactMessagesList($unreadOnly, $page, $perPage);
        
        echo json_encode(['success' => true, 'data' => $result]);
    }

    public function markMessageRead(int $id): void
    {
        $this->requireAdminApi();
        header('Content-Type: application/json');
        
        $currentUser = $this->getCurrentUser();
        
        $sql = "UPDATE contact_messages SET is_read = TRUE, replied_by = :user_id, replied_at = NOW() WHERE id = :id";
        $this->db->execute($sql, [':id' => $id, ':user_id' => $currentUser['id']]);
        
        echo json_encode(['success' => true]);
    }

    // ==================== HELPER METHODS ====================

    private function requireAdmin(): void
    {
        $user = $this->getCurrentUser();
        if (!$user || !$user['is_admin']) {
            header('Location: /login');
            exit;
        }
    }

    private function requireAdminApi(): void
    {
        $user = $this->getCurrentUser();
        if (!$user || !$user['is_admin']) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Accesso negato']);
            exit;
        }
    }

    private function getCurrentUser(): ?array
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);
        
        if (!$token) {
            $token = $_SESSION['admin_token'] ?? '';
        }
        
        if (!$token) {
            return null;
        }
        
        $session = $this->userModel->validateSession($token);
        
        if (!$session) {
            return null;
        }
        
        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name'],
            'is_admin' => $session['is_admin'] ?? false
        ];
    }

    private function render(string $template, array $data = []): void
    {
        extract($data);
        include __DIR__ . '/../../templates/admin/' . $template . '.php';
        exit;
    }

    // ... (additional helper methods for statistics, database queries, etc.)
}
