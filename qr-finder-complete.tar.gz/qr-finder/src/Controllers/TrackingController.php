<?php

declare(strict_types=1);

namespace QrFinder\Controllers;

use QrFinder\Models\Object;
use QrFinder\Models\QrScan;
use QrFinder\Services\NotificationService;
use QrFinder\Utils\Database;

class TrackingController
{
    private Object $objectModel;
    private QrScan $qrScanModel;
    private NotificationService $notificationService;

    public function __construct(
        Database $db,
        NotificationService $notificationService
    ) {
        $this->objectModel = new Object($db);
        $this->qrScanModel = new QrScan($db);
        $this->notificationService = $notificationService;
    }

    public function track(string $shortCode): void
    {
        try {
            // Find object by short code
            $object = $this->objectModel->findByShortCode($shortCode);

            if (!$object) {
                // Show error page
                $this->renderErrorPage('Codice QR non valido');
                return;
            }

            // Get geolocation data from request
            $data = json_decode(file_get_contents('php://input'), true);
            
            $latitude = $data['latitude'] ?? $_POST['latitude'] ?? null;
            $longitude = $data['longitude'] ?? $_POST['longitude'] ?? null;
            $accuracy = $data['accuracy'] ?? $_POST['accuracy'] ?? null;

            // Record the scan
            $scanData = [
                'object_id' => $object['id'],
                'latitude' => $latitude,
                'longitude' => $longitude,
                'accuracy' => $accuracy,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
            ];

            $scanId = $this->qrScanModel->create($scanData);
            $scanData['id'] = $scanId;
            $scanData['scanned_at'] = date('Y-m-d H:i:s');

            // Send notification to owner (async would be better in production)
            try {
                $this->notificationService->notifyObjectFound($object, $scanData);
            } catch (\Exception $e) {
                error_log("Notification error: " . $e->getMessage());
                // Don't fail the request if notification fails
            }

            // Return success response for AJAX requests
            if ($this->isAjaxRequest()) {
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => true,
                    'message' => 'Posizione registrata. Grazie per aver aiutato!',
                    'data' => [
                        'object_name' => $object['name'],
                        'owner_notified' => true
                    ]
                ]);
                return;
            }

            // Render the tracking page
            $this->renderTrackingPage($object, $scanData);

        } catch (\Exception $e) {
            error_log("Tracking error: " . $e->getMessage());
            
            if ($this->isAjaxRequest()) {
                header('Content-Type: application/json');
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => 'Errore durante il tracciamento']);
                return;
            }

            $this->renderErrorPage('Errore durante il tracciamento');
        }
    }

    public function showTrackingPage(string $shortCode): void
    {
        try {
            $object = $this->objectModel->findByShortCode($shortCode);

            if (!$object) {
                $this->renderErrorPage('Codice QR non valido');
                return;
            }

            $this->renderTrackingPage($object, []);

        } catch (\Exception $e) {
            error_log("Show tracking page error: " . $e->getMessage());
            $this->renderErrorPage('Errore del server');
        }
    }

    public function submitContactForm(string $shortCode): void
    {
        header('Content-Type: application/json');

        try {
            $object = $this->objectModel->findByShortCode($shortCode);

            if (!$object) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            $data = json_decode(file_get_contents('php://input'), true);

            // Validate contact data
            if (empty($data['message'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Messaggio richiesto']);
                return;
            }

            // Store contact message
            $db = $this->objectModel->db;
            $sql = "INSERT INTO contact_messages (object_id, finder_name, finder_email, finder_phone, message) 
                    VALUES (:object_id, :finder_name, :finder_email, :finder_phone, :message)";
            
            $db->execute($sql, [
                ':object_id' => $object['id'],
                ':finder_name' => $data['name'] ?? null,
                ':finder_email' => $data['email'] ?? null,
                ':finder_phone' => $data['phone'] ?? null,
                ':message' => $data['message']
            ]);

            // Send notification to owner
            $this->notificationService->sendObjectContactNotification($object, $data);

            echo json_encode([
                'success' => true,
                'message' => 'Messaggio inviato con successo! Il proprietario verrà avvisato.'
            ]);

        } catch (\Exception $e) {
            error_log("Contact form error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'invio del messaggio']);
        }
    }

    public function getScanHistory(int $objectId): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($objectId);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            $history = $this->qrScanModel->findByObjectId($objectId, 100);

            echo json_encode([
                'success' => true,
                'data' => $history
            ]);

        } catch (\Exception $e) {
            error_log("Get scan history error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    private function renderTrackingPage(array $object, array $scanData): void
    {
        $pageTitle = 'Oggetto Trovato - QR Finder';
        $objectName = htmlspecialchars($object['name']);
        $category = htmlspecialchars($object['category']);
        $description = htmlspecialchars($object['description'] ?? '');
        $shortCode = htmlspecialchars($object['short_code']);
        
        // Include the tracking page template
        include __DIR__ . '/../../templates/tracking_page.php';
    }

    private function renderErrorPage(string $message): void
    {
        $pageTitle = 'Errore - QR Finder';
        $errorMessage = htmlspecialchars($message);
        
        include __DIR__ . '/../../templates/error_page.php';
    }

    private function isAjaxRequest(): bool
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    private function getAuthenticatedUser(): ?array
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);

        if (!$token) {
            return null;
        }

        $userModel = new \QrFinder\Models\User($this->objectModel->db);
        $session = $userModel->validateSession($token);

        if (!$session) {
            return null;
        }

        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name']
        ];
    }
}
