<?php

declare(strict_types=1);

namespace QrFinder\Controllers;

use QrFinder\Models\Object;
use QrFinder\Models\User;
use QrFinder\Services\QrCodeService;
use QrFinder\Services\StripeService;
use QrFinder\Services\NotificationService;
use QrFinder\Utils\Database;

class ObjectController
{
    private Object $objectModel;
    private User $userModel;
    private QrCodeService $qrCodeService;
    private StripeService $stripeService;
    private NotificationService $notificationService;
    private array $config;

    public function __construct(
        Database $db,
        QrCodeService $qrCodeService,
        StripeService $stripeService,
        NotificationService $notificationService,
        array $config
    ) {
        $this->objectModel = new Object($db);
        $this->userModel = new User($db);
        $this->qrCodeService = $qrCodeService;
        $this->stripeService = $stripeService;
        $this->notificationService = $notificationService;
        $this->config = $config;
    }

    public function index(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $objects = $this->objectModel->findByUserId($user['id']);

            echo json_encode([
                'success' => true,
                'data' => $objects
            ]);

        } catch (\Exception $e) {
            error_log("Get objects error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function show(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($id);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            // Get scan history
            $scanHistory = $this->objectModel->getScanHistory($id);

            echo json_encode([
                'success' => true,
                'data' => array_merge($object, ['scan_history' => $scanHistory])
            ]);

        } catch (\Exception $e) {
            error_log("Get object error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function create(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $data = json_decode(file_get_contents('php://input'), true);

            if (!$data || empty($data['name'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Nome oggetto richiesto']);
                return;
            }

            // Generate short code
            $shortCode = $this->objectModel->generateShortCode();

            // Generate QR code
            $qrResult = $this->qrCodeService->generate($shortCode);

            // Create object
            $objectId = $this->objectModel->create([
                'user_id' => $user['id'],
                'name' => $data['name'],
                'description' => $data['description'] ?? null,
                'category' => $data['category'] ?? 'other',
                'short_code' => $shortCode,
                'qr_code_path' => $qrResult['filename']
            ]);

            $object = $this->objectModel->findById($objectId);

            http_response_code(201);
            echo json_encode([
                'success' => true,
                'data' => array_merge($object, [
                    'qr_code_url' => $qrResult['dataUri'],
                    'short_url' => $qrResult['url']
                ])
            ]);

        } catch (\Exception $e) {
            error_log("Create object error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante la creazione']);
        }
    }

    public function update(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($id);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            $data = json_decode(file_get_contents('php://input'), true);

            $this->objectModel->update($id, $data);
            $updatedObject = $this->objectModel->findById($id);

            echo json_encode([
                'success' => true,
                'data' => $updatedObject
            ]);

        } catch (\Exception $e) {
            error_log("Update object error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'aggiornamento']);
        }
    }

    public function delete(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($id);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            $this->objectModel->delete($id);

            echo json_encode([
                'success' => true,
                'message' => 'Oggetto eliminato'
            ]);

        } catch (\Exception $e) {
            error_log("Delete object error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore durante l\'eliminazione']);
        }
    }

    public function createPaymentIntent(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($id);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            if ($object['label_purchased']) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Etichetta già acquistata']);
                return;
            }

            $amount = $this->config['pricing']['label_price_cents'];
            $currency = $this->config['pricing']['currency'];

            $result = $this->stripeService->createPaymentIntent($amount, $currency, [
                'object_id' => (string)$id,
                'user_id' => (string)$user['id']
            ]);

            if (!$result['success']) {
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => 'Errore durante la creazione del pagamento']);
                return;
            }

            echo json_encode([
                'success' => true,
                'data' => [
                    'client_secret' => $result['client_secret'],
                    'publishable_key' => $this->stripeService->getPublishableKey()
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Create payment intent error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function downloadQrCode(int $id): void
    {
        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($id);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            if (!$object['label_purchased']) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Etichetta non acquistata']);
                return;
            }

            $qrPath = $this->qrCodeService->getQrCodePath($object['qr_code_path']);

            if (!file_exists($qrPath)) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'QR code non trovato']);
                return;
            }

            header('Content-Type: image/png');
            header('Content-Disposition: attachment; filename="qr-' . $object['short_code'] . '.png"');
            readfile($qrPath);
            exit;

        } catch (\Exception $e) {
            error_log("Download QR code error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function getLocations(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $locations = $this->objectModel->getObjectLocations($user['id']);

            echo json_encode([
                'success' => true,
                'data' => $locations
            ]);

        } catch (\Exception $e) {
            error_log("Get locations error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function getMapData(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $object = $this->objectModel->findById($id);

            if (!$object || $object['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Oggetto non trovato']);
                return;
            }

            $scanHistory = $this->objectModel->getScanHistory($id);

            // Filter scans with valid coordinates
            $locations = array_filter($scanHistory, function($scan) {
                return !empty($scan['latitude']) && !empty($scan['longitude']);
            });

            echo json_encode([
                'success' => true,
                'data' => [
                    'object' => $object,
                    'locations' => array_values($locations)
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Get map data error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    private function getAuthenticatedUser(): ?array
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);

        if (!$token) {
            return null;
        }

        $session = $this->userModel->validateSession($token);

        if (!$session) {
            return null;
        }

        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name'],
            'email_verified' => $session['email_verified']
        ];
    }
}
