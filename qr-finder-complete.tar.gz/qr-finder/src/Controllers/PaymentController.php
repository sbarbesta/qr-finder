<?php

declare(strict_types=1);

namespace QrFinder\Controllers;

use QrFinder\Models\Payment;
use QrFinder\Models\Object;
use QrFinder\Services\StripeService;
use QrFinder\Services\NotificationService;
use QrFinder\Utils\Database;

class PaymentController
{
    private Payment $paymentModel;
    private Object $objectModel;
    private StripeService $stripeService;
    private NotificationService $notificationService;

    public function __construct(
        Database $db,
        StripeService $stripeService,
        NotificationService $notificationService
    ) {
        $this->paymentModel = new Payment($db);
        $this->objectModel = new Object($db);
        $this->stripeService = $stripeService;
        $this->notificationService = $notificationService;
    }

    public function handleWebhook(): void
    {
        header('Content-Type: application/json');

        try {
            $payload = file_get_contents('php://input');
            $sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

            $event = $this->stripeService->constructEvent($payload, $sigHeader);

            if (!$event) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid signature']);
                return;
            }

            $result = $this->stripeService->handleWebhook($event);

            if ($result['handled'] && isset($result['payment_intent_id'])) {
                // Update payment status in database
                $this->paymentModel->updateStatus($result['payment_intent_id'], $result['status']);

                // If payment succeeded, update object
                if ($result['status'] === 'succeeded') {
                    $payment = $this->paymentModel->findByPaymentIntent($result['payment_intent_id']);
                    if ($payment && $payment['object_id']) {
                        $this->objectModel->markLabelPurchased($payment['object_id'], $result['payment_intent_id']);
                        
                        // Send confirmation email
                        $object = $this->objectModel->findById($payment['object_id']);
                        $user = [
                            'email' => $payment['user_email'],
                            'first_name' => $payment['first_name'] ?? 'Utente'
                        ];
                        $this->notificationService->sendLabelPurchasedEmail($user, $object);
                    }
                }
            }

            echo json_encode(['success' => true, 'received' => true]);

        } catch (\Exception $e) {
            error_log("Webhook error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Webhook processing error']);
        }
    }

    public function getPaymentStatus(string $paymentIntentId): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $payment = $this->paymentModel->findByPaymentIntent($paymentIntentId);

            if (!$payment || $payment['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Pagamento non trovato']);
                return;
            }

            // Get fresh status from Stripe
            $stripePayment = $this->stripeService->retrievePaymentIntent($paymentIntentId);

            echo json_encode([
                'success' => true,
                'data' => [
                    'status' => $stripePayment ? $stripePayment->status : $payment['status'],
                    'amount' => $payment['amount_cents'],
                    'currency' => $payment['currency'],
                    'created_at' => $payment['created_at']
                ]
            ]);

        } catch (\Exception $e) {
            error_log("Get payment status error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function getPaymentHistory(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $payments = $this->paymentModel->findByUserId($user['id']);

            echo json_encode([
                'success' => true,
                'data' => $payments
            ]);

        } catch (\Exception $e) {
            error_log("Get payment history error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function createRefund(int $paymentId): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $payment = $this->paymentModel->findById($paymentId);

            if (!$payment || $payment['user_id'] != $user['id']) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Pagamento non trovato']);
                return;
            }

            if ($payment['status'] !== 'succeeded') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Il pagamento non può essere rimborsato']);
                return;
            }

            $result = $this->stripeService->refund($payment['stripe_payment_intent']);

            if (!$result['success']) {
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => 'Errore durante il rimborso']);
                return;
            }

            // Update payment status
            $this->paymentModel->updateStatus($payment['stripe_payment_intent'], 'refunded');

            echo json_encode([
                'success' => true,
                'message' => 'Rimborso effettuato con successo',
                'data' => $result
            ]);

        } catch (\Exception $e) {
            error_log("Refund error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    private function getAuthenticatedUser(): ?array
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);

        if (!$token) {
            return null;
        }

        $userModel = new \QrFinder\Models\User($this->paymentModel->db);
        $session = $userModel->validateSession($token);

        if (!$session) {
            return null;
        }

        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name']
        ];
    }
}
