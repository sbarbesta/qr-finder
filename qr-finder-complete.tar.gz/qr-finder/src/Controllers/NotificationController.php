<?php

declare(strict_types=1);

namespace QrFinder\Controllers;

use QrFinder\Models\User;
use QrFinder\Services\NotificationService;
use QrFinder\Utils\Database;

class NotificationController
{
    private User $userModel;
    private NotificationService $notificationService;

    public function __construct(
        Database $db,
        NotificationService $notificationService
    ) {
        $this->userModel = new User($db);
        $this->notificationService = $notificationService;
    }

    public function index(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $notifications = $this->notificationService->getUnreadNotifications($user['id']);

            echo json_encode([
                'success' => true,
                'data' => $notifications
            ]);

        } catch (\Exception $e) {
            error_log("Get notifications error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function getAll(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $notifications = $this->notificationService->notificationModel->findByUserId($user['id'], false, 100);

            echo json_encode([
                'success' => true,
                'data' => $notifications
            ]);

        } catch (\Exception $e) {
            error_log("Get all notifications error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function getUnreadCount(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $count = $this->notificationService->getUnreadCount($user['id']);

            echo json_encode([
                'success' => true,
                'data' => ['count' => $count]
            ]);

        } catch (\Exception $e) {
            error_log("Get unread count error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function markAsRead(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $success = $this->notificationService->markAsRead($id, $user['id']);

            if (!$success) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Notifica non trovata']);
                return;
            }

            echo json_encode([
                'success' => true,
                'message' => 'Notifica segnata come letta'
            ]);

        } catch (\Exception $e) {
            error_log("Mark as read error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function markAllAsRead(): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            $count = $this->notificationService->markAllAsRead($user['id']);

            echo json_encode([
                'success' => true,
                'message' => "$count notifiche segnate come lette"
            ]);

        } catch (\Exception $e) {
            error_log("Mark all as read error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    public function delete(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $user = $this->getAuthenticatedUser();

            if (!$user) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Non autenticato']);
                return;
            }

            // Soft delete - mark as read (actual delete would need separate method)
            $success = $this->notificationService->markAsRead($id, $user['id']);

            if (!$success) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Notifica non trovata']);
                return;
            }

            echo json_encode([
                'success' => true,
                'message' => 'Notifica eliminata'
            ]);

        } catch (\Exception $e) {
            error_log("Delete notification error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Errore del server']);
        }
    }

    private function getAuthenticatedUser(): ?array
    {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        $token = str_replace('Bearer ', '', $token);

        if (!$token) {
            return null;
        }

        $session = $this->userModel->validateSession($token);

        if (!$session) {
            return null;
        }

        return [
            'id' => $session['user_id'],
            'email' => $session['email'],
            'first_name' => $session['first_name'],
            'last_name' => $session['last_name']
        ];
    }
}
