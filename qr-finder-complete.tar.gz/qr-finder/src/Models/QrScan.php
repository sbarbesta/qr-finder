<?php

declare(strict_types=1);

namespace QrFinder\Models;

use QrFinder\Utils\Database;

class QrScan
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function create(array $data): int
    {
        $sql = "INSERT INTO qr_scans (object_id, latitude, longitude, accuracy, ip_address, user_agent) 
                VALUES (:object_id, :latitude, :longitude, :accuracy, :ip_address, :user_agent)";

        $this->db->execute($sql, [
            ':object_id' => $data['object_id'],
            ':latitude' => $data['latitude'] ?? null,
            ':longitude' => $data['longitude'] ?? null,
            ':accuracy' => $data['accuracy'] ?? null,
            ':ip_address' => $data['ip_address'] ?? null,
            ':user_agent' => $data['user_agent'] ?? null
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT * FROM qr_scans WHERE id = :id";
        return $this->db->queryOne($sql, [':id' => $id]);
    }

    public function findByObjectId(int $objectId, int $limit = 100): array
    {
        $sql = "SELECT * FROM qr_scans 
                WHERE object_id = :object_id 
                ORDER BY scanned_at DESC 
                LIMIT :limit";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':object_id', $objectId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getLatestScan(int $objectId): ?array
    {
        $sql = "SELECT * FROM qr_scans 
                WHERE object_id = :object_id 
                ORDER BY scanned_at DESC 
                LIMIT 1";
        return $this->db->queryOne($sql, [':object_id' => $objectId]);
    }

    public function markNotificationSent(int $scanId): bool
    {
        $sql = "UPDATE qr_scans SET notification_sent = TRUE, notification_sent_at = NOW() WHERE id = :id";
        return $this->db->execute($sql, [':id' => $scanId]) > 0;
    }

    public function getScansNeedingNotification(int $minutesAgo = 5): array
    {
        $sql = "SELECT qs.*, o.user_id, o.name as object_name, u.email as user_email, 
                       u.first_name, u.last_name
                FROM qr_scans qs
                JOIN objects o ON qs.object_id = o.id
                JOIN users u ON o.user_id = u.id
                WHERE qs.notification_sent = FALSE 
                AND qs.scanned_at <= DATE_SUB(NOW(), INTERVAL :minutes MINUTE)
                ORDER BY qs.scanned_at ASC";
        
        return $this->db->query($sql, [':minutes' => $minutesAgo]);
    }

    public function getScanStats(int $objectId): array
    {
        $sql = "SELECT 
                    COUNT(*) as total_scans,
                    COUNT(DISTINCT DATE(scanned_at)) as unique_days,
                    MIN(scanned_at) as first_scan,
                    MAX(scanned_at) as last_scan,
                    AVG(accuracy) as avg_accuracy
                FROM qr_scans 
                WHERE object_id = :object_id";
        
        return $this->db->queryOne($sql, [':object_id' => $objectId]) ?? [
            'total_scans' => 0,
            'unique_days' => 0,
            'first_scan' => null,
            'last_scan' => null,
            'avg_accuracy' => null
        ];
    }

    public function getRecentScansByUser(int $userId, int $limit = 20): array
    {
        $sql = "SELECT qs.*, o.name as object_name, o.short_code, o.category
                FROM qr_scans qs
                JOIN objects o ON qs.object_id = o.id
                WHERE o.user_id = :user_id
                ORDER BY qs.scanned_at DESC
                LIMIT :limit";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}
