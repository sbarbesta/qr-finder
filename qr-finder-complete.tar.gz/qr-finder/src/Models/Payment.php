<?php

declare(strict_types=1);

namespace QrFinder\Models;

use QrFinder\Utils\Database;

class Payment
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function create(array $data): int
    {
        $sql = "INSERT INTO payments (user_id, object_id, stripe_payment_intent, stripe_customer_id, amount_cents, currency, status) 
                VALUES (:user_id, :object_id, :stripe_payment_intent, :stripe_customer_id, :amount_cents, :currency, :status)";

        $this->db->execute($sql, [
            ':user_id' => $data['user_id'],
            ':object_id' => $data['object_id'] ?? null,
            ':stripe_payment_intent' => $data['stripe_payment_intent'],
            ':stripe_customer_id' => $data['stripe_customer_id'] ?? null,
            ':amount_cents' => $data['amount_cents'],
            ':currency' => $data['currency'] ?? 'eur',
            ':status' => $data['status'] ?? 'pending'
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT * FROM payments WHERE id = :id";
        return $this->db->queryOne($sql, [':id' => $id]);
    }

    public function findByPaymentIntent(string $paymentIntent): ?array
    {
        $sql = "SELECT * FROM payments WHERE stripe_payment_intent = :payment_intent";
        return $this->db->queryOne($sql, [':payment_intent' => $paymentIntent]);
    }

    public function findByUserId(int $userId): array
    {
        $sql = "SELECT p.*, o.name as object_name
                FROM payments p
                LEFT JOIN objects o ON p.object_id = o.id
                WHERE p.user_id = :user_id
                ORDER BY p.created_at DESC";
        return $this->db->query($sql, [':user_id' => $userId]);
    }

    public function updateStatus(string $paymentIntent, string $status): bool
    {
        $sql = "UPDATE payments SET status = :status";
        
        if ($status === 'succeeded') {
            $sql .= ", paid_at = NOW()";
        }
        
        $sql .= " WHERE stripe_payment_intent = :payment_intent";
        
        return $this->db->execute($sql, [
            ':status' => $status,
            ':payment_intent' => $paymentIntent
        ]) > 0;
    }

    public function getTotalRevenue(): int
    {
        $sql = "SELECT SUM(amount_cents) as total FROM payments WHERE status = 'succeeded'";
        $result = $this->db->queryOne($sql);
        return (int)($result['total'] ?? 0);
    }

    public function getRevenueByPeriod(string $startDate, string $endDate): int
    {
        $sql = "SELECT SUM(amount_cents) as total FROM payments 
                WHERE status = 'succeeded' AND paid_at BETWEEN :start AND :end";
        $result = $this->db->queryOne($sql, [':start' => $startDate, ':end' => $endDate]);
        return (int)($result['total'] ?? 0);
    }

    public function getRecentPayments(int $limit = 20): array
    {
        $sql = "SELECT p.*, u.email as user_email, u.first_name, u.last_name, o.name as object_name
                FROM payments p
                JOIN users u ON p.user_id = u.id
                LEFT JOIN objects o ON p.object_id = o.id
                ORDER BY p.created_at DESC
                LIMIT :limit";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}
