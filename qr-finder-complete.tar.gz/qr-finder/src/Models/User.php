<?php

declare(strict_types=1);

namespace QrFinder\Models;

use QrFinder\Utils\Database;
use Ramsey\Uuid\Uuid;

class User
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function create(array $data): int
    {
        $sql = "INSERT INTO users (email, password_hash, first_name, last_name, phone, verification_token) 
                VALUES (:email, :password_hash, :first_name, :last_name, :phone, :verification_token)";

        $verificationToken = Uuid::uuid4()->toString();

        $this->db->execute($sql, [
            ':email' => $data['email'],
            ':password_hash' => password_hash($data['password'], PASSWORD_BCRYPT),
            ':first_name' => $data['first_name'],
            ':last_name' => $data['last_name'],
            ':phone' => $data['phone'] ?? null,
            ':verification_token' => $verificationToken
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT id, email, first_name, last_name, phone, email_verified, created_at, is_active 
                FROM users WHERE id = :id";
        return $this->db->queryOne($sql, [':id' => $id]);
    }

    public function findByEmail(string $email): ?array
    {
        $sql = "SELECT * FROM users WHERE email = :email";
        return $this->db->queryOne($sql, [':email' => $email]);
    }

    public function findByVerificationToken(string $token): ?array
    {
        $sql = "SELECT * FROM users WHERE verification_token = :token";
        return $this->db->queryOne($sql, [':token' => $token]);
    }

    public function verifyEmail(int $userId): bool
    {
        $sql = "UPDATE users SET email_verified = TRUE, verification_token = NULL WHERE id = :id";
        return $this->db->execute($sql, [':id' => $userId]) > 0;
    }

    public function setResetToken(int $userId, string $token, int $expiresIn = 3600): bool
    {
        $sql = "UPDATE users SET reset_token = :token, reset_token_expires = DATE_ADD(NOW(), INTERVAL :expires SECOND) 
                WHERE id = :id";
        return $this->db->execute($sql, [
            ':token' => $token,
            ':expires' => $expiresIn,
            ':id' => $userId
        ]) > 0;
    }

    public function findByResetToken(string $token): ?array
    {
        $sql = "SELECT * FROM users WHERE reset_token = :token AND reset_token_expires > NOW()";
        return $this->db->queryOne($sql, [':token' => $token]);
    }

    public function updatePassword(int $userId, string $newPassword): bool
    {
        $sql = "UPDATE users SET password_hash = :password_hash, reset_token = NULL, reset_token_expires = NULL 
                WHERE id = :id";
        return $this->db->execute($sql, [
            ':password_hash' => password_hash($newPassword, PASSWORD_BCRYPT),
            ':id' => $userId
        ]) > 0;
    }

    public function update(int $userId, array $data): bool
    {
        $allowedFields = ['first_name', 'last_name', 'phone'];
        $updates = [];
        $params = [':id' => $userId];

        foreach ($data as $field => $value) {
            if (in_array($field, $allowedFields)) {
                $updates[] = "$field = :$field";
                $params[":$field"] = $value;
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE users SET " . implode(', ', $updates) . ", updated_at = NOW() WHERE id = :id";
        return $this->db->execute($sql, $params) > 0;
    }

    public function validateCredentials(string $email, string $password): ?array
    {
        $user = $this->findByEmail($email);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            return null;
        }

        if (!$user['is_active']) {
            return null;
        }

        unset($user['password_hash']);
        return $user;
    }

    public function createSession(int $userId, string $ipAddress = null, string $userAgent = null): string
    {
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', time() + 86400 * 30); // 30 days

        $sql = "INSERT INTO user_sessions (user_id, session_token, expires_at, ip_address, user_agent) 
                VALUES (:user_id, :token, :expires_at, :ip_address, :user_agent)";

        $this->db->execute($sql, [
            ':user_id' => $userId,
            ':token' => $token,
            ':expires_at' => $expiresAt,
            ':ip_address' => $ipAddress,
            ':user_agent' => $userAgent
        ]);

        return $token;
    }

    public function validateSession(string $token): ?array
    {
        $sql = "SELECT us.*, u.email, u.first_name, u.last_name, u.email_verified 
                FROM user_sessions us 
                JOIN users u ON us.user_id = u.id 
                WHERE us.session_token = :token AND us.expires_at > NOW() AND u.is_active = TRUE";
        
        return $this->db->queryOne($sql, [':token' => $token]);
    }

    public function deleteSession(string $token): bool
    {
        $sql = "DELETE FROM user_sessions WHERE session_token = :token";
        return $this->db->execute($sql, [':token' => $token]) > 0;
    }

    public function deleteExpiredSessions(): int
    {
        $sql = "DELETE FROM user_sessions WHERE expires_at < NOW()";
        return $this->db->execute($sql);
    }
}
