<?php

declare(strict_types=1);

namespace QrFinder\Models;

use QrFinder\Utils\Database;

class Notification
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function create(array $data): int
    {
        $sql = "INSERT INTO notifications (user_id, object_id, scan_id, type, title, message) 
                VALUES (:user_id, :object_id, :scan_id, :type, :title, :message)";

        $this->db->execute($sql, [
            ':user_id' => $data['user_id'],
            ':object_id' => $data['object_id'] ?? null,
            ':scan_id' => $data['scan_id'] ?? null,
            ':type' => $data['type'] ?? 'email',
            ':title' => $data['title'],
            ':message' => $data['message']
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT * FROM notifications WHERE id = :id";
        return $this->db->queryOne($sql, [':id' => $id]);
    }

    public function findByUserId(int $userId, bool $unreadOnly = false, int $limit = 50): array
    {
        $sql = "SELECT n.*, o.name as object_name, o.short_code
                FROM notifications n
                LEFT JOIN objects o ON n.object_id = o.id
                WHERE n.user_id = :user_id";
        
        if ($unreadOnly) {
            $sql .= " AND n.is_read = FALSE";
        }
        
        $sql .= " ORDER BY n.sent_at DESC LIMIT :limit";
        
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function markAsRead(int $id, int $userId): bool
    {
        $sql = "UPDATE notifications SET is_read = TRUE, read_at = NOW() 
                WHERE id = :id AND user_id = :user_id";
        return $this->db->execute($sql, [':id' => $id, ':user_id' => $userId]) > 0;
    }

    public function markAllAsRead(int $userId): int
    {
        $sql = "UPDATE notifications SET is_read = TRUE, read_at = NOW() 
                WHERE user_id = :user_id AND is_read = FALSE";
        return $this->db->execute($sql, [':user_id' => $userId]);
    }

    public function getUnreadCount(int $userId): int
    {
        $sql = "SELECT COUNT(*) as count FROM notifications WHERE user_id = :user_id AND is_read = FALSE";
        $result = $this->db->queryOne($sql, [':user_id' => $userId]);
        return (int)($result['count'] ?? 0);
    }

    public function deleteOldNotifications(int $days = 90): int
    {
        $sql = "DELETE FROM notifications WHERE sent_at < DATE_SUB(NOW(), INTERVAL :days DAY)";
        return $this->db->execute($sql, [':days' => $days]);
    }

    public function createObjectFoundNotification(int $userId, int $objectId, int $scanId, array $scanData): int
    {
        $title = 'Oggetto trovato!';
        $message = sprintf(
            "Il tuo oggetto '%s' è stato trovato! Qualcuno ha scannerizzato il QR code%s.",
            $scanData['object_name'] ?? 'Sconosciuto',
            isset($scanData['scanned_at']) ? ' il ' . date('d/m/Y H:i', strtotime($scanData['scanned_at'])) : ''
        );

        if (isset($scanData['latitude']) && isset($scanData['longitude'])) {
            $message .= sprintf(
                " Posizione approssimativa: %.4f, %.4f",
                $scanData['latitude'],
                $scanData['longitude']
            );
        }

        return $this->create([
            'user_id' => $userId,
            'object_id' => $objectId,
            'scan_id' => $scanId,
            'type' => 'email',
            'title' => $title,
            'message' => $message
        ]);
    }
}
