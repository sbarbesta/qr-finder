<?php

declare(strict_types=1);

namespace QrFinder\Models;

use QrFinder\Utils\Database;

class Object
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function create(array $data): int
    {
        $sql = "INSERT INTO objects (user_id, name, description, category, short_code, qr_code_path) 
                VALUES (:user_id, :name, :description, :category, :short_code, :qr_code_path)";

        $this->db->execute($sql, [
            ':user_id' => $data['user_id'],
            ':name' => $data['name'],
            ':description' => $data['description'] ?? null,
            ':category' => $data['category'] ?? 'other',
            ':short_code' => $data['short_code'],
            ':qr_code_path' => $data['qr_code_path'] ?? null
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $sql = "SELECT o.*, u.email as user_email, u.first_name, u.last_name, u.phone 
                FROM objects o 
                JOIN users u ON o.user_id = u.id 
                WHERE o.id = :id";
        return $this->db->queryOne($sql, [':id' => $id]);
    }

    public function findByShortCode(string $shortCode): ?array
    {
        $sql = "SELECT o.*, u.email as user_email, u.first_name, u.last_name, u.phone 
                FROM objects o 
                JOIN users u ON o.user_id = u.id 
                WHERE o.short_code = :short_code AND o.is_active = TRUE";
        return $this->db->queryOne($sql, [':short_code' => $shortCode]);
    }

    public function findByUserId(int $userId): array
    {
        $sql = "SELECT o.*, 
                (SELECT COUNT(*) FROM qr_scans WHERE object_id = o.id) as scan_count,
                (SELECT scanned_at FROM qr_scans WHERE object_id = o.id ORDER BY scanned_at DESC LIMIT 1) as last_scanned_at
                FROM objects o 
                WHERE o.user_id = :user_id AND o.is_active = TRUE 
                ORDER BY o.created_at DESC";
        return $this->db->query($sql, [':user_id' => $userId]);
    }

    public function update(int $id, array $data): bool
    {
        $allowedFields = ['name', 'description', 'category'];
        $updates = [];
        $params = [':id' => $id];

        foreach ($data as $field => $value) {
            if (in_array($field, $allowedFields)) {
                $updates[] = "$field = :$field";
                $params[":$field"] = $value;
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE objects SET " . implode(', ', $updates) . ", updated_at = NOW() WHERE id = :id";
        return $this->db->execute($sql, $params) > 0;
    }

    public function delete(int $id): bool
    {
        $sql = "UPDATE objects SET is_active = FALSE WHERE id = :id";
        return $this->db->execute($sql, [':id' => $id]) > 0;
    }

    public function markLabelPurchased(int $id, string $paymentIntent): bool
    {
        $sql = "UPDATE objects SET label_purchased = TRUE, label_purchase_date = NOW(), stripe_payment_intent = :payment_intent WHERE id = :id";
        return $this->db->execute($sql, [
            ':id' => $id,
            ':payment_intent' => $paymentIntent
        ]) > 0;
    }

    public function updateQrCodePath(int $id, string $path): bool
    {
        $sql = "UPDATE objects SET qr_code_path = :path WHERE id = :id";
        return $this->db->execute($sql, [':id' => $id, ':path' => $path]) > 0;
    }

    public function generateShortCode(): string
    {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $code = '';
        
        do {
            $code = '';
            for ($i = 0; $i < 8; $i++) {
                $code .= $characters[random_int(0, strlen($characters) - 1)];
            }
        } while ($this->shortCodeExists($code));

        return $code;
    }

    private function shortCodeExists(string $code): bool
    {
        $sql = "SELECT COUNT(*) as count FROM objects WHERE short_code = :code";
        $result = $this->db->queryOne($sql, [':code' => $code]);
        return $result['count'] > 0;
    }

    public function getObjectLocations(int $userId): array
    {
        $sql = "SELECT 
                    o.id as object_id,
                    o.name as object_name,
                    o.short_code,
                    o.category,
                    qs.latitude,
                    qs.longitude,
                    qs.accuracy,
                    qs.scanned_at,
                    qs.notification_sent
                FROM objects o
                LEFT JOIN qr_scans qs ON o.id = qs.object_id
                WHERE o.user_id = :user_id AND o.is_active = TRUE
                AND qs.id = (
                    SELECT id FROM qr_scans 
                    WHERE object_id = o.id 
                    ORDER BY scanned_at DESC 
                    LIMIT 1
                )
                ORDER BY qs.scanned_at DESC";
        
        return $this->db->query($sql, [':user_id' => $userId]);
    }

    public function getScanHistory(int $objectId): array
    {
        $sql = "SELECT * FROM qr_scans 
                WHERE object_id = :object_id 
                ORDER BY scanned_at DESC";
        return $this->db->query($sql, [':object_id' => $objectId]);
    }
}
