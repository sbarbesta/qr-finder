<?php
/**
 * QR Finder - Test Script
 * 
 * This script tests the installation and configuration.
 * Run: php test.php
 */

if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.\n");
}

$errors = [];
$warnings = [];
$success = [];

echo "================================\n";
echo "  QR Finder - Test Suite\n";
echo "================================\n\n";

// Test 1: PHP Version
if (PHP_VERSION_ID >= 80100) {
    $success[] = "PHP version: " . PHP_VERSION;
} else {
    $errors[] = "PHP 8.1+ required. Current: " . PHP_VERSION;
}

// Test 2: Required Extensions
$requiredExtensions = ['pdo', 'pdo_mysql', 'gd', 'mbstring', 'openssl', 'json', 'curl'];
foreach ($requiredExtensions as $ext) {
    if (extension_loaded($ext)) {
        $success[] = "Extension '$ext' is loaded";
    } else {
        $errors[] = "Required extension '$ext' is not loaded";
    }
}

// Test 3: GD Extension with required formats
if (extension_loaded('gd')) {
    $gdInfo = gd_info();
    if ($gdInfo['PNG Support']) {
        $success[] = "GD PNG support enabled";
    } else {
        $errors[] = "GD PNG support not enabled";
    }
}

// Test 4: File permissions
$writableDirs = ['storage', 'storage/qr_codes', 'storage/logs'];
foreach ($writableDirs as $dir) {
    if (is_dir($dir)) {
        if (is_writable($dir)) {
            $success[] = "Directory '$dir' is writable";
        } else {
            $errors[] = "Directory '$dir' is not writable";
        }
    } else {
        $warnings[] = "Directory '$dir' does not exist";
    }
}

// Test 5: Configuration files
if (file_exists('.env')) {
    $success[] = ".env file exists";
    
    // Test 6: Database connection
    $env = parse_ini_file('.env');
    if ($env) {
        try {
            $pdo = new PDO(
                "mysql:host={$env['DB_HOST']};dbname={$env['DB_NAME']};charset=utf8mb4",
                $env['DB_USER'],
                $env['DB_PASS'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            $success[] = "Database connection successful";
            
            // Test 7: Check tables
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            $requiredTables = ['users', 'objects', 'qr_scans', 'notifications', 'payments'];
            foreach ($requiredTables as $table) {
                if (in_array($table, $tables)) {
                    $success[] = "Table '$table' exists";
                } else {
                    $errors[] = "Required table '$table' does not exist";
                }
            }
        } catch (PDOException $e) {
            $errors[] = "Database connection failed: " . $e->getMessage();
        }
    } else {
        $errors[] = "Could not parse .env file";
    }
} else {
    $errors[] = ".env file does not exist. Run install.php first.";
}

// Test 8: Composer autoload
if (file_exists('vendor/autoload.php')) {
    $success[] = "Composer autoload exists";
    
    require_once 'vendor/autoload.php';
    
    // Test 9: Required packages
    $requiredPackages = [
        'Stripe\\Stripe' => 'stripe/stripe-php',
        'Endroid\\QrCode\\QrCode' => 'endroid/qr-code',
        'PHPMailer\\PHPMailer\\PHPMailer' => 'phpmailer/phpmailer',
        'Dotenv\\Dotenv' => 'vlucas/phpdotenv',
        'Firebase\\JWT\\JWT' => 'firebase/php-jwt',
        'Ramsey\\Uuid\\Uuid' => 'ramsey/uuid'
    ];
    
    foreach ($requiredPackages as $class => $package) {
        if (class_exists($class)) {
            $success[] = "Package '$package' is installed";
        } else {
            $errors[] = "Package '$package' is not installed";
        }
    }
} else {
    $errors[] = "Composer autoload not found. Run 'composer install'.";
}

// Test 10: SSL/TLS for production
if (extension_loaded('openssl')) {
    $success[] = "OpenSSL extension is loaded";
} else {
    $warnings[] = "OpenSSL extension is not loaded (required for HTTPS)";
}

// Print results
echo "SUCCESS (" . count($success) . "):\n";
echo str_repeat("-", 40) . "\n";
foreach ($success as $msg) {
    echo "✓ $msg\n";
}

if (!empty($warnings)) {
    echo "\nWARNINGS (" . count($warnings) . "):\n";
    echo str_repeat("-", 40) . "\n";
    foreach ($warnings as $msg) {
        echo "⚠ $msg\n";
    }
}

if (!empty($errors)) {
    echo "\nERRORS (" . count($errors) . "):\n";
    echo str_repeat("-", 40) . "\n";
    foreach ($errors as $msg) {
        echo "✗ $msg\n";
    }
}

echo "\n================================\n";

if (empty($errors)) {
    echo "  All tests passed!\n";
    exit(0);
} else {
    echo "  Some tests failed.\n";
    exit(1);
}
