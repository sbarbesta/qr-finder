<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - QR Finder</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/dashboard.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body class="dashboard-page">
    <nav class="navbar dashboard-nav">
        <div class="container">
            <a href="/dashboard" class="logo">QR Finder</a>
            <div class="nav-right">
                <div class="notifications-wrapper">
                    <button id="notifications-btn" class="icon-btn">
                        🔔
                        <span id="notification-count" class="badge" style="display: none;">0</span>
                    </button>
                    <div id="notifications-dropdown" class="dropdown" style="display: none;">
                        <div class="dropdown-header">
                            <h4>Notifiche</h4>
                            <button id="mark-all-read">Segna tutte come lette</button>
                        </div>
                        <div id="notifications-list" class="notifications-list">
                            <p class="empty">Nessuna notifica</p>
                        </div>
                    </div>
                </div>
                <div class="user-menu-wrapper">
                    <button id="user-menu-btn" class="user-btn">
                        <span id="user-name">Utente</span>
                        <span class="dropdown-arrow">▼</span>
                    </button>
                    <div id="user-dropdown" class="dropdown" style="display: none;">
                        <a href="/dashboard/profile">Profilo</a>
                        <a href="/dashboard/settings">Impostazioni</a>
                        <hr>
                        <a href="#" id="logout-btn">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <main class="dashboard-main">
        <div class="container">
            <div class="dashboard-header">
                <h1>I miei oggetti</h1>
                <button id="add-object-btn" class="btn-primary">+ Aggiungi Oggetto</button>
            </div>

            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-value" id="total-objects">0</div>
                    <div class="stat-label">Oggetti</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="tracked-objects">0</div>
                    <div class="stat-label">Tracciati</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="notifications-count">0</div>
                    <div class="stat-label">Notifiche</div>
                </div>
            </div>

            <div class="dashboard-content">
                <div class="objects-section">
                    <h2>Lista Oggetti</h2>
                    <div id="objects-list" class="objects-grid">
                        <div class="loading">Caricamento...</div>
                    </div>
                </div>

                <div class="map-section">
                    <h2>Mappa Oggetti</h2>
                    <div id="objects-map" class="map-container"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- Add Object Modal -->
    <div id="add-object-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Aggiungi Nuovo Oggetto</h2>
                <button class="close-btn">&times;</button>
            </div>
            <form id="add-object-form">
                <div class="form-group">
                    <label for="object-name">Nome Oggetto *</label>
                    <input type="text" id="object-name" name="name" required placeholder="Es. Chiavi di casa">
                </div>
                <div class="form-group">
                    <label for="object-category">Categoria</label>
                    <select id="object-category" name="category">
                        <option value="keys">Chiavi</option>
                        <option value="smartphone">Smartphone</option>
                        <option value="bicycle">Bicicletta</option>
                        <option value="wallet">Portafoglio</option>
                        <option value="laptop">Laptop</option>
                        <option value="tablet">Tablet</option>
                        <option value="bag">Borsa/Zaino</option>
                        <option value="pet">Animale</option>
                        <option value="other">Altro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="object-description">Descrizione</label>
                    <textarea id="object-description" name="description" rows="3" placeholder="Descrizione opzionale dell'oggetto"></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-secondary" id="cancel-add">Annulla</button>
                    <button type="submit" class="btn-primary">Genera QR Code</button>
                </div>
            </form>
        </div>
    </div>

    <!-- QR Code Modal -->
    <div id="qr-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2>QR Code Generato!</h2>
                <button class="close-btn">&times;</button>
            </div>
            <div class="qr-preview">
                <img id="qr-image" src="" alt="QR Code">
                <p class="qr-code">Codice: <span id="qr-short-code"></span></p>
            </div>
            <div class="modal-actions">
                <button id="purchase-label-btn" class="btn-primary">Acquista Etichetta (€5)</button>
                <button id="download-qr-btn" class="btn-secondary" disabled>Scarica QR</button>
            </div>
            <p class="modal-note">Acquista l'etichetta per scaricare il QR code e ricevere notifiche quando l'oggetto viene trovato.</p>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="payment-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Acquista Etichetta</h2>
                <button class="close-btn">&times;</button>
            </div>
            <div class="payment-info">
                <p>Etichetta per: <strong id="payment-object-name"></strong></p>
                <p class="price">€5.00</p>
            </div>
            <form id="payment-form">
                <div id="card-element"></div>
                <div id="card-errors" role="alert"></div>
                <button type="submit" class="btn-primary btn-full">Paga Ora</button>
            </form>
        </div>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://js.stripe.com/v3/"></script>
    <script src="/assets/js/dashboard.js"></script>
</body>
</html>
