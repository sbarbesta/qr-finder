<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifica Email - QR Finder</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <a href="/" class="logo">QR Finder</a>
                <h1>Verifica Email</h1>
            </div>

            <div id="message-container">
                <div class="loading">Verifica in corso...</div>
            </div>

            <div class="auth-footer">
                <a href="/login" class="btn-primary btn-full" style="display: none;" id="login-btn">Vai al Login</a>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', async function() {
            const urlParams = new URLSearchParams(window.location.search);
            const token = urlParams.get('token');
            const container = document.getElementById('message-container');
            const loginBtn = document.getElementById('login-btn');
            
            if (!token) {
                container.innerHTML = '<div class="error-message">Token mancante. Controlla il link nella tua email.</div>';
                return;
            }
            
            try {
                const response = await fetch(`/api/auth/verify-email?token=${token}`);
                const data = await response.json();
                
                if (data.success) {
                    container.innerHTML = '<div class="success-message">Email verificata con successo! Il tuo account è ora attivo.</div>';
                    loginBtn.style.display = 'block';
                } else {
                    container.innerHTML = `<div class="error-message">${data.error || 'Errore durante la verifica.'}</div>`;
                }
            } catch (error) {
                container.innerHTML = '<div class="error-message">Errore di connessione. Riprova più tardi.</div>';
            }
        });
    </script>
</body>
</html>
