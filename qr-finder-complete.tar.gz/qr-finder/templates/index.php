<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Finder - Trova i tuoi oggetti smarriti</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="/" class="logo">QR Finder</a>
            <div class="nav-links">
                <a href="/login">Accedi</a>
                <a href="/register" class="btn-primary">Registrati</a>
            </div>
        </div>
    </nav>

    <header class="hero">
        <div class="container">
            <h1>Non perdere mai più i tuoi oggetti</h1>
            <p class="lead">QR Finder ti aiuta a ritrovare chiavi, smartphone, biciclette e altri oggetti personali. Genera QR code univoci, attaccali ai tuoi oggetti e ricevi notifiche quando vengono trovati.</p>
            <div class="cta-buttons">
                <a href="/register" class="btn-large">Inizia Gratuitamente</a>
                <a href="#how-it-works" class="btn-secondary">Come Funziona</a>
            </div>
        </div>
    </header>

    <section id="features" class="features">
        <div class="container">
            <h2>Caratteristiche</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3>QR Code Univoci</h3>
                    <p>Genera QR code personalizzati per ogni tuo oggetto. Ogni codice è collegato al tuo account.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📍</div>
                    <h3>Geolocalizzazione</h3>
                    <p>Quando qualcuno scannerizza il tuo QR code, ricevi la posizione esatta dell'oggetto.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔔</div>
                    <h3>Notifiche Istantanee</h3>
                    <p>Ricevi email e notifiche sul sito quando i tuoi oggetti vengono trovati.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🗺️</div>
                    <h3>Mappa Interattiva</h3>
                    <p>Visualizza sulla mappa dove si trovano i tuoi oggetti in tempo reale.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🖨️</div>
                    <h3>Etichette Pronte</h3>
                    <p>Acquista etichette QR stampabili e resistenti da attaccare ai tuoi oggetti.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <h3>Privacy Garantita</h3>
                    <p>I tuoi dati personali sono protetti. I trovanti non vedono le tue informazioni.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <h2>Come Funziona</h2>
            <div class="steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <h3>Registrati</h3>
                    <p>Crea un account gratuito su QR Finder in pochi secondi.</p>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <h3>Aggiungi Oggetti</h3>
                    <p>Registra i tuoi oggetti importanti e genera QR code univoci.</p>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <h3>Attacca le Etichette</h3>
                    <p>Stampa e attacca le etichette QR ai tuoi oggetti.</p>
                </div>
                <div class="step">
                    <div class="step-number">4</div>
                    <h3>Rimani Tranquillo</h3>
                    <p>Se perdi qualcosa, riceverai una notifica quando viene trovata.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="pricing" class="pricing">
        <div class="container">
            <h2>Prezzi</h2>
            <div class="pricing-grid">
                <div class="pricing-card">
                    <h3>Gratuito</h3>
                    <div class="price">€0</div>
                    <ul>
                        <li>Fino a 3 oggetti</li>
                        <li>QR code digitali</li>
                        <li>Notifiche email</li>
                        <li>Geolocalizzazione</li>
                    </ul>
                    <a href="/register" class="btn-primary">Inizia</a>
                </div>
                <div class="pricing-card featured">
                    <div class="badge">Più Popolare</div>
                    <h3>Premium</h3>
                    <div class="price">€5<span>/etichetta</span></div>
                    <ul>
                        <li>Oggetti illimitati</li>
                        <li>QR code digitali</li>
                        <li>Etichette stampabili</li>
                        <li>Notifiche email</li>
                        <li>Geolocalizzazione avanzata</li>
                        <li>Supporto prioritario</li>
                    </ul>
                    <a href="/register" class="btn-primary">Acquista Etichette</a>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>QR Finder</h4>
                    <p>La soluzione intelligente per trovare i tuoi oggetti smarriti.</p>
                </div>
                <div class="footer-section">
                    <h4>Link Utili</h4>
                    <ul>
                        <li><a href="/login">Accedi</a></li>
                        <li><a href="/register">Registrati</a></li>
                        <li><a href="#how-it-works">Come Funziona</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contatti</h4>
                    <p>Email: support@qr-finder.com</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
            </div>
        </div>
    </footer>

    <script src="/assets/js/main.js"></script>
</body>
</html>
