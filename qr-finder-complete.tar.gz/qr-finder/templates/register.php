<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrati - QR Finder</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <a href="/" class="logo">QR Finder</a>
                <h1>Crea un account</h1>
                <p>Inizia a proteggere i tuoi oggetti</p>
            </div>

            <form id="register-form" class="auth-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">Nome</label>
                        <input type="text" id="first_name" name="first_name" required placeholder="Il tuo nome">
                    </div>
                    <div class="form-group">
                        <label for="last_name">Cognome</label>
                        <input type="text" id="last_name" name="last_name" required placeholder="Il tuo cognome">
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required placeholder="La tua email">
                </div>

                <div class="form-group">
                    <label for="phone">Telefono (opzionale)</label>
                    <input type="tel" id="phone" name="phone" placeholder="Il tuo numero di telefono">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required placeholder="Crea una password" minlength="8">
                    <small class="form-hint">Almeno 8 caratteri</small>
                </div>

                <div class="form-group">
                    <label for="password_confirm">Conferma Password</label>
                    <input type="password" id="password_confirm" name="password_confirm" required placeholder="Conferma la password">
                </div>

                <div class="form-group">
                    <label class="checkbox">
                        <input type="checkbox" name="terms" id="terms" required>
                        <span>Accetto i <a href="#" target="_blank">Termini di Servizio</a> e la <a href="#" target="_blank">Privacy Policy</a></span>
                    </label>
                </div>

                <button type="submit" class="btn-primary btn-full">Registrati</button>
            </form>

            <div id="error-message" class="error-message" style="display: none;"></div>
            <div id="success-message" class="success-message" style="display: none;"></div>

            <div class="auth-footer">
                <p>Hai già un account? <a href="/login">Accedi</a></p>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('register-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const firstName = document.getElementById('first_name').value;
            const lastName = document.getElementById('last_name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const password = document.getElementById('password').value;
            const passwordConfirm = document.getElementById('password_confirm').value;
            const errorDiv = document.getElementById('error-message');
            const successDiv = document.getElementById('success-message');
            
            errorDiv.style.display = 'none';
            successDiv.style.display = 'none';
            
            // Validation
            if (password !== passwordConfirm) {
                errorDiv.textContent = 'Le password non coincidono';
                errorDiv.style.display = 'block';
                return;
            }
            
            if (password.length < 8) {
                errorDiv.textContent = 'La password deve essere di almeno 8 caratteri';
                errorDiv.style.display = 'block';
                return;
            }
            
            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        first_name: firstName,
                        last_name: lastName,
                        email: email,
                        phone: phone || null,
                        password: password
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Store session token
                    localStorage.setItem('session_token', data.data.session_token);
                    localStorage.setItem('user', JSON.stringify(data.data.user));
                    
                    successDiv.textContent = 'Registrazione completata! Reindirizzamento...';
                    successDiv.style.display = 'block';
                    
                    setTimeout(() => {
                        window.location.href = '/dashboard';
                    }, 1500);
                } else {
                    errorDiv.textContent = data.error || 'Errore durante la registrazione';
                    errorDiv.style.display = 'block';
                }
            } catch (error) {
                errorDiv.textContent = 'Errore di connessione. Riprova più tardi.';
                errorDiv.style.display = 'block';
            }
        });
    </script>
</body>
</html>
