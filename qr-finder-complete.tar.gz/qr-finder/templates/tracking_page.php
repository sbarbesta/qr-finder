<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/tracking.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body class="tracking-page">
    <nav class="navbar simple-nav">
        <div class="container">
            <a href="/" class="logo">QR Finder</a>
        </div>
    </nav>

    <main class="tracking-main">
        <div class="container">
            <div class="tracking-card">
                <div class="tracking-header">
                    <div class="found-icon">📍</div>
                    <h1>Hai trovato un oggetto!</h1>
                    <p class="object-name"><?php echo $objectName; ?></p>
                    <span class="category-badge"><?php echo ucfirst($category); ?></span>
                </div>

                <?php if ($description): ?>
                <div class="object-description">
                    <p><?php echo $description; ?></p>
                </div>
                <?php endif; ?>

                <div class="tracking-actions">
                    <div class="action-section">
                        <h2>Aiuta il proprietario</h2>
                        <p>Per aiutare il proprietario a ritrovare il suo oggetto, puoi:</p>
                        
                        <div class="action-buttons">
                            <button id="share-location-btn" class="btn-primary btn-large">
                                📍 Condividi la tua posizione
                            </button>
                            <button id="contact-owner-btn" class="btn-secondary btn-large">
                                ✉️ Contatta il proprietario
                            </button>
                        </div>
                    </div>
                </div>

                <div id="location-status" class="status-message" style="display: none;"></div>

                <div id="contact-form-section" class="contact-section" style="display: none;">
                    <h3>Invia un messaggio al proprietario</h3>
                    <form id="contact-form">
                        <div class="form-group">
                            <label for="finder-name">Il tuo nome (opzionale)</label>
                            <input type="text" id="finder-name" name="name" placeholder="Come ti chiami">
                        </div>
                        <div class="form-group">
                            <label for="finder-email">La tua email (opzionale)</label>
                            <input type="email" id="finder-email" name="email" placeholder="La tua email">
                        </div>
                        <div class="form-group">
                            <label for="finder-phone">Il tuo telefono (opzionale)</label>
                            <input type="tel" id="finder-phone" name="phone" placeholder="Il tuo numero di telefono">
                        </div>
                        <div class="form-group">
                            <label for="finder-message">Messaggio *</label>
                            <textarea id="finder-message" name="message" rows="4" required placeholder="Descrivi dove hai trovato l'oggetto o come puoi essere contattato..."></textarea>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-secondary" id="cancel-contact">Annulla</button>
                            <button type="submit" class="btn-primary">Invia Messaggio</button>
                        </div>
                    </form>
                </div>

                <div class="tracking-info">
                    <div class="info-box">
                        <h3>Cosa succede ora?</h3>
                        <ul>
                            <li>Il proprietario riceverà una notifica che il suo oggetto è stato trovato</li>
                            <li>Se condividi la tua posizione, il proprietario vedrà dove si trova l'oggetto</li>
                            <li>Puoi anche contattare direttamente il proprietario tramite il form</li>
                            <li>I tuoi dati personali rimangono privati</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="simple-footer">
        <div class="container">
            <p>Powered by <a href="/">QR Finder</a> - La soluzione per trovare oggetti smarriti</p>
        </div>
    </footer>

    <script>
        const shortCode = '<?php echo $shortCode; ?>';
        
        document.getElementById('share-location-btn').addEventListener('click', function() {
            const statusDiv = document.getElementById('location-status');
            statusDiv.style.display = 'block';
            statusDiv.textContent = 'Richiesta posizione in corso...';
            statusDiv.className = 'status-message info';
            
            if ('geolocation' in navigator) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        // Send location to server
                        fetch('/r/' + shortCode, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            body: JSON.stringify({
                                latitude: position.coords.latitude,
                                longitude: position.coords.longitude,
                                accuracy: position.coords.accuracy
                            })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                statusDiv.textContent = 'Grazie! La posizione è stata condivisa con il proprietario.';
                                statusDiv.className = 'status-message success';
                                document.getElementById('share-location-btn').disabled = true;
                                document.getElementById('share-location-btn').textContent = '✓ Posizione Condivisa';
                            } else {
                                statusDiv.textContent = 'Errore: ' + (data.error || 'Impossibile inviare la posizione');
                                statusDiv.className = 'status-message error';
                            }
                        })
                        .catch(error => {
                            statusDiv.textContent = 'Errore di connessione. Riprova più tardi.';
                            statusDiv.className = 'status-message error';
                        });
                    },
                    function(error) {
                        let errorMsg = 'Impossibile ottenere la posizione.';
                        switch(error.code) {
                            case error.PERMISSION_DENIED:
                                errorMsg = 'Hai negato l\'accesso alla posizione. Per favore abilita i permessi e riprova.';
                                break;
                            case error.POSITION_UNAVAILABLE:
                                errorMsg = 'Informazioni sulla posizione non disponibili.';
                                break;
                            case error.TIMEOUT:
                                errorMsg = 'Timeout nella richiesta di posizione.';
                                break;
                        }
                        statusDiv.textContent = errorMsg;
                        statusDiv.className = 'status-message error';
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
            } else {
                statusDiv.textContent = 'Il tuo browser non supporta la geolocalizzazione.';
                statusDiv.className = 'status-message error';
            }
        });
        
        document.getElementById('contact-owner-btn').addEventListener('click', function() {
            document.getElementById('contact-form-section').style.display = 'block';
            this.style.display = 'none';
        });
        
        document.getElementById('cancel-contact').addEventListener('click', function() {
            document.getElementById('contact-form-section').style.display = 'none';
            document.getElementById('contact-owner-btn').style.display = 'inline-block';
        });
        
        document.getElementById('contact-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                name: document.getElementById('finder-name').value,
                email: document.getElementById('finder-email').value,
                phone: document.getElementById('finder-phone').value,
                message: document.getElementById('finder-message').value
            };
            
            fetch('/r/' + shortCode + '/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                const statusDiv = document.getElementById('location-status');
                statusDiv.style.display = 'block';
                
                if (data.success) {
                    statusDiv.textContent = data.message;
                    statusDiv.className = 'status-message success';
                    document.getElementById('contact-form-section').style.display = 'none';
                    document.getElementById('contact-owner-btn').style.display = 'inline-block';
                    document.getElementById('contact-form').reset();
                } else {
                    statusDiv.textContent = data.error || 'Errore durante l\'invio del messaggio';
                    statusDiv.className = 'status-message error';
                }
            })
            .catch(error => {
                const statusDiv = document.getElementById('location-status');
                statusDiv.style.display = 'block';
                statusDiv.textContent = 'Errore di connessione. Riprova più tardi.';
                statusDiv.className = 'status-message error';
            });
        });
    </script>
</body>
</html>
