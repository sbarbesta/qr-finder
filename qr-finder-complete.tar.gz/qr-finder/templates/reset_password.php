<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reimposta Password - QR Finder</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <a href="/" class="logo">QR Finder</a>
                <h1>Reimposta Password</h1>
            </div>

            <div id="reset-form-container">
                <form id="reset-form" class="auth-form">
                    <div class="form-group">
                        <label for="password">Nuova Password</label>
                        <input type="password" id="password" name="password" required placeholder="Crea una nuova password" minlength="8">
                        <small class="form-hint">Almeno 8 caratteri</small>
                    </div>

                    <div class="form-group">
                        <label for="password_confirm">Conferma Password</label>
                        <input type="password" id="password_confirm" name="password_confirm" required placeholder="Conferma la password">
                    </div>

                    <button type="submit" class="btn-primary btn-full">Reimposta Password</button>
                </form>
            </div>

            <div id="message-container"></div>

            <div class="auth-footer">
                <a href="/login" class="btn-primary btn-full" style="display: none;" id="login-btn">Vai al Login</a>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const token = urlParams.get('token');
            const formContainer = document.getElementById('reset-form-container');
            const messageContainer = document.getElementById('message-container');
            const loginBtn = document.getElementById('login-btn');
            
            if (!token) {
                formContainer.style.display = 'none';
                messageContainer.innerHTML = '<div class="error-message">Token mancante. Richiedi un nuovo link di reset.</div>';
                return;
            }
            
            document.getElementById('reset-form').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const password = document.getElementById('password').value;
                const passwordConfirm = document.getElementById('password_confirm').value;
                
                if (password !== passwordConfirm) {
                    messageContainer.innerHTML = '<div class="error-message">Le password non coincidono</div>';
                    return;
                }
                
                if (password.length < 8) {
                    messageContainer.innerHTML = '<div class="error-message">La password deve essere di almeno 8 caratteri</div>';
                    return;
                }
                
                try {
                    const response = await fetch('/api/auth/reset-password', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ token, password })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        formContainer.style.display = 'none';
                        messageContainer.innerHTML = '<div class="success-message">Password reimpostata con successo!</div>';
                        loginBtn.style.display = 'block';
                    } else {
                        messageContainer.innerHTML = `<div class="error-message">${data.error || 'Errore durante il reset.'}</div>`;
                    }
                } catch (error) {
                    messageContainer.innerHTML = '<div class="error-message">Errore di connessione. Riprova più tardi.</div>';
                }
            });
        });
    </script>
</body>
</html>
