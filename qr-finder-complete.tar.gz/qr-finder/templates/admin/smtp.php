<?php
$pageTitle = 'Configurazione SMTP - Admin';
$activeMenu = 'smtp';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Configurazione SMTP</h1>
    <p class="subtitle">Configura il server email per l'invio delle notifiche</p>
</div>

<div class="settings-grid">
    <!-- SMTP Configuration -->
    <div class="settings-card">
        <h3><i class="fas fa-server"></i> Impostazioni Server</h3>
        
        <form id="smtpForm">
            <div class="form-row">
                <div class="form-group">
                    <label for="smtp_host">Host SMTP *</label>
                    <input type="text" id="smtp_host" name="smtp_host" value="<?php echo htmlspecialchars($settings['smtp_host'] ?? 'smtp.gmail.com'); ?>" required>
                    <small>Es: smtp.gmail.com, smtp.office365.com, mail.yourdomain.com</small>
                </div>
                
                <div class="form-group">
                    <label for="smtp_port">Porta *</label>
                    <input type="number" id="smtp_port" name="smtp_port" value="<?php echo $settings['smtp_port'] ?? '587'; ?>" required>
                    <small>Porte comuni: 25, 465 (SSL), 587 (TLS), 2525</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="smtp_encryption">Crittografia</label>
                    <select id="smtp_encryption" name="smtp_encryption">
                        <option value="tls" <?php echo ($settings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : ''; ?>>TLS (Consigliato)</option>
                        <option value="ssl" <?php echo ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                        <option value="" <?php echo ($settings['smtp_encryption'] ?? '') === '' ? 'selected' : ''; ?>>Nessuna</option>
                    </select>
                    <small>TLS è consigliato per la maggior parte dei server</small>
                </div>
                
                <div class="form-group">
                    <label for="smtp_auth">Autenticazione</label>
                    <select id="smtp_auth" name="smtp_auth">
                        <option value="true" selected>Sì</option>
                        <option value="false">No</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="smtp_username">Username / Email *</label>
                    <input type="text" id="smtp_username" name="smtp_username" value="<?php echo htmlspecialchars($settings['smtp_username'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="smtp_password">Password *</label>
                    <input type="password" id="smtp_password" name="smtp_password" value="<?php echo htmlspecialchars($settings['smtp_password'] ?? ''); ?>" required>
                    <small>Per Gmail, usa una "App Password"</small>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="smtp_from_email">Email Mittente *</label>
                    <input type="email" id="smtp_from_email" name="smtp_from_email" value="<?php echo htmlspecialchars($settings['smtp_from_email'] ?? 'noreply@qr-finder.com'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="smtp_from_name">Nome Mittente *</label>
                    <input type="text" id="smtp_from_name" name="smtp_from_name" value="<?php echo htmlspecialchars($settings['smtp_from_name'] ?? 'QR Finder'); ?>" required>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary">
                    <i class="fas fa-save"></i> Salva Configurazione
                </button>
            </div>
        </form>
    </div>
    
    <!-- Test Email -->
    <div class="settings-card">
        <h3><i class="fas fa-paper-plane"></i> Test Email</h3>
        
        <form id="testEmailForm">
            <div class="form-group">
                <label for="test_email">Email di Test</label>
                <input type="email" id="test_email" placeholder="Inserisci un'email per il test" required>
                <small>Inserisci un indirizzo email dove ricevere il messaggio di test</small>
            </div>
            
            <div class="test-info">
                <h4>Cosa verrà testato:</h4>
                <ul>
                    <li><i class="fas fa-check"></i> Connessione al server SMTP</li>
                    <li><i class="fas fa-check"></i> Autenticazione</li>
                    <li><i class="fas fa-check"></i> Invio email</li>
                    <li><i class="fas fa-check"></i> Formattazione HTML</li>
                </ul>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary btn-success">
                    <i class="fas fa-paper-plane"></i> Invia Email di Test
                </button>
            </div>
        </form>
        
        <div id="test-result" class="test-result" style="display:none;"></div>
    </div>
</div>

<!-- Quick Presets -->
<div class="presets-card">
    <h3><i class="fas fa-magic"></i> Configurazioni Rapide</h3>
    <div class="presets-grid">
        <button type="button" class="preset-btn" onclick="applyPreset('gmail')">
            <i class="fab fa-google"></i>
            <span>Gmail</span>
        </button>
        <button type="button" class="preset-btn" onclick="applyPreset('outlook')">
            <i class="fab fa-microsoft"></i>
            <span>Outlook</span>
        </button>
        <button type="button" class="preset-btn" onclick="applyPreset('yahoo')">
            <i class="fab fa-yahoo"></i>
            <span>Yahoo</span>
        </button>
        <button type="button" class="preset-btn" onclick="applyPreset('sendgrid')">
            <i class="fas fa-envelope"></i>
            <span>SendGrid</span>
        </button>
        <button type="button" class="preset-btn" onclick="applyPreset('mailgun')">
            <i class="fas fa-envelope"></i>
            <span>Mailgun</span>
        </button>
    </div>
</div>

<script>
const presets = {
    gmail: {
        host: 'smtp.gmail.com',
        port: '587',
        encryption: 'tls'
    },
    outlook: {
        host: 'smtp.office365.com',
        port: '587',
        encryption: 'tls'
    },
    yahoo: {
        host: 'smtp.mail.yahoo.com',
        port: '587',
        encryption: 'tls'
    },
    sendgrid: {
        host: 'smtp.sendgrid.net',
        port: '587',
        encryption: 'tls'
    },
    mailgun: {
        host: 'smtp.mailgun.org',
        port: '587',
        encryption: 'tls'
    }
};

document.addEventListener('DOMContentLoaded', function() {
    setupSmtpForm();
    setupTestForm();
});

function setupSmtpForm() {
    document.getElementById('smtpForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        try {
            const response = await fetch('/api/admin/smtp', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Configurazione SMTP salvata con successo!');
            } else {
                alert(result.error || 'Errore durante il salvataggio');
            }
        } catch (error) {
            console.error('Failed to save SMTP:', error);
            alert('Errore durante il salvataggio');
        }
    });
}

function setupTestForm() {
    document.getElementById('testEmailForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const testEmail = document.getElementById('test_email').value;
        const resultDiv = document.getElementById('test-result');
        
        // Get current SMTP settings
        const smtpData = {
            smtp_host: document.getElementById('smtp_host').value,
            smtp_port: document.getElementById('smtp_port').value,
            smtp_encryption: document.getElementById('smtp_encryption').value,
            smtp_username: document.getElementById('smtp_username').value,
            smtp_password: document.getElementById('smtp_password').value,
            smtp_from_email: document.getElementById('smtp_from_email').value,
            smtp_from_name: document.getElementById('smtp_from_name').value,
            test_email: testEmail
        };
        
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Invio email in corso...</div>';
        
        try {
            const response = await fetch('/api/admin/smtp/test', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify(smtpData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                resultDiv.innerHTML = '<div class="success"><i class="fas fa-check-circle"></i> Email di test inviata con successo! Controlla la tua casella di posta.</div>';
            } else {
                resultDiv.innerHTML = `<div class="error"><i class="fas fa-times-circle"></i> ${result.error || 'Errore durante l\'invio'}</div>`;
            }
        } catch (error) {
            resultDiv.innerHTML = '<div class="error"><i class="fas fa-times-circle"></i> Errore di connessione</div>';
        }
    });
}

function applyPreset(provider) {
    const preset = presets[provider];
    if (preset) {
        document.getElementById('smtp_host').value = preset.host;
        document.getElementById('smtp_port').value = preset.port;
        document.getElementById('smtp_encryption').value = preset.encryption;
        
        // Visual feedback
        event.target.classList.add('active');
        setTimeout(() => event.target.classList.remove('active'), 500);
    }
}
</script>

<style>
.settings-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
}

@media (max-width: 968px) {
    .settings-grid {
        grid-template-columns: 1fr;
    }
}

.test-info {
    background: #f9fafb;
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
}

.test-info h4 {
    margin-bottom: 10px;
    font-size: 14px;
}

.test-info ul {
    list-style: none;
    padding: 0;
}

.test-info li {
    padding: 5px 0;
    color: #374151;
}

.test-info li i {
    color: #10b981;
    margin-right: 8px;
}

.test-result {
    margin-top: 15px;
    padding: 15px;
    border-radius: 8px;
}

.test-result .success {
    background: #d1fae5;
    color: #065f46;
    padding: 15px;
    border-radius: 8px;
}

.test-result .error {
    background: #fee2e2;
    color: #991b1b;
    padding: 15px;
    border-radius: 8px;
}

.test-result .loading {
    color: #6b7280;
}

.presets-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.presets-card h3 {
    margin-bottom: 15px;
}

.presets-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 10px;
}

.preset-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    padding: 15px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: white;
    cursor: pointer;
    transition: all 0.3s;
}

.preset-btn:hover {
    border-color: #2563eb;
    background: #eff6ff;
}

.preset-btn.active {
    background: #2563eb;
    color: white;
    border-color: #2563eb;
}

.preset-btn i {
    font-size: 24px;
}

.btn-success {
    background: #10b981;
}

.btn-success:hover {
    background: #059669;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
