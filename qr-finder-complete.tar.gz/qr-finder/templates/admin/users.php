<?php
$pageTitle = 'Gestione Utenti - Admin';
$activeMenu = 'users';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Gestione Utenti</h1>
    <p class="subtitle">Cerca e gestisci gli utenti registrati</p>
</div>

<!-- Filters -->
<div class="filters-card">
    <div class="filters-header">
        <h3><i class="fas fa-filter"></i> Filtri di Ricerca</h3>
        <button class="btn-toggle" onclick="toggleFilters()">
            <i class="fas fa-chevron-up"></i>
        </button>
    </div>
    <div class="filters-body" id="filtersBody">
        <div class="filters-grid">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" id="filter-first-name" placeholder="Cerca per nome...">
            </div>
            <div class="form-group">
                <label>Cognome</label>
                <input type="text" id="filter-last-name" placeholder="Cerca per cognome...">
            </div>
            <div class="form-group">
                <label>Nickname</label>
                <input type="text" id="filter-nickname" placeholder="Cerca per nickname...">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="text" id="filter-email" placeholder="Cerca per email...">
            </div>
            <div class="form-group">
                <label>Città</label>
                <input type="text" id="filter-city" placeholder="Cerca per città...">
            </div>
            <div class="form-group">
                <label>Nazione</label>
                <select id="filter-country">
                    <option value="">Tutte le nazioni</option>
                    <?php foreach ($countries as $country): ?>
                    <option value="<?php echo $country['code']; ?>"><?php echo $country['name_it'] ?? $country['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Data Registrazione (Da)</label>
                <input type="date" id="filter-date-from">
            </div>
            <div class="form-group">
                <label>Data Registrazione (A)</label>
                <input type="date" id="filter-date-to">
            </div>
        </div>
        <div class="filters-actions">
            <button class="btn-secondary" onclick="resetFilters()">
                <i class="fas fa-undo"></i> Reset
            </button>
            <button class="btn-primary" onclick="applyFilters()">
                <i class="fas fa-search"></i> Cerca
            </button>
        </div>
    </div>
</div>

<!-- Results -->
<div class="results-card">
    <div class="results-header">
        <h3>Risultati <span id="results-count" class="badge">0</span></h3>
        <div class="results-actions">
            <select id="per-page" onchange="loadUsers()">
                <option value="20">20 per pagina</option>
                <option value="50">50 per pagina</option>
                <option value="100">100 per pagina</option>
            </select>
        </div>
    </div>
    
    <div class="table-responsive">
        <table class="data-table" id="users-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Avatar</th>
                    <th>Nome</th>
                    <th>Cognome</th>
                    <th>Nickname</th>
                    <th>Email</th>
                    <th>Città</th>
                    <th>Nazione</th>
                    <th>Data Reg.</th>
                    <th>Stato</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
                <tr class="loading-row">
                    <td colspan="11" class="text-center">Caricamento...</td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div class="pagination" id="pagination"></div>
</div>

<!-- Edit User Modal -->
<div class="modal" id="editUserModal" style="display:none;">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3>Modifica Utente</h3>
            <button class="close-btn" onclick="closeEditModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="editUserForm">
                <input type="hidden" id="edit-user-id">
                <div class="form-row">
                    <div class="form-group">
                        <label>Nome</label>
                        <input type="text" id="edit-first-name">
                    </div>
                    <div class="form-group">
                        <label>Cognome</label>
                        <input type="text" id="edit-last-name">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Nickname</label>
                        <input type="text" id="edit-nickname">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="edit-email">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Telefono</label>
                        <input type="tel" id="edit-phone">
                    </div>
                    <div class="form-group">
                        <label>Città</label>
                        <input type="text" id="edit-city">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Provincia</label>
                        <input type="text" id="edit-province">
                    </div>
                    <div class="form-group">
                        <label>Nazione</label>
                        <select id="edit-country">
                            <option value="">Seleziona...</option>
                            <?php foreach ($countries as $country): ?>
                            <option value="<?php echo $country['code']; ?>"><?php echo $country['name_it'] ?? $country['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>CAP</label>
                        <input type="text" id="edit-postal-code">
                    </div>
                    <div class="form-group">
                        <label>Lingua</label>
                        <select id="edit-language">
                            <option value="it">Italiano</option>
                            <option value="en">English</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Indirizzo</label>
                    <textarea id="edit-address" rows="2"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" id="edit-is-active">
                            <span>Account Attivo</span>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="checkbox">
                            <input type="checkbox" id="edit-newsletter">
                            <span>Iscritto Newsletter</span>
                        </label>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn-secondary" onclick="closeEditModal()">Annulla</button>
            <button class="btn-primary" onclick="saveUser()">Salva Modifiche</button>
        </div>
    </div>
</div>

<script>
let currentPage = 1;
let currentFilters = {};

document.addEventListener('DOMContentLoaded', function() {
    loadUsers();
});

function toggleFilters() {
    const body = document.getElementById('filtersBody');
    const icon = document.querySelector('.btn-toggle i');
    body.classList.toggle('collapsed');
    icon.classList.toggle('fa-chevron-up');
    icon.classList.toggle('fa-chevron-down');
}

function applyFilters() {
    currentFilters = {
        first_name: document.getElementById('filter-first-name').value,
        last_name: document.getElementById('filter-last-name').value,
        nickname: document.getElementById('filter-nickname').value,
        email: document.getElementById('filter-email').value,
        city: document.getElementById('filter-city').value,
        country: document.getElementById('filter-country').value,
        date_from: document.getElementById('filter-date-from').value,
        date_to: document.getElementById('filter-date-to').value,
    };
    currentPage = 1;
    loadUsers();
}

function resetFilters() {
    document.querySelectorAll('.filters-grid input, .filters-grid select').forEach(el => el.value = '');
    currentFilters = {};
    currentPage = 1;
    loadUsers();
}

async function loadUsers() {
    const perPage = document.getElementById('per-page').value;
    
    const params = new URLSearchParams({
        page: currentPage,
        per_page: perPage,
        ...currentFilters
    });
    
    try {
        const response = await fetch(`/api/admin/users?${params}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderUsers(data.data.users);
            renderPagination(data.data.total, data.data.per_page, data.data.page);
            document.getElementById('results-count').textContent = data.data.total;
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

function renderUsers(users) {
    const tbody = document.querySelector('#users-table tbody');
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" class="text-center">Nessun utente trovato</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>
                <img src="${user.avatar || '/assets/images/default-avatar.png'}" alt="" class="avatar-small">
            </td>
            <td>${escapeHtml(user.first_name)}</td>
            <td>${escapeHtml(user.last_name)}</td>
            <td>${escapeHtml(user.nickname || '-')}</td>
            <td>${escapeHtml(user.email)}</td>
            <td>${escapeHtml(user.city || '-')}</td>
            <td>${user.country_code || '-'}</td>
            <td>${formatDate(user.created_at)}</td>
            <td>
                <span class="status-badge ${user.is_active ? 'active' : 'inactive'}">
                    ${user.is_active ? 'Attivo' : 'Disattivato'}
                </span>
            </td>
            <td>
                <button class="btn-icon" onclick="editUser(${user.id})" title="Modifica">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon btn-danger" onclick="deleteUser(${user.id})" title="Elimina">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function renderPagination(total, perPage, page) {
    const totalPages = Math.ceil(total / perPage);
    const container = document.getElementById('pagination');
    
    let html = '';
    
    if (totalPages > 1) {
        html += `<button ${page === 1 ? 'disabled' : ''} onclick="goToPage(${page - 1})"><i class="fas fa-chevron-left"></i></button>`;
        
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
                html += `<button class="${i === page ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
            } else if (i === page - 3 || i === page + 3) {
                html += `<span>...</span>`;
            }
        }
        
        html += `<button ${page === totalPages ? 'disabled' : ''} onclick="goToPage(${page + 1})"><i class="fas fa-chevron-right"></i></button>`;
    }
    
    container.innerHTML = html;
}

function goToPage(page) {
    currentPage = page;
    loadUsers();
}

async function editUser(id) {
    try {
        const response = await fetch(`/api/admin/users/${id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const user = data.data;
            document.getElementById('edit-user-id').value = user.id;
            document.getElementById('edit-first-name').value = user.first_name || '';
            document.getElementById('edit-last-name').value = user.last_name || '';
            document.getElementById('edit-nickname').value = user.nickname || '';
            document.getElementById('edit-email').value = user.email || '';
            document.getElementById('edit-phone').value = user.phone || '';
            document.getElementById('edit-city').value = user.city || '';
            document.getElementById('edit-province').value = user.province || '';
            document.getElementById('edit-country').value = user.country_code || '';
            document.getElementById('edit-postal-code').value = user.postal_code || '';
            document.getElementById('edit-address').value = user.address || '';
            document.getElementById('edit-language').value = user.language || 'it';
            document.getElementById('edit-is-active').checked = user.is_active;
            document.getElementById('edit-newsletter').checked = user.newsletter_subscribed;
            
            document.getElementById('editUserModal').style.display = 'flex';
        }
    } catch (error) {
        console.error('Failed to load user:', error);
        alert('Errore durante il caricamento dell\'utente');
    }
}

function closeEditModal() {
    document.getElementById('editUserModal').style.display = 'none';
}

async function saveUser() {
    const id = document.getElementById('edit-user-id').value;
    const data = {
        first_name: document.getElementById('edit-first-name').value,
        last_name: document.getElementById('edit-last-name').value,
        nickname: document.getElementById('edit-nickname').value,
        email: document.getElementById('edit-email').value,
        phone: document.getElementById('edit-phone').value,
        city: document.getElementById('edit-city').value,
        province: document.getElementById('edit-province').value,
        country_code: document.getElementById('edit-country').value,
        postal_code: document.getElementById('edit-postal-code').value,
        address: document.getElementById('edit-address').value,
        language: document.getElementById('edit-language').value,
        is_active: document.getElementById('edit-is-active').checked,
        newsletter_subscribed: document.getElementById('edit-newsletter').checked,
    };
    
    try {
        const response = await fetch(`/api/admin/users/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            closeEditModal();
            loadUsers();
            alert('Utente aggiornato con successo');
        } else {
            alert(result.error || 'Errore durante il salvataggio');
        }
    } catch (error) {
        console.error('Failed to save user:', error);
        alert('Errore durante il salvataggio');
    }
}

async function deleteUser(id) {
    if (!confirm('Sei sicuro di voler eliminare questo utente? Questa azione non può essere annullata.')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/admin/users/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            loadUsers();
            alert('Utente eliminato con successo');
        } else {
            alert(result.error || 'Errore durante l\'eliminazione');
        }
    } catch (error) {
        console.error('Failed to delete user:', error);
        alert('Errore durante l\'eliminazione');
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT');
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
