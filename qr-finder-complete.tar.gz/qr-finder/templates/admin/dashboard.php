<?php
$pageTitle = 'Dashboard - Admin';
$activeMenu = 'dashboard';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Dashboard</h1>
    <p class="subtitle">Panoramica del sistema</p>
</div>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon users">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['total_users'] ?? 0); ?></h3>
            <p>Utenti Registrati</p>
            <a href="/admin/users" class="btn-go">VAI <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon qrcodes">
            <i class="fas fa-qrcode"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['total_qr_codes'] ?? 0); ?></h3>
            <p>QR Codes Generati</p>
            <a href="/admin/qrcodes" class="btn-go">VAI <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon revenue">
            <i class="fas fa-euro-sign"></i>
        </div>
        <div class="stat-info">
            <h3>€<?php echo number_format(($stats['total_revenue'] ?? 0) / 100, 2, ',', '.'); ?></h3>
            <p>Fatturato Totale</p>
            <span class="trend"><?php echo $stats['total_payments'] ?? 0; ?> pagamenti</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon scans">
            <i class="fas fa-map-marker-alt"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['scans_today'] ?? 0); ?></h3>
            <p>Scansioni Oggi</p>
            <span class="trend"><?php echo $stats['scans_this_month'] ?? 0; ?> questo mese</span>
        </div>
    </div>
</div>

<!-- Charts Section -->
<div class="charts-grid">
    <div class="chart-card">
        <div class="chart-header">
            <h3>Crescita Utenti</h3>
            <select id="user-growth-period" onchange="loadStatistics()">
                <option value="week">Ultima Settimana</option>
                <option value="month" selected>Ultimo Mese</option>
                <option value="year">Ultimo Anno</option>
            </select>
        </div>
        <canvas id="userGrowthChart"></canvas>
    </div>
    
    <div class="chart-card">
        <div class="chart-header">
            <h3>QR Codes Generati</h3>
            <select id="qr-growth-period" onchange="loadStatistics()">
                <option value="week">Ultima Settimana</option>
                <option value="month" selected>Ultimo Mese</option>
                <option value="year">Ultimo Anno</option>
            </select>
        </div>
        <canvas id="qrGrowthChart"></canvas>
    </div>
</div>

<!-- Additional Stats -->
<div class="stats-row">
    <div class="stat-box">
        <h4>Nuovi Utenti</h4>
        <div class="stat-values">
            <div>
                <span class="number"><?php echo $stats['new_users_today'] ?? 0; ?></span>
                <span class="label">Oggi</span>
            </div>
            <div>
                <span class="number"><?php echo $stats['new_users_this_week'] ?? 0; ?></span>
                <span class="label">Questa Settimana</span>
            </div>
            <div>
                <span class="number"><?php echo $stats['new_users_this_month'] ?? 0; ?></span>
                <span class="label">Questo Mese</span>
            </div>
        </div>
    </div>
    
    <div class="stat-box">
        <h4>Top Paesi</h4>
        <div id="topCountries" class="top-list">
            <div class="loading">Caricamento...</div>
        </div>
    </div>
    
    <div class="stat-box">
        <h4>Top Città</h4>
        <div id="topCities" class="top-list">
            <div class="loading">Caricamento...</div>
        </div>
    </div>
</div>

<script>
let userGrowthChart = null;
let qrGrowthChart = null;

document.addEventListener('DOMContentLoaded', function() {
    loadStatistics();
});

async function loadStatistics() {
    const period = document.getElementById('user-growth-period').value;
    
    try {
        const response = await fetch(`/api/admin/statistics?period=${period}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderUserGrowthChart(data.data.user_growth);
            renderQrGrowthChart(data.data.qr_generation);
            renderTopCountries(data.data.top_countries);
            renderTopCities(data.data.top_cities);
        }
    } catch (error) {
        console.error('Failed to load statistics:', error);
    }
}

function renderUserGrowthChart(data) {
    const ctx = document.getElementById('userGrowthChart').getContext('2d');
    
    if (userGrowthChart) {
        userGrowthChart.destroy();
    }
    
    userGrowthChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Nuovi Utenti',
                data: data.values,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                }
            }
        }
    });
}

function renderQrGrowthChart(data) {
    const ctx = document.getElementById('qrGrowthChart').getContext('2d');
    
    if (qrGrowthChart) {
        qrGrowthChart.destroy();
    }
    
    qrGrowthChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'QR Codes',
                data: data.values,
                backgroundColor: '#10b981'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                }
            }
        }
    });
}

function renderTopCountries(countries) {
    const container = document.getElementById('topCountries');
    
    if (!countries || countries.length === 0) {
        container.innerHTML = '<p class="empty">Nessun dato disponibile</p>';
        return;
    }
    
    container.innerHTML = countries.map(c => `
        <div class="top-item">
            <span class="name">${escapeHtml(c.name)}</span>
            <span class="count">${c.count}</span>
        </div>
    `).join('');
}

function renderTopCities(cities) {
    const container = document.getElementById('topCities');
    
    if (!cities || cities.length === 0) {
        container.innerHTML = '<p class="empty">Nessun dato disponibile</p>';
        return;
    }
    
    container.innerHTML = cities.map(c => `
        <div class="top-item">
            <span class="name">${escapeHtml(c.name)}</span>
            <span class="count">${c.count}</span>
        </div>
    `).join('');
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
