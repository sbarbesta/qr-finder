<?php
$pageTitle = 'Impostazioni Grafiche - Admin';
$activeMenu = 'branding';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Impostazioni Grafiche</h1>
    <p class="subtitle">Personalizza l'aspetto del tuo sito</p>
</div>

<div class="settings-grid">
    <!-- Logo & Images -->
    <div class="settings-card">
        <h3><i class="fas fa-images"></i> Logo e Immagini</h3>
        
        <div class="upload-section">
            <label>Logo del Sito</label>
            <div class="upload-box" id="logo-upload">
                <?php if (!empty($settings['site_logo'])): ?>
                <img src="/storage/<?php echo $settings['site_logo']; ?>" alt="Logo" class="upload-preview">
                <?php else: ?>
                <div class="upload-placeholder">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <span>Trascina qui il logo o clicca per selezionare</span>
                    <small>Formati supportati: PNG, JPG, SVG. Max 2MB</small>
                </div>
                <?php endif; ?>
                <input type="file" id="logo-file" accept="image/png,image/jpeg,image/svg+xml" hidden>
            </div>
            <button type="button" class="btn-secondary btn-small" onclick="document.getElementById('logo-file').click()">
                <i class="fas fa-upload"></i> Carica Logo
            </button>
        </div>
        
        <div class="upload-section">
            <label>Favicon</label>
            <div class="upload-box small" id="favicon-upload">
                <?php if (!empty($settings['site_favicon'])): ?>
                <img src="/storage/<?php echo $settings['site_favicon']; ?>" alt="Favicon" class="upload-preview">
                <?php else: ?>
                <div class="upload-placeholder">
                    <i class="fas fa-image"></i>
                    <span>32x32px ICO o PNG</span>
                </div>
                <?php endif; ?>
                <input type="file" id="favicon-file" accept="image/x-icon,image/png" hidden>
            </div>
            <button type="button" class="btn-secondary btn-small" onclick="document.getElementById('favicon-file').click()">
                <i class="fas fa-upload"></i> Carica Favicon
            </button>
        </div>
    </div>
    
    <!-- Colors -->
    <div class="settings-card">
        <h3><i class="fas fa-palette"></i> Colori</h3>
        
        <form id="brandingForm">
            <div class="color-grid">
                <div class="form-group">
                    <label>Colore Primario</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="primary_color" name="primary_color" value="<?php echo $settings['primary_color'] ?? '#2563eb'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['primary_color'] ?? '#2563eb'; ?>" readonly>
                    </div>
                    <small>Usato per pulsanti e link principali</small>
                </div>
                
                <div class="form-group">
                    <label>Colore Secondario</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="secondary_color" name="secondary_color" value="<?php echo $settings['secondary_color'] ?? '#10b981'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['secondary_color'] ?? '#10b981'; ?>" readonly>
                    </div>
                    <small>Usato per stati di successo</small>
                </div>
                
                <div class="form-group">
                    <label>Colore Sfondo</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="background_color" name="background_color" value="<?php echo $settings['background_color'] ?? '#ffffff'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['background_color'] ?? '#ffffff'; ?>" readonly>
                    </div>
                    <small>Sfondo principale del sito</small>
                </div>
                
                <div class="form-group">
                    <label>Colore Testo</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="text_color" name="text_color" value="<?php echo $settings['text_color'] ?? '#1f2937'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['text_color'] ?? '#1f2937'; ?>" readonly>
                    </div>
                    <small>Colore del testo principale</small>
                </div>
                
                <div class="form-group">
                    <label>Colore Link</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="link_color" name="link_color" value="<?php echo $settings['link_color'] ?? '#2563eb'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['link_color'] ?? '#2563eb'; ?>" readonly>
                    </div>
                    <small>Colore dei link</small>
                </div>
                
                <div class="form-group">
                    <label>Sfondo Footer</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="footer_background" name="footer_background" value="<?php echo $settings['footer_background'] ?? '#111827'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['footer_background'] ?? '#111827'; ?>" readonly>
                    </div>
                    <small>Sfondo del footer</small>
                </div>
                
                <div class="form-group">
                    <label>Testo Footer</label>
                    <div class="color-picker-wrapper">
                        <input type="color" id="footer_text_color" name="footer_text_color" value="<?php echo $settings['footer_text_color'] ?? '#ffffff'; ?>">
                        <input type="text" class="color-value" value="<?php echo $settings['footer_text_color'] ?? '#ffffff'; ?>" readonly>
                    </div>
                    <small>Colore testo nel footer</small>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn-secondary" onclick="resetColors()">Reset Default</button>
                <button type="submit" class="btn-primary">Salva Colori</button>
            </div>
        </form>
    </div>
</div>

<!-- Live Preview -->
<div class="preview-card">
    <h3><i class="fas fa-eye"></i> Anteprima Live</h3>
    <div class="live-preview" id="livePreview">
        <div class="preview-navbar">
            <span class="preview-logo">QR Finder</span>
            <nav>
                <a href="#">Home</a>
                <a href="#">Funzionalità</a>
                <a href="#">Prezzi</a>
            </nav>
        </div>
        <div class="preview-hero">
            <h1>Trova i tuoi oggetti smarriti</h1>
            <p>QR Finder ti aiuta a ritrovare chiavi, smartphone, biciclette e altri oggetti personali.</p>
            <button class="preview-btn-primary">Inizia Gratuitamente</button>
            <button class="preview-btn-secondary">Scopri di più</button>
        </div>
        <div class="preview-footer">
            <p>&copy; 2024 QR Finder. Tutti i diritti riservati.</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    setupColorPickers();
    setupFileUploads();
    setupForm();
    updatePreview();
});

function setupColorPickers() {
    document.querySelectorAll('input[type="color"]').forEach(picker => {
        picker.addEventListener('input', function() {
            this.nextElementSibling.value = this.value;
            updatePreview();
        });
    });
}

function setupFileUploads() {
    // Logo upload
    const logoFile = document.getElementById('logo-file');
    logoFile.addEventListener('change', function() {
        if (this.files.length > 0) {
            uploadFile(this.files[0], 'logo');
        }
    });
    
    // Favicon upload
    const faviconFile = document.getElementById('favicon-file');
    faviconFile.addEventListener('change', function() {
        if (this.files.length > 0) {
            uploadFile(this.files[0], 'favicon');
        }
    });
}

async function uploadFile(file, type) {
    const formData = new FormData();
    formData.append(type, file);
    
    try {
        const response = await fetch(`/api/admin/branding/upload-${type}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            },
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(`${type === 'logo' ? 'Logo' : 'Favicon'} caricato con successo!`);
            location.reload();
        } else {
            alert(result.error || 'Errore durante il caricamento');
        }
    } catch (error) {
        console.error('Upload failed:', error);
        alert('Errore durante il caricamento');
    }
}

function setupForm() {
    document.getElementById('brandingForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        try {
            const response = await fetch('/api/admin/branding', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Impostazioni grafiche salvate con successo!');
            } else {
                alert(result.error || 'Errore durante il salvataggio');
            }
        } catch (error) {
            console.error('Failed to save branding:', error);
            alert('Errore durante il salvataggio');
        }
    });
}

function updatePreview() {
    const preview = document.getElementById('livePreview');
    
    preview.style.setProperty('--primary-color', document.getElementById('primary_color').value);
    preview.style.setProperty('--secondary-color', document.getElementById('secondary_color').value);
    preview.style.setProperty('--background-color', document.getElementById('background_color').value);
    preview.style.setProperty('--text-color', document.getElementById('text_color').value);
    preview.style.setProperty('--link-color', document.getElementById('link_color').value);
    preview.style.setProperty('--footer-bg', document.getElementById('footer_background').value);
    preview.style.setProperty('--footer-text', document.getElementById('footer_text_color').value);
}

function resetColors() {
    if (confirm('Ripristinare i colori predefiniti?')) {
        document.getElementById('primary_color').value = '#2563eb';
        document.getElementById('secondary_color').value = '#10b981';
        document.getElementById('background_color').value = '#ffffff';
        document.getElementById('text_color').value = '#1f2937';
        document.getElementById('link_color').value = '#2563eb';
        document.getElementById('footer_background').value = '#111827';
        document.getElementById('footer_text_color').value = '#ffffff';
        
        document.querySelectorAll('input[type="color"]').forEach(picker => {
            picker.nextElementSibling.value = picker.value;
        });
        
        updatePreview();
    }
}
</script>

<style>
.settings-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
}

@media (max-width: 968px) {
    .settings-grid {
        grid-template-columns: 1fr;
    }
}

.upload-section {
    margin-bottom: 20px;
}

.upload-section label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
}

.upload-box {
    border: 2px dashed #d1d5db;
    border-radius: 8px;
    padding: 30px;
    text-align: center;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all 0.3s;
}

.upload-box:hover {
    border-color: #2563eb;
    background: #eff6ff;
}

.upload-box.small {
    padding: 20px;
    max-width: 150px;
}

.upload-placeholder i {
    font-size: 40px;
    color: #9ca3af;
    margin-bottom: 10px;
}

.upload-placeholder span {
    display: block;
    color: #374151;
    font-weight: 500;
}

.upload-placeholder small {
    color: #6b7280;
}

.upload-preview {
    max-width: 200px;
    max-height: 100px;
}

.color-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.color-picker-wrapper {
    display: flex;
    align-items: center;
    gap: 10px;
}

.color-picker-wrapper input[type="color"] {
    width: 50px;
    height: 40px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.color-value {
    flex: 1;
    padding: 8px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    font-family: monospace;
    font-size: 14px;
}

.preview-card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.preview-card h3 {
    margin-bottom: 15px;
}

.live-preview {
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    overflow: hidden;
}

.preview-navbar {
    background: var(--background-color, #fff);
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #e5e7eb;
}

.preview-logo {
    font-size: 20px;
    font-weight: bold;
    color: var(--primary-color, #2563eb);
}

.preview-navbar nav a {
    color: var(--text-color, #374151);
    text-decoration: none;
    margin-left: 20px;
}

.preview-navbar nav a:hover {
    color: var(--link-color, #2563eb);
}

.preview-hero {
    background: linear-gradient(135deg, var(--primary-color, #2563eb) 0%, #1d4ed8 100%);
    color: white;
    padding: 40px;
    text-align: center;
}

.preview-hero h1 {
    font-size: 28px;
    margin-bottom: 10px;
}

.preview-hero p {
    opacity: 0.9;
    margin-bottom: 20px;
}

.preview-btn-primary {
    background: white;
    color: var(--primary-color, #2563eb);
    border: none;
    padding: 10px 20px;
    border-radius: 6px;
    font-weight: 600;
    margin-right: 10px;
    cursor: pointer;
}

.preview-btn-secondary {
    background: transparent;
    color: white;
    border: 1px solid rgba(255,255,255,0.5);
    padding: 10px 20px;
    border-radius: 6px;
    cursor: pointer;
}

.preview-footer {
    background: var(--footer-bg, #111827);
    color: var(--footer-text, #fff);
    padding: 20px;
    text-align: center;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
