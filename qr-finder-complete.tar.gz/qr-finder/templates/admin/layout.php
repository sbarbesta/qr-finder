<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Admin - QR Finder'; ?></title>
    <link rel="stylesheet" href="/assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php if (isset($includeTinyMCE) && $includeTinyMCE): ?>
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <?php endif; ?>
</head>
<body class="admin-page">
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <a href="/admin" class="logo">
                    <i class="fas fa-qrcode"></i>
                    <span>QR Finder</span>
                </a>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li class="<?php echo $activeMenu === 'dashboard' ? 'active' : ''; ?>">
                        <a href="/admin">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'users' ? 'active' : ''; ?>">
                        <a href="/admin/users">
                            <i class="fas fa-users"></i>
                            <span>Utenti</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'qrcodes' ? 'active' : ''; ?>">
                        <a href="/admin/qrcodes">
                            <i class="fas fa-qrcode"></i>
                            <span>QR Codes</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'pages' ? 'active' : ''; ?>">
                        <a href="/admin/pages">
                            <i class="fas fa-file-alt"></i>
                            <span>Pagine</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'newsletter' ? 'active' : ''; ?>">
                        <a href="/admin/newsletter">
                            <i class="fas fa-envelope"></i>
                            <span>Newsletter</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'messages' ? 'active' : ''; ?>">
                        <a href="/admin/messages">
                            <i class="fas fa-comments"></i>
                            <span>Messaggi</span>
                            <span class="badge" id="unread-messages-count" style="display:none;">0</span>
                        </a>
                    </li>
                    <li class="nav-section">Configurazione</li>
                    <li class="<?php echo $activeMenu === 'seo' ? 'active' : ''; ?>">
                        <a href="/admin/seo">
                            <i class="fas fa-search"></i>
                            <span>SEO</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'branding' ? 'active' : ''; ?>">
                        <a href="/admin/branding">
                            <i class="fas fa-paint-brush"></i>
                            <span>Grafica</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'smtp' ? 'active' : ''; ?>">
                        <a href="/admin/smtp">
                            <i class="fas fa-server"></i>
                            <span>SMTP</span>
                        </a>
                    </li>
                    <li class="<?php echo $activeMenu === 'profile' ? 'active' : ''; ?>">
                        <a href="/admin/profile">
                            <i class="fas fa-user-cog"></i>
                            <span>Profilo</span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <a href="/" target="_blank">
                    <i class="fas fa-external-link-alt"></i>
                    <span>Vedi Sito</span>
                </a>
                <a href="#" onclick="logout(); return false;">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-main">
            <header class="admin-header">
                <button class="sidebar-toggle" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="header-right">
                    <span class="admin-name"><?php echo htmlspecialchars($adminName ?? 'Admin'); ?></span>
                </div>
            </header>
            
            <div class="admin-content">
                <?php echo $content ?? ''; ?>
            </div>
        </main>
    </div>
    
    <script src="/assets/js/admin.js"></script>
    <script>
        function toggleSidebar() {
            document.querySelector('.admin-wrapper').classList.toggle('sidebar-collapsed');
        }
        
        function logout() {
            fetch('/api/auth/logout', { method: 'POST' })
                .then(() => {
                    localStorage.removeItem('session_token');
                    window.location.href = '/login';
                });
        }
    </script>
</body>
</html>
