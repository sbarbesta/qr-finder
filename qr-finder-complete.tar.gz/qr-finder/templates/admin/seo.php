<?php
$pageTitle = 'Impostazioni SEO - Admin';
$activeMenu = 'seo';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Impostazioni SEO</h1>
    <p class="subtitle">Gestisci i meta tag per il posizionamento sui motori di ricerca</p>
</div>

<div class="settings-card">
    <div class="settings-tabs">
        <button class="tab-btn active" onclick="switchTab('it')">
            <img src="/assets/images/flags/it.png" alt="IT" class="flag-icon"> Italiano
        </button>
        <button class="tab-btn" onclick="switchTab('en')">
            <img src="/assets/images/flags/gb.png" alt="EN" class="flag-icon"> English
        </button>
    </div>
    
    <form id="seoForm">
        <!-- Italian -->
        <div class="tab-content active" id="tab-it">
            <div class="form-group">
                <label for="title_it">Title (Titolo del sito)</label>
                <input type="text" id="title_it" name="seo_title_it" value="<?php echo htmlspecialchars($settings['seo_title_it'] ?? ''); ?>" maxlength="70">
                <small class="form-hint">Max 70 caratteri. Appare nella scheda del browser e nei risultati di ricerca.</small>
                <div class="char-counter"><span id="title_it_count">0</span>/70</div>
            </div>
            
            <div class="form-group">
                <label for="description_it">Meta Description</label>
                <textarea id="description_it" name="seo_description_it" rows="4" maxlength="160"><?php echo htmlspecialchars($settings['seo_description_it'] ?? ''); ?></textarea>
                <small class="form-hint">Max 160 caratteri. Descrizione che appare nei risultati di ricerca.</small>
                <div class="char-counter"><span id="description_it_count">0</span>/160</div>
            </div>
            
            <div class="form-group">
                <label for="keywords_it">Meta Keywords</label>
                <input type="text" id="keywords_it" name="seo_keywords_it" value="<?php echo htmlspecialchars($settings['seo_keywords_it'] ?? ''); ?>">
                <small class="form-hint">Parole chiave separate da virgola. Es: qr code, trova oggetti, chiavi smarrite</small>
            </div>
            
            <div class="preview-box">
                <h4>Anteprima nei risultati di ricerca</h4>
                <div class="google-preview">
                    <div class="preview-title" id="preview_title_it"><?php echo htmlspecialchars($settings['seo_title_it'] ?? 'QR Finder'); ?></div>
                    <div class="preview-url"><?php echo $_SERVER['HTTP_HOST'] ?? 'qr-finder.com'; ?></div>
                    <div class="preview-description" id="preview_description_it"><?php echo htmlspecialchars($settings['seo_description_it'] ?? ''); ?></div>
                </div>
            </div>
        </div>
        
        <!-- English -->
        <div class="tab-content" id="tab-en">
            <div class="form-group">
                <label for="title_en">Title (Site Title)</label>
                <input type="text" id="title_en" name="seo_title_en" value="<?php echo htmlspecialchars($settings['seo_title_en'] ?? ''); ?>" maxlength="70">
                <small class="form-hint">Max 70 characters. Appears in browser tab and search results.</small>
                <div class="char-counter"><span id="title_en_count">0</span>/70</div>
            </div>
            
            <div class="form-group">
                <label for="description_en">Meta Description</label>
                <textarea id="description_en" name="seo_description_en" rows="4" maxlength="160"><?php echo htmlspecialchars($settings['seo_description_en'] ?? ''); ?></textarea>
                <small class="form-hint">Max 160 characters. Description that appears in search results.</small>
                <div class="char-counter"><span id="description_en_count">0</span>/160</div>
            </div>
            
            <div class="form-group">
                <label for="keywords_en">Meta Keywords</label>
                <input type="text" id="keywords_en" name="seo_keywords_en" value="<?php echo htmlspecialchars($settings['seo_keywords_en'] ?? ''); ?>">
                <small class="form-hint">Keywords separated by comma. Ex: qr code, find items, lost keys</small>
            </div>
            
            <div class="preview-box">
                <h4>Search Results Preview</h4>
                <div class="google-preview">
                    <div class="preview-title" id="preview_title_en"><?php echo htmlspecialchars($settings['seo_title_en'] ?? 'QR Finder'); ?></div>
                    <div class="preview-url"><?php echo $_SERVER['HTTP_HOST'] ?? 'qr-finder.com'; ?></div>
                    <div class="preview-description" id="preview_description_en"><?php echo htmlspecialchars($settings['seo_description_en'] ?? ''); ?></div>
                </div>
            </div>
        </div>
        
        <div class="form-actions">
            <button type="button" class="btn-secondary" onclick="resetForm()">Reset</button>
            <button type="submit" class="btn-primary">Salva Impostazioni</button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    setupCounters();
    setupPreviews();
    setupForm();
});

function switchTab(lang) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById('tab-' + lang).classList.add('active');
}

function setupCounters() {
    ['it', 'en'].forEach(lang => {
        const titleInput = document.getElementById('title_' + lang);
        const descInput = document.getElementById('description_' + lang);
        
        titleInput.addEventListener('input', function() {
            document.getElementById('title_' + lang + '_count').textContent = this.value.length;
        });
        
        descInput.addEventListener('input', function() {
            document.getElementById('description_' + lang + '_count').textContent = this.value.length;
        });
        
        // Initial count
        document.getElementById('title_' + lang + '_count').textContent = titleInput.value.length;
        document.getElementById('description_' + lang + '_count').textContent = descInput.value.length;
    });
}

function setupPreviews() {
    ['it', 'en'].forEach(lang => {
        const titleInput = document.getElementById('title_' + lang);
        const descInput = document.getElementById('description_' + lang);
        
        titleInput.addEventListener('input', function() {
            document.getElementById('preview_title_' + lang).textContent = this.value || 'QR Finder';
        });
        
        descInput.addEventListener('input', function() {
            document.getElementById('preview_description_' + lang).textContent = this.value;
        });
    });
}

function setupForm() {
    document.getElementById('seoForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        try {
            const response = await fetch('/api/admin/seo', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Impostazioni SEO salvate con successo!');
            } else {
                alert(result.error || 'Errore durante il salvataggio');
            }
        } catch (error) {
            console.error('Failed to save SEO settings:', error);
            alert('Errore durante il salvataggio');
        }
    });
}

function resetForm() {
    if (confirm('Sei sicuro di voler annullare le modifiche?')) {
        location.reload();
    }
}
</script>

<style>
.settings-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 10px;
}

.tab-btn {
    padding: 10px 20px;
    border: none;
    background: #f3f4f6;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}

.tab-btn:hover {
    background: #e5e7eb;
}

.tab-btn.active {
    background: #2563eb;
    color: white;
}

.flag-icon {
    width: 20px;
    height: auto;
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

.char-counter {
    text-align: right;
    font-size: 12px;
    color: #6b7280;
    margin-top: 4px;
}

.preview-box {
    background: #f9fafb;
    padding: 20px;
    border-radius: 8px;
    margin-top: 20px;
}

.preview-box h4 {
    margin-bottom: 15px;
    color: #374151;
}

.google-preview {
    background: white;
    padding: 15px;
    border-radius: 8px;
    max-width: 600px;
}

.preview-title {
    color: #1a0dab;
    font-size: 20px;
    font-weight: 400;
    line-height: 1.3;
    margin-bottom: 5px;
}

.preview-url {
    color: #006621;
    font-size: 14px;
    margin-bottom: 5px;
}

.preview-description {
    color: #545454;
    font-size: 14px;
    line-height: 1.4;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
