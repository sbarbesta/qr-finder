<?php
$pageTitle = 'Profilo Admin - Admin';
$activeMenu = 'profile';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Profilo Amministratore</h1>
    <p class="subtitle">Gestisci le impostazioni del tuo account</p>
</div>

<div class="settings-grid">
    <!-- Profile Info -->
    <div class="settings-card">
        <h3><i class="fas fa-user"></i> Informazioni Personali</h3>
        
        <form id="profileForm">
            <div class="avatar-section">
                <div class="avatar-preview" id="avatarPreview">
                    <img src="/assets/images/default-avatar.png" alt="Avatar">
                </div>
                <div class="avatar-actions">
                    <button type="button" class="btn-secondary btn-small" onclick="document.getElementById('avatarFile').click()">
                        <i class="fas fa-camera"></i> Cambia Avatar
                    </button>
                    <input type="file" id="avatarFile" accept="image/*" hidden onchange="previewAvatar(event)">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="first_name">Nome</label>
                    <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($admin['first_name'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="last_name">Cognome</label>
                    <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($admin['last_name'] ?? ''); ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="nickname">Nickname</label>
                <input type="text" id="nickname" name="nickname" value="<?php echo htmlspecialchars($admin['nickname'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin['email'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="phone">Telefono</label>
                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($admin['phone'] ?? ''); ?>">
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-primary">Salva Profilo</button>
            </div>
        </form>
    </div>
    
    <!-- Password Change -->
    <div class="settings-card">
        <h3><i class="fas fa-lock"></i> Cambia Password</h3>
        
        <div class="password-info">
            <div class="info-icon">
                <i class="fas fa-shield-alt"></i>
            </div>
            <p>Per cambiare la password, ti invieremo un codice di verifica a 5 cifre via email. Questo garantisce la sicurezza del tuo account.</p>
        </div>
        
        <form id="passwordForm">
            <div class="form-group">
                <label for="current_password">Password Attuale</label>
                <input type="password" id="current_password" required>
            </div>
            
            <div class="form-group">
                <label for="new_password">Nuova Password</label>
                <input type="password" id="new_password" required minlength="8">
                <small>Minimo 8 caratteri</small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Conferma Password</label>
                <input type="password" id="confirm_password" required>
            </div>
            
            <div class="verification-section" id="verificationSection" style="display:none;">
                <div class="form-group">
                    <label for="verification_code">Codice di Verifica (5 cifre)</label>
                    <input type="text" id="verification_code" maxlength="5" pattern="\d{5}" placeholder="00000">
                    <small>Inserisci il codice ricevuto via email</small>
                </div>
                <div class="code-timer">
                    Il codice scade tra <span id="timer">10:00</span>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn-secondary" id="requestCodeBtn" onclick="requestVerificationCode()">
                    <i class="fas fa-envelope"></i> Richiedi Codice
                </button>
                <button type="submit" class="btn-primary" id="changePasswordBtn" style="display:none;">
                    <i class="fas fa-save"></i> Cambia Password
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Security Settings -->
<div class="settings-card">
    <h3><i class="fas fa-shield-alt"></i> Sicurezza</h3>
    
    <div class="security-options">
        <div class="security-item">
            <div class="security-info">
                <h4>Notifiche di Login</h4>
                <p>Ricevi una notifica email ogni volta che accedi al pannello admin</p>
            </div>
            <label class="toggle">
                <input type="checkbox" id="login_notifications" checked>
                <span class="toggle-slider"></span>
            </label>
        </div>
        
        <div class="security-item">
            <div class="security-info">
                <h4>Sessioni Attive</h4>
                <p>Visualizza e gestisci le sessioni di accesso attive</p>
            </div>
            <button class="btn-secondary btn-small" onclick="viewSessions()">Visualizza</button>
        </div>
        
        <div class="security-item">
            <div class="security-info">
                <h4>Log Attività</h4>
                <p>Visualizza la cronologia delle azioni effettuate nel pannello admin</p>
            </div>
            <button class="btn-secondary btn-small" onclick="viewLogs()">Visualizza</button>
        </div>
    </div>
</div>

<script>
let verificationCodeRequested = false;
let timerInterval = null;

document.addEventListener('DOMContentLoaded', function() {
    setupProfileForm();
    setupPasswordForm();
});

function setupProfileForm() {
    document.getElementById('profileForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        // Add avatar if changed
        const avatarFile = document.getElementById('avatarFile').files[0];
        if (avatarFile) {
            // Upload avatar first
            const avatarFormData = new FormData();
            avatarFormData.append('avatar', avatarFile);
            
            try {
                const avatarResponse = await fetch('/api/admin/profile/avatar', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                    },
                    body: avatarFormData
                });
                
                const avatarResult = await avatarResponse.json();
                if (avatarResult.success) {
                    data.avatar = avatarResult.filename;
                }
            } catch (error) {
                console.error('Avatar upload failed:', error);
            }
        }
        
        try {
            const response = await fetch('/api/admin/profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Profilo aggiornato con successo!');
            } else {
                alert(result.error || 'Errore durante il salvataggio');
            }
        } catch (error) {
            console.error('Failed to save profile:', error);
            alert('Errore durante il salvataggio');
        }
    });
}

function setupPasswordForm() {
    document.getElementById('passwordForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        if (!verificationCodeRequested) {
            alert('Richiedi prima il codice di verifica');
            return;
        }
        
        const newPassword = document.getElementById('new_password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        const verificationCode = document.getElementById('verification_code').value;
        
        if (newPassword !== confirmPassword) {
            alert('Le password non coincidono');
            return;
        }
        
        if (newPassword.length < 8) {
            alert('La password deve essere di almeno 8 caratteri');
            return;
        }
        
        if (!/^\d{5}$/.test(verificationCode)) {
            alert('Il codice di verifica deve essere di 5 cifre');
            return;
        }
        
        try {
            const response = await fetch('/api/admin/profile/password', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify({
                    current_password: document.getElementById('current_password').value,
                    new_password: newPassword,
                    verification_code: verificationCode
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Password cambiata con successo!');
                document.getElementById('passwordForm').reset();
                resetVerification();
            } else {
                alert(result.error || 'Errore durante il cambio password');
            }
        } catch (error) {
            console.error('Failed to change password:', error);
            alert('Errore durante il cambio password');
        }
    });
}

async function requestVerificationCode() {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    if (!newPassword || !confirmPassword) {
        alert('Inserisci prima la nuova password e la conferma');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        alert('Le password non coincidono');
        return;
    }
    
    if (newPassword.length < 8) {
        alert('La password deve essere di almeno 8 caratteri');
        return;
    }
    
    try {
        const response = await fetch('/api/admin/profile/verification-code', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            verificationCodeRequested = true;
            document.getElementById('verificationSection').style.display = 'block';
            document.getElementById('requestCodeBtn').style.display = 'none';
            document.getElementById('changePasswordBtn').style.display = 'inline-block';
            startTimer();
            alert('Codice di verifica inviato alla tua email!');
        } else {
            alert(result.error || 'Errore durante l\'invio del codice');
        }
    } catch (error) {
        console.error('Failed to request code:', error);
        alert('Errore durante la richiesta del codice');
    }
}

function startTimer() {
    let minutes = 10;
    let seconds = 0;
    
    timerInterval = setInterval(() => {
        if (seconds === 0) {
            if (minutes === 0) {
                clearInterval(timerInterval);
                resetVerification();
                alert('Il codice è scaduto. Richiedine uno nuovo.');
                return;
            }
            minutes--;
            seconds = 59;
        } else {
            seconds--;
        }
        
        document.getElementById('timer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }, 1000);
}

function resetVerification() {
    verificationCodeRequested = false;
    document.getElementById('verificationSection').style.display = 'none';
    document.getElementById('requestCodeBtn').style.display = 'inline-block';
    document.getElementById('changePasswordBtn').style.display = 'none';
    document.getElementById('verification_code').value = '';
    
    if (timerInterval) {
        clearInterval(timerInterval);
    }
}

function previewAvatar(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.querySelector('#avatarPreview img').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

function viewSessions() {
    alert('Visualizzazione sessioni (da implementare)');
}

function viewLogs() {
    window.open('/admin/logs', '_blank');
}
</script>

<style>
.avatar-section {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 20px;
    padding: 20px;
    background: #f9fafb;
    border-radius: 8px;
}

.avatar-preview {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    overflow: hidden;
    border: 3px solid #e5e7eb;
}

.avatar-preview img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.password-info {
    display: flex;
    gap: 15px;
    padding: 15px;
    background: #eff6ff;
    border-radius: 8px;
    margin-bottom: 20px;
}

.password-info .info-icon {
    font-size: 24px;
    color: #2563eb;
}

.password-info p {
    margin: 0;
    color: #374151;
    font-size: 14px;
}

.verification-section {
    background: #fef3c7;
    padding: 20px;
    border-radius: 8px;
    margin: 20px 0;
}

.code-timer {
    text-align: center;
    color: #92400e;
    font-weight: 600;
    margin-top: 10px;
}

.security-options {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.security-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: #f9fafb;
    border-radius: 8px;
}

.security-info h4 {
    margin: 0 0 5px;
    font-size: 16px;
}

.security-info p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
}

.toggle {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 26px;
}

.toggle input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
    border-radius: 26px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
}

.toggle input:checked + .toggle-slider {
    background-color: #10b981;
}

.toggle input:checked + .toggle-slider:before {
    transform: translateX(24px);
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
