<?php
$pageTitle = 'Gestione QR Codes - Admin';
$activeMenu = 'qrcodes';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Gestione QR Codes</h1>
    <p class="subtitle">Visualizza e filtra tutti i codici QR generati</p>
</div>

<!-- Filters -->
<div class="filters-card">
    <div class="filters-header">
        <h3><i class="fas fa-filter"></i> Filtri di Ricerca</h3>
        <button class="btn-toggle" onclick="toggleFilters()">
            <i class="fas fa-chevron-up"></i>
        </button>
    </div>
    <div class="filters-body" id="filtersBody">
        <div class="filters-grid">
            <div class="form-group">
                <label>Data Creazione (Da)</label>
                <input type="date" id="filter-date-from">
            </div>
            <div class="form-group">
                <label>Data Creazione (A)</label>
                <input type="date" id="filter-date-to">
            </div>
            <div class="form-group">
                <label>Utente</label>
                <select id="filter-user">
                    <option value="">Tutti gli utenti</option>
                    <?php foreach ($users as $user): ?>
                    <option value="<?php echo $user['id']; ?>"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Città</label>
                <input type="text" id="filter-city" placeholder="Cerca per città...">
            </div>
            <div class="form-group">
                <label>Provincia</label>
                <input type="text" id="filter-province" placeholder="Cerca per provincia...">
            </div>
            <div class="form-group">
                <label>Nazione</label>
                <select id="filter-country">
                    <option value="">Tutte le nazioni</option>
                    <?php foreach ($countries as $country): ?>
                    <option value="<?php echo $country['code']; ?>"><?php echo $country['name_it'] ?? $country['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Ha Scansioni</label>
                <select id="filter-has-scans">
                    <option value="">Tutti</option>
                    <option value="1">Con scansioni</option>
                    <option value="0">Senza scansioni</option>
                </select>
            </div>
            <div class="form-group">
                <label>Etichetta Acquistata</label>
                <select id="filter-purchased">
                    <option value="">Tutti</option>
                    <option value="1">Acquistata</option>
                    <option value="0">Non acquistata</option>
                </select>
            </div>
        </div>
        <div class="filters-actions">
            <button class="btn-secondary" onclick="resetFilters()">
                <i class="fas fa-undo"></i> Reset
            </button>
            <button class="btn-primary" onclick="applyFilters()">
                <i class="fas fa-search"></i> Cerca
            </button>
        </div>
    </div>
</div>

<!-- Results -->
<div class="results-card">
    <div class="results-header">
        <h3>Risultati <span id="results-count" class="badge">0</span></h3>
        <div class="results-actions">
            <select id="per-page" onchange="loadQrCodes()">
                <option value="20">20 per pagina</option>
                <option value="50">50 per pagina</option>
                <option value="100">100 per pagina</option>
            </select>
        </div>
    </div>
    
    <div class="table-responsive">
        <table class="data-table" id="qrcodes-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Anteprima QR</th>
                    <th>Codice</th>
                    <th>Nome Oggetto</th>
                    <th>Categoria</th>
                    <th>Utente</th>
                    <th>Scansioni</th>
                    <th>Ultima Scansione</th>
                    <th>Etichetta</th>
                    <th>Data Creaz.</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
                <tr class="loading-row">
                    <td colspan="11" class="text-center">Caricamento...</td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div class="pagination" id="pagination"></div>
</div>

<!-- QR Preview Modal -->
<div class="modal" id="qrPreviewModal" style="display:none;">
    <div class="modal-content modal-medium">
        <div class="modal-header">
            <h3>Anteprima QR Code</h3>
            <button class="close-btn" onclick="closeQrModal()">&times;</button>
        </div>
        <div class="modal-body text-center">
            <img id="qr-preview-image" src="" alt="QR Code" class="qr-preview-large">
            <p class="qr-code-info" id="qr-code-info"></p>
        </div>
        <div class="modal-footer">
            <a id="qr-download-link" href="#" class="btn-primary" download>
                <i class="fas fa-download"></i> Scarica
            </a>
            <button class="btn-secondary" onclick="closeQrModal()">Chiudi</button>
        </div>
    </div>
</div>

<script>
let currentPage = 1;
let currentFilters = {};

document.addEventListener('DOMContentLoaded', function() {
    loadQrCodes();
});

function toggleFilters() {
    const body = document.getElementById('filtersBody');
    const icon = document.querySelector('.btn-toggle i');
    body.classList.toggle('collapsed');
    icon.classList.toggle('fa-chevron-up');
    icon.classList.toggle('fa-chevron-down');
}

function applyFilters() {
    currentFilters = {
        date_from: document.getElementById('filter-date-from').value,
        date_to: document.getElementById('filter-date-to').value,
        user_id: document.getElementById('filter-user').value,
        city: document.getElementById('filter-city').value,
        province: document.getElementById('filter-province').value,
        country: document.getElementById('filter-country').value,
        has_scans: document.getElementById('filter-has-scans').value,
        label_purchased: document.getElementById('filter-purchased').value,
    };
    currentPage = 1;
    loadQrCodes();
}

function resetFilters() {
    document.querySelectorAll('.filters-grid input, .filters-grid select').forEach(el => el.value = '');
    currentFilters = {};
    currentPage = 1;
    loadQrCodes();
}

async function loadQrCodes() {
    const perPage = document.getElementById('per-page').value;
    
    const params = new URLSearchParams({
        page: currentPage,
        per_page: perPage,
        ...currentFilters
    });
    
    try {
        const response = await fetch(`/api/admin/qrcodes?${params}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderQrCodes(data.data.qrcodes);
            renderPagination(data.data.total, data.data.per_page, data.data.page);
            document.getElementById('results-count').textContent = data.data.total;
        }
    } catch (error) {
        console.error('Failed to load QR codes:', error);
    }
}

function renderQrCodes(qrcodes) {
    const tbody = document.querySelector('#qrcodes-table tbody');
    
    if (qrcodes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" class="text-center">Nessun QR code trovato</td></tr>';
        return;
    }
    
    tbody.innerHTML = qrcodes.map(qr => `
        <tr>
            <td>${qr.id}</td>
            <td>
                <img src="/storage/qr_codes/${qr.qr_code_path}" alt="QR" class="qr-thumb" onclick="previewQr(${qr.id}, '${qr.short_code}', '${escapeHtml(qr.name)}')">
            </td>
            <td><code>${qr.short_code}</code></td>
            <td>${escapeHtml(qr.name)}</td>
            <td><span class="category-badge">${qr.category}</span></td>
            <td>${escapeHtml(qr.user_name)}</td>
            <td>${qr.scan_count || 0}</td>
            <td>${qr.last_scanned_at ? formatDate(qr.last_scanned_at) : '-'}</td>
            <td>
                <span class="status-badge ${qr.label_purchased ? 'purchased' : 'not-purchased'}">
                    ${qr.label_purchased ? '✓ Acquistata' : '⏳ No'}
                </span>
            </td>
            <td>${formatDate(qr.created_at)}</td>
            <td>
                <button class="btn-icon" onclick="previewQr(${qr.id}, '${qr.short_code}', '${escapeHtml(qr.name)}')" title="Anteprima">
                    <i class="fas fa-eye"></i>
                </button>
                <a href="/r/${qr.short_code}" target="_blank" class="btn-icon" title="Vedi Pagina">
                    <i class="fas fa-external-link-alt"></i>
                </a>
            </td>
        </tr>
    `).join('');
}

function renderPagination(total, perPage, page) {
    const totalPages = Math.ceil(total / perPage);
    const container = document.getElementById('pagination');
    
    let html = '';
    
    if (totalPages > 1) {
        html += `<button ${page === 1 ? 'disabled' : ''} onclick="goToPage(${page - 1})"><i class="fas fa-chevron-left"></i></button>`;
        
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
                html += `<button class="${i === page ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
            } else if (i === page - 3 || i === page + 3) {
                html += `<span>...</span>`;
            }
        }
        
        html += `<button ${page === totalPages ? 'disabled' : ''} onclick="goToPage(${page + 1})"><i class="fas fa-chevron-right"></i></button>`;
    }
    
    container.innerHTML = html;
}

function goToPage(page) {
    currentPage = page;
    loadQrCodes();
}

function previewQr(id, code, name) {
    document.getElementById('qr-preview-image').src = `/api/admin/qrcodes/${id}/preview`;
    document.getElementById('qr-code-info').innerHTML = `<strong>${escapeHtml(name)}</strong><br><code>${code}</code>`;
    document.getElementById('qr-download-link').href = `/storage/qr_codes/${code}.png`;
    document.getElementById('qrPreviewModal').style.display = 'flex';
}

function closeQrModal() {
    document.getElementById('qrPreviewModal').style.display = 'none';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT');
}
</script>

<style>
.qr-thumb {
    width: 50px;
    height: 50px;
    cursor: pointer;
    border-radius: 4px;
    transition: transform 0.2s;
}
.qr-thumb:hover {
    transform: scale(1.1);
}
.qr-preview-large {
    max-width: 300px;
    max-height: 300px;
}
.category-badge {
    background: #e5e7eb;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    text-transform: capitalize;
}
.status-badge.purchased {
    color: #10b981;
}
.status-badge.not-purchased {
    color: #f59e0b;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
