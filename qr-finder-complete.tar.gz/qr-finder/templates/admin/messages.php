<?php
$pageTitle = 'Messaggi di Contatto - Admin';
$activeMenu = 'messages';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Messaggi di Contatto</h1>
    <p class="subtitle">Messaggi ricevuti dal modulo contatti</p>
</div>

<!-- Filters -->
<div class="filters-card">
    <div class="filters-header">
        <h3><i class="fas fa-filter"></i> Filtri</h3>
        <button class="btn-toggle" onclick="toggleFilters()">
            <i class="fas fa-chevron-up"></i>
        </button>
    </div>
    <div class="filters-body" id="filtersBody">
        <div class="filters-actions">
            <button class="btn-secondary" onclick="loadMessages(true)">
                <i class="fas fa-envelope-open"></i> Solo Non Letti
            </button>
            <button class="btn-secondary" onclick="loadMessages(false)">
                <i class="fas fa-envelope"></i> Tutti
            </button>
        </div>
    </div>
</div>

<!-- Messages List -->
<div class="results-card">
    <div class="results-header">
        <h3>Messaggi <span id="results-count" class="badge">0</span></h3>
    </div>
    
    <div class="messages-list" id="messagesList">
        <div class="loading">Caricamento messaggi...</div>
    </div>
    
    <div class="pagination" id="pagination"></div>
</div>

<!-- Message Detail Modal -->
<div class="modal" id="messageModal" style="display:none;">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3>Dettaglio Messaggio</h3>
            <button class="close-btn" onclick="closeMessageModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div class="message-detail" id="messageDetail">
                <!-- Content loaded dynamically -->
            </div>
        </div>
        <div class="modal-footer">
            <a id="replyEmail" href="#" class="btn-primary">
                <i class="fas fa-reply"></i> Rispondi via Email
            </a>
            <button class="btn-secondary" onclick="closeMessageModal()">Chiudi</button>
        </div>
    </div>
</div>

<script>
let currentPage = 1;
let showUnreadOnly = false;

document.addEventListener('DOMContentLoaded', function() {
    loadMessages();
});

function toggleFilters() {
    const body = document.getElementById('filtersBody');
    const icon = document.querySelector('.btn-toggle i');
    body.classList.toggle('collapsed');
    icon.classList.toggle('fa-chevron-up');
    icon.classList.toggle('fa-chevron-down');
}

async function loadMessages(unreadOnly = false) {
    showUnreadOnly = unreadOnly;
    
    try {
        const response = await fetch(`/api/admin/messages?unread=${unreadOnly}&page=${currentPage}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderMessages(data.data.messages);
            renderPagination(data.data.total, data.data.per_page, data.data.page);
            document.getElementById('results-count').textContent = data.data.total;
        }
    } catch (error) {
        console.error('Failed to load messages:', error);
    }
}

function renderMessages(messages) {
    const container = document.getElementById('messagesList');
    
    if (messages.length === 0) {
        container.innerHTML = '<div class="empty">Nessun messaggio</div>';
        return;
    }
    
    container.innerHTML = messages.map(msg => `
        <div class="message-item ${msg.is_read ? 'read' : 'unread'}" onclick="viewMessage(${msg.id})">
            <div class="message-header">
                <div class="message-sender">
                    <strong>${escapeHtml(msg.name)}</strong>
                    <span class="message-email">${escapeHtml(msg.email)}</span>
                </div>
                <div class="message-meta">
                    <span class="message-date">${formatDate(msg.created_at)}</span>
                    ${!msg.is_read ? '<span class="unread-badge">Nuovo</span>' : ''}
                </div>
            </div>
            <div class="message-subject">${escapeHtml(msg.subject || 'Nessun oggetto')}</div>
            <div class="message-preview">${escapeHtml(msg.message.substring(0, 150))}${msg.message.length > 150 ? '...' : ''}</div>
        </div>
    `).join('');
}

function renderPagination(total, perPage, page) {
    const totalPages = Math.ceil(total / perPage);
    const container = document.getElementById('pagination');
    
    let html = '';
    
    if (totalPages > 1) {
        html += `<button ${page === 1 ? 'disabled' : ''} onclick="goToPage(${page - 1})"><i class="fas fa-chevron-left"></i></button>`;
        
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
                html += `<button class="${i === page ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
            } else if (i === page - 3 || i === page + 3) {
                html += `<span>...</span>`;
            }
        }
        
        html += `<button ${page === totalPages ? 'disabled' : ''} onclick="goToPage(${page + 1})"><i class="fas fa-chevron-right"></i></button>`;
    }
    
    container.innerHTML = html;
}

function goToPage(page) {
    currentPage = page;
    loadMessages(showUnreadOnly);
}

async function viewMessage(id) {
    try {
        // Mark as read
        await fetch(`/api/admin/messages/${id}/read`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        // Get message details
        const response = await fetch(`/api/admin/messages/${id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const msg = data.data;
            document.getElementById('messageDetail').innerHTML = `
                <div class="message-full-header">
                    <p><strong>Da:</strong> ${escapeHtml(msg.name)} &lt;${escapeHtml(msg.email)}&gt;</p>
                    <p><strong>Data:</strong> ${formatDateTime(msg.created_at)}</p>
                    <p><strong>Oggetto:</strong> ${escapeHtml(msg.subject || 'Nessun oggetto')}</p>
                </div>
                <div class="message-full-body">
                    ${nl2br(escapeHtml(msg.message))}
                </div>
            `;
            
            document.getElementById('replyEmail').href = `mailto:${msg.email}?subject=Re: ${encodeURIComponent(msg.subject || '')}`;
            document.getElementById('messageModal').style.display = 'flex';
            
            // Refresh list to update read status
            loadMessages(showUnreadOnly);
        }
    } catch (error) {
        console.error('Failed to load message:', error);
    }
}

function closeMessageModal() {
    document.getElementById('messageModal').style.display = 'none';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function nl2br(str) {
    return str.replace(/\n/g, '<br>');
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT');
}

function formatDateTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('it-IT');
}
</script>

<style>
.messages-list {
    max-height: 600px;
    overflow-y: auto;
}

.message-item {
    padding: 15px 20px;
    border-bottom: 1px solid var(--admin-border);
    cursor: pointer;
    transition: background 0.2s;
}

.message-item:hover {
    background: #f9fafb;
}

.message-item.unread {
    background: #eff6ff;
}

.message-item.unread:hover {
    background: #dbeafe;
}

.message-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 8px;
}

.message-sender strong {
    display: block;
    color: var(--admin-text);
}

.message-email {
    font-size: 13px;
    color: var(--admin-text-light);
}

.message-meta {
    text-align: right;
}

.message-date {
    font-size: 12px;
    color: var(--admin-text-light);
}

.unread-badge {
    display: inline-block;
    background: var(--admin-primary);
    color: white;
    font-size: 10px;
    padding: 2px 8px;
    border-radius: 10px;
    margin-top: 5px;
}

.message-subject {
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--admin-text);
}

.message-preview {
    font-size: 13px;
    color: var(--admin-text-light);
    line-height: 1.5;
}

.message-full-header {
    background: #f9fafb;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.message-full-header p {
    margin-bottom: 8px;
}

.message-full-header p:last-child {
    margin-bottom: 0;
}

.message-full-body {
    line-height: 1.8;
    white-space: pre-wrap;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
