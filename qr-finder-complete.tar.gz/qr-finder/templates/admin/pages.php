<?php
$pageTitle = 'Pagine Statiche - Admin';
$activeMenu = 'pages';
$adminName = $adminName ?? 'Admin';
$includeTinyMCE = true;

ob_start();
?>

<div class="page-header">
    <h1>Pagine Statiche</h1>
    <p class="subtitle">Gestisci le pagine del sito</p>
</div>

<!-- Pages List -->
<div class="results-card">
    <div class="results-header">
        <h3>Pagine <span class="badge"><?php echo count($pages); ?></span></h3>
        <button class="btn-primary" onclick="openPageModal()">
            <i class="fas fa-plus"></i> Nuova Pagina
        </button>
    </div>
    
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Ordine</th>
                    <th>Titolo (IT)</th>
                    <th>Titolo (EN)</th>
                    <th>Slug</th>
                    <th>Footer</th>
                    <th>Stato</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pages as $page): ?>
                <tr>
                    <td><?php echo $page['footer_order']; ?></td>
                    <td><?php echo htmlspecialchars($page['title_it']); ?></td>
                    <td><?php echo htmlspecialchars($page['title_en'] ?? '-'); ?></td>
                    <td><code>/page/<?php echo $page['slug']; ?></code></td>
                    <td>
                        <?php if ($page['show_in_footer']): ?>
                        <span class="status-badge active"><i class="fas fa-check"></i> Sì</span>
                        <?php else: ?>
                        <span class="status-badge inactive">No</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($page['is_published']): ?>
                        <span class="status-badge published">Pubblicata</span>
                        <?php else: ?>
                        <span class="status-badge draft">Bozza</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button class="btn-icon" onclick="editPage(<?php echo $page['id']; ?>)" title="Modifica">
                            <i class="fas fa-edit"></i>
                        </button>
                        <a href="/page/<?php echo $page['slug']; ?>" target="_blank" class="btn-icon" title="Visualizza">
                            <i class="fas fa-eye"></i>
                        </a>
                        <?php if (!in_array($page['slug'], ['chi-siamo', 'missione', 'termini-condizioni', 'privacy-policy', 'cookie-policy', 'contatti'])): ?>
                        <button class="btn-icon btn-danger" onclick="deletePage(<?php echo $page['id']; ?>)" title="Elimina">
                            <i class="fas fa-trash"></i>
                        </button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Page Modal -->
<div class="modal" id="pageModal" style="display:none;">
    <div class="modal-content modal-xlarge">
        <div class="modal-header">
            <h3 id="modalTitle">Nuova Pagina</h3>
            <button class="close-btn" onclick="closePageModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="pageForm">
                <input type="hidden" id="page_id" name="id">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="title_it">Titolo (Italiano) *</label>
                        <input type="text" id="title_it" name="title_it" required>
                    </div>
                    <div class="form-group">
                        <label for="title_en">Titolo (English)</label>
                        <input type="text" id="title_en" name="title_en">
                    </div>
                </div>
                
                <div class="form-tabs">
                    <button type="button" class="tab-btn active" onclick="switchTab('content-it')">
                        <img src="/assets/images/flags/it.png" alt="IT" class="flag-icon"> Contenuto IT
                    </button>
                    <button type="button" class="tab-btn" onclick="switchTab('content-en')">
                        <img src="/assets/images/flags/gb.png" alt="EN" class="flag-icon"> Contenuto EN
                    </button>
                    <button type="button" class="tab-btn" onclick="switchTab('settings')">
                        <i class="fas fa-cog"></i> Impostazioni
                    </button>
                </div>
                
                <div class="tab-content active" id="content-it">
                    <div class="form-group">
                        <label for="content_it">Contenuto (Italiano)</label>
                        <textarea id="content_it" name="content_it" class="tinymce-editor"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="meta_description_it">Meta Description (IT)</label>
                        <textarea id="meta_description_it" name="meta_description_it" rows="2" maxlength="160"></textarea>
                        <small>Max 160 caratteri per SEO</small>
                    </div>
                </div>
                
                <div class="tab-content" id="content-en">
                    <div class="form-group">
                        <label for="content_en">Content (English)</label>
                        <textarea id="content_en" name="content_en" class="tinymce-editor"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="meta_description_en">Meta Description (EN)</label>
                        <textarea id="meta_description_en" name="meta_description_en" rows="2" maxlength="160"></textarea>
                        <small>Max 160 characters for SEO</small>
                    </div>
                </div>
                
                <div class="tab-content" id="settings">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="slug">Slug URL</label>
                            <input type="text" id="slug" name="slug" readonly>
                            <small>Generato automaticamente dal titolo</small>
                        </div>
                        <div class="form-group">
                            <label for="footer_order">Ordine nel Footer</label>
                            <input type="number" id="footer_order" name="footer_order" value="0" min="0">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="checkbox">
                                <input type="checkbox" id="is_published" name="is_published" checked>
                                <span>Pubblicata</span>
                            </label>
                        </div>
                        <div class="form-group">
                            <label class="checkbox">
                                <input type="checkbox" id="show_in_footer" name="show_in_footer" checked>
                                <span>Mostra nel Footer</span>
                            </label>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn-secondary" onclick="closePageModal()">Annulla</button>
            <button type="button" class="btn-primary" onclick="savePage()">Salva Pagina</button>
        </div>
    </div>
</div>

<script>
let isEditing = false;
let currentPageId = null;

document.addEventListener('DOMContentLoaded', function() {
    setupTinyMCE();
    setupSlugGeneration();
});

function setupTinyMCE() {
    tinymce.init({
        selector: '.tinymce-editor',
        plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
        height: 400,
        language: 'it',
        branding: false,
        promotion: false,
        images_upload_url: '/api/admin/upload-image'
    });
}

function setupSlugGeneration() {
    document.getElementById('title_it').addEventListener('blur', function() {
        if (!isEditing && this.value) {
            document.getElementById('slug').value = slugify(this.value);
        }
    });
}

function slugify(text) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

function switchTab(tabId) {
    document.querySelectorAll('#pageModal .tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('#pageModal .tab-content').forEach(tab => tab.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById(tabId).classList.add('active');
}

function openPageModal() {
    isEditing = false;
    currentPageId = null;
    document.getElementById('modalTitle').textContent = 'Nuova Pagina';
    document.getElementById('pageForm').reset();
    document.getElementById('slug').value = '';
    document.getElementById('slug').readOnly = false;
    
    tinymce.get('content_it').setContent('');
    tinymce.get('content_en').setContent('');
    
    document.getElementById('pageModal').style.display = 'flex';
}

async function editPage(id) {
    isEditing = true;
    currentPageId = id;
    document.getElementById('modalTitle').textContent = 'Modifica Pagina';
    document.getElementById('slug').readOnly = true;
    
    try {
        const response = await fetch(`/api/admin/pages/${id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const page = data.data;
            document.getElementById('page_id').value = page.id;
            document.getElementById('title_it').value = page.title_it;
            document.getElementById('title_en').value = page.title_en || '';
            document.getElementById('slug').value = page.slug;
            document.getElementById('meta_description_it').value = page.meta_description_it || '';
            document.getElementById('meta_description_en').value = page.meta_description_en || '';
            document.getElementById('footer_order').value = page.footer_order;
            document.getElementById('is_published').checked = page.is_published;
            document.getElementById('show_in_footer').checked = page.show_in_footer;
            
            tinymce.get('content_it').setContent(page.content_it || '');
            tinymce.get('content_en').setContent(page.content_en || '');
            
            document.getElementById('pageModal').style.display = 'flex';
        }
    } catch (error) {
        console.error('Failed to load page:', error);
        alert('Errore durante il caricamento della pagina');
    }
}

function closePageModal() {
    document.getElementById('pageModal').style.display = 'none';
}

async function savePage() {
    const contentIt = tinymce.get('content_it').getContent();
    const contentEn = tinymce.get('content_en').getContent();
    
    const data = {
        title_it: document.getElementById('title_it').value,
        title_en: document.getElementById('title_en').value,
        content_it: contentIt,
        content_en: contentEn,
        meta_description_it: document.getElementById('meta_description_it').value,
        meta_description_en: document.getElementById('meta_description_en').value,
        is_published: document.getElementById('is_published').checked,
        show_in_footer: document.getElementById('show_in_footer').checked,
        footer_order: parseInt(document.getElementById('footer_order').value) || 0
    };
    
    if (!data.title_it) {
        alert('Il titolo in italiano è obbligatorio');
        return;
    }
    
    const url = isEditing ? `/api/admin/pages/${currentPageId}` : '/api/admin/pages';
    const method = isEditing ? 'PUT' : 'POST';
    
    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            closePageModal();
            location.reload();
        } else {
            alert(result.error || 'Errore durante il salvataggio');
        }
    } catch (error) {
        console.error('Failed to save page:', error);
        alert('Errore durante il salvataggio');
    }
}

async function deletePage(id) {
    if (!confirm('Sei sicuro di voler eliminare questa pagina?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/admin/pages/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('session_token')}`
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            location.reload();
        } else {
            alert(result.error || 'Errore durante l\'eliminazione');
        }
    } catch (error) {
        console.error('Failed to delete page:', error);
        alert('Errore durante l\'eliminazione');
    }
}
</script>

<style>
.modal-xlarge {
    max-width: 1000px;
    width: 95%;
}

.status-badge.published {
    background: #d1fae5;
    color: #065f46;
}

.status-badge.draft {
    background: #fef3c7;
    color: #92400e;
}

.status-badge.active {
    background: #d1fae5;
    color: #065f46;
}

.status-badge.inactive {
    background: #f3f4f6;
    color: #6b7280;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
