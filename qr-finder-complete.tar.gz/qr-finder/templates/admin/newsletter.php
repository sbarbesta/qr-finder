<?php
$pageTitle = 'Newsletter - Admin';
$activeMenu = 'newsletter';
$adminName = $adminName ?? 'Admin';

ob_start();
?>

<div class="page-header">
    <h1>Gestione Newsletter</h1>
    <p class="subtitle">Invia newsletter agli iscritti</p>
</div>

<!-- Stats -->
<div class="stats-row">
    <div class="stat-box">
        <h4>Iscritti Totali</h4>
        <div class="stat-large"><?php echo number_format($subscribers['total'] ?? 0); ?></div>
    </div>
    <div class="stat-box">
        <h4>Iscritti Attivi</h4>
        <div class="stat-large"><?php echo number_format($subscribers['active'] ?? 0); ?></div>
    </div>
    <div class="stat-box">
        <h4>Italiano</h4>
        <div class="stat-large"><?php echo number_format($subscribers['it'] ?? 0); ?></div>
    </div>
    <div class="stat-box">
        <h4>English</h4>
        <div class="stat-large"><?php echo number_format($subscribers['en'] ?? 0); ?></div>
    </div>
</div>

<!-- Send Newsletter -->
<div class="settings-card">
    <h3><i class="fas fa-paper-plane"></i> Componi Newsletter</h3>
    
    <form id="newsletterForm">
        <div class="form-tabs">
            <button type="button" class="tab-btn active" onclick="switchTab('compose-it')">
                <img src="/assets/images/flags/it.png" alt="IT" class="flag-icon"> Italiano
            </button>
            <button type="button" class="tab-btn" onclick="switchTab('compose-en')">
                <img src="/assets/images/flags/gb.png" alt="EN" class="flag-icon"> English
            </button>
        </div>
        
        <div class="tab-content active" id="compose-it">
            <div class="form-group">
                <label for="subject_it">Oggetto *</label>
                <input type="text" id="subject_it" name="subject_it" required placeholder="Oggetto della newsletter...">
            </div>
            <div class="form-group">
                <label for="content_it">Contenuto *</label>
                <textarea id="content_it" name="content_it" rows="15" required></textarea>
            </div>
        </div>
        
        <div class="tab-content" id="compose-en">
            <div class="form-group">
                <label for="subject_en">Subject *</label>
                <input type="text" id="subject_en" name="subject_en" placeholder="Newsletter subject...">
            </div>
            <div class="form-group">
                <label for="content_en">Content *</label>
                <textarea id="content_en" name="content_en" rows="15"></textarea>
            </div>
        </div>
        
        <div class="newsletter-info">
            <h4><i class="fas fa-info-circle"></i> Informazioni</h4>
            <ul>
                <li>La newsletter verrà inviata a tutti gli iscritti attivi</li>
                <li>Ogni iscritto riceverà la versione nella sua lingua preferita</li>
                <li>Verrà automaticamente aggiunto un link per la disiscrizione</li>
                <li>L'invio potrebbe richiedere alcuni minuti</li>
            </ul>
        </div>
        
        <div class="form-actions">
            <button type="button" class="btn-secondary" onclick="previewNewsletter()">
                <i class="fas fa-eye"></i> Anteprima
            </button>
            <button type="submit" class="btn-primary btn-large">
                <i class="fas fa-paper-plane"></i> Invia Newsletter
            </button>
        </div>
    </form>
</div>

<!-- Campaign History -->
<div class="results-card">
    <div class="results-header">
        <h3>Cronologia Campagne</h3>
    </div>
    
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Oggetto</th>
                    <th>Destinatari</th>
                    <th>Stato</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($campaigns)): ?>
                <tr>
                    <td colspan="5" class="text-center">Nessuna campagna inviata</td>
                </tr>
                <?php else: ?>
                <?php foreach ($campaigns as $campaign): ?>
                <tr>
                    <td><?php echo date('d/m/Y H:i', strtotime($campaign['sent_at'] ?? $campaign['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($campaign['subject_it']); ?></td>
                    <td><?php echo number_format($campaign['recipients_count']); ?></td>
                    <td>
                        <span class="status-badge <?php echo $campaign['status']; ?>">
                            <?php 
                            $statusLabels = [
                                'draft' => 'Bozza',
                                'sending' => 'Invio...',
                                'sent' => 'Inviata',
                                'failed' => 'Fallita'
                            ];
                            echo $statusLabels[$campaign['status']] ?? $campaign['status'];
                            ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn-icon" onclick="viewCampaign(<?php echo $campaign['id']; ?>)" title="Visualizza">
                            <i class="fas fa-eye"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal" id="previewModal" style="display:none;">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3>Anteprima Newsletter</h3>
            <button class="close-btn" onclick="closePreviewModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div class="preview-tabs">
                <button type="button" class="preview-tab active" onclick="switchPreviewTab('it')">Italiano</button>
                <button type="button" class="preview-tab" onclick="switchPreviewTab('en')">English</button>
            </div>
            <div class="preview-content" id="preview-it"></div>
            <div class="preview-content" id="preview-en" style="display:none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn-secondary" onclick="closePreviewModal()">Chiudi</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    setupTinyMCE();
    setupForm();
});

function setupTinyMCE() {
    tinymce.init({
        selector: '#content_it, #content_en',
        plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
        height: 400,
        language: 'it',
        branding: false,
        promotion: false
    });
}

function setupForm() {
    document.getElementById('newsletterForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Get content from TinyMCE
        const contentIt = tinymce.get('content_it').getContent();
        const contentEn = tinymce.get('content_en').getContent();
        
        if (!contentIt) {
            alert('Il contenuto in italiano è obbligatorio');
            return;
        }
        
        const data = {
            subject_it: document.getElementById('subject_it').value,
            subject_en: document.getElementById('subject_en').value,
            content_it: contentIt,
            content_en: contentEn
        };
        
        if (!confirm('Sei sicuro di voler inviare questa newsletter a tutti gli iscritti?')) {
            return;
        }
        
        try {
            const response = await fetch('/api/admin/newsletter/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('session_token')}`
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                location.reload();
            } else {
                alert(result.error || 'Errore durante l\'invio');
            }
        } catch (error) {
            console.error('Failed to send newsletter:', error);
            alert('Errore durante l\'invio');
        }
    });
}

function switchTab(tabId) {
    document.querySelectorAll('.form-tabs .tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById(tabId).classList.add('active');
}

function previewNewsletter() {
    const contentIt = tinymce.get('content_it').getContent();
    const contentEn = tinymce.get('content_en').getContent();
    
    document.getElementById('preview-it').innerHTML = `
        <h2>${document.getElementById('subject_it').value || 'Oggetto'}</h2>
        ${contentIt}
        <hr>
        <p style="font-size:12px;color:#666;"><a href="#">Disiscriviti</a></p>
    `;
    
    document.getElementById('preview-en').innerHTML = `
        <h2>${document.getElementById('subject_en').value || 'Subject'}</h2>
        ${contentEn || contentIt}
        <hr>
        <p style="font-size:12px;color:#666;"><a href="#">Unsubscribe</a></p>
    `;
    
    document.getElementById('previewModal').style.display = 'flex';
}

function switchPreviewTab(lang) {
    document.querySelectorAll('.preview-tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.preview-content').forEach(content => content.style.display = 'none');
    
    event.target.classList.add('active');
    document.getElementById('preview-' + lang).style.display = 'block';
}

function closePreviewModal() {
    document.getElementById('previewModal').style.display = 'none';
}

function viewCampaign(id) {
    // Load campaign details
    alert('Visualizzazione campagna ' + id);
}
</script>

<style>
.stat-large {
    font-size: 36px;
    font-weight: 700;
    color: #2563eb;
}

.form-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 10px;
}

.newsletter-info {
    background: #eff6ff;
    padding: 15px;
    border-radius: 8px;
    margin: 20px 0;
}

.newsletter-info h4 {
    margin-bottom: 10px;
    color: #1e40af;
}

.newsletter-info ul {
    margin: 0;
    padding-left: 20px;
}

.newsletter-info li {
    margin-bottom: 5px;
    color: #374151;
}

.preview-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 15px;
}

.preview-tab {
    padding: 8px 16px;
    border: 1px solid #e5e7eb;
    background: white;
    border-radius: 4px;
    cursor: pointer;
}

.preview-tab.active {
    background: #2563eb;
    color: white;
    border-color: #2563eb;
}

.preview-content {
    border: 1px solid #e5e7eb;
    padding: 20px;
    border-radius: 8px;
    min-height: 300px;
}

.status-badge.draft {
    background: #f3f4f6;
    color: #6b7280;
}

.status-badge.sending {
    background: #dbeafe;
    color: #1e40af;
}

.status-badge.sent {
    background: #d1fae5;
    color: #065f46;
}

.status-badge.failed {
    background: #fee2e2;
    color: #991b1b;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>
