<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dettaglio Oggetto - QR Finder</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/dashboard.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body class="dashboard-page">
    <nav class="navbar dashboard-nav">
        <div class="container">
            <a href="/dashboard" class="logo">QR Finder</a>
            <div class="nav-right">
                <a href="/dashboard" class="btn-secondary">← Torna alla Dashboard</a>
            </div>
        </div>
    </nav>

    <main class="dashboard-main">
        <div class="container">
            <div id="object-content">
                <div class="loading">Caricamento...</div>
            </div>
        </div>
    </main>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        const objectId = <?php echo json_encode((int)($_GET['object_id'] ?? 0)); ?>;
        const API_BASE = '/api';
        
        document.addEventListener('DOMContentLoaded', function() {
            loadObjectDetails();
        });
        
        async function loadObjectDetails() {
            const token = localStorage.getItem('session_token');
            
            if (!token) {
                window.location.href = '/login';
                return;
            }
            
            try {
                const [objectResponse, mapResponse] = await Promise.all([
                    fetch(`${API_BASE}/objects/${objectId}`, {
                        headers: { 'Authorization': `Bearer ${token}` }
                    }),
                    fetch(`${API_BASE}/objects/${objectId}/map`, {
                        headers: { 'Authorization': `Bearer ${token}` }
                    })
                ]);
                
                const objectData = await objectResponse.json();
                const mapData = await mapResponse.json();
                
                if (objectData.success && mapData.success) {
                    renderObjectDetails(objectData.data, mapData.data);
                } else {
                    document.getElementById('object-content').innerHTML = 
                        '<div class="error-message">Oggetto non trovato</div>';
                }
            } catch (error) {
                console.error('Failed to load object:', error);
                document.getElementById('object-content').innerHTML = 
                    '<div class="error-message">Errore durante il caricamento</div>';
            }
        }
        
        function renderObjectDetails(object, mapData) {
            const container = document.getElementById('object-content');
            
            const hasLocations = mapData.locations && mapData.locations.length > 0;
            
            container.innerHTML = `
                <div class="dashboard-header">
                    <div>
                        <h1>${escapeHtml(object.name)}</h1>
                        <span class="category-badge">${escapeHtml(object.category)}</span>
                    </div>
                    <div class="header-actions">
                        ${object.label_purchased ? 
                            `<button class="btn-secondary" onclick="downloadQr(${object.id})">Scarica QR</button>` :
                            `<button class="btn-primary" onclick="purchaseLabel(${object.id}, '${escapeHtml(object.name)}')">Acquista Etichetta</button>`
                        }
                    </div>
                </div>
                
                <div class="object-info-card">
                    <div class="info-grid">
                        <div class="info-item">
                            <label>Codice QR:</label>
                            <span class="code">${object.short_code}</span>
                        </div>
                        <div class="info-item">
                            <label>Stato:</label>
                            <span class="status ${object.label_purchased ? 'purchased' : 'not-purchased'}">
                                ${object.label_purchased ? 'Etichetta acquistata' : 'Etichetta non acquistata'}
                            </span>
                        </div>
                        <div class="info-item">
                            <label>Scannerizzazioni:</label>
                            <span>${object.scan_count || 0}</span>
                        </div>
                        <div class="info-item">
                            <label>Ultima scansione:</label>
                            <span>${object.last_scanned_at ? formatDate(object.last_scanned_at) : 'Mai'}</span>
                        </div>
                    </div>
                    ${object.description ? `
                        <div class="description">
                            <label>Descrizione:</label>
                            <p>${escapeHtml(object.description)}</p>
                        </div>
                    ` : ''}
                </div>
                
                <div class="map-section-full">
                    <h2>Posizione dell'oggetto</h2>
                    <div id="object-map" class="map-container-large"></div>
                    ${hasLocations ? `
                        <div class="location-history">
                            <h3>Cronologia posizioni</h3>
                            <div class="history-list">
                                ${mapData.locations.map(loc => `
                                    <div class="history-item">
                                        <span class="date">${formatDate(loc.scanned_at)}</span>
                                        <span class="coords">${loc.latitude.toFixed(6)}, ${loc.longitude.toFixed(6)}</span>
                                        ${loc.accuracy ? `<span class="accuracy">±${Math.round(loc.accuracy)}m</span>` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : '<p class="empty">Nessuna posizione registrata</p>'}
                </div>
            `;
            
            // Initialize map
            if (hasLocations) {
                initMap(mapData.locations);
            }
        }
        
        function initMap(locations) {
            const map = L.map('object-map');
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);
            
            const bounds = L.latLngBounds();
            
            locations.forEach((loc, index) => {
                const marker = L.marker([loc.latitude, loc.longitude])
                    .bindPopup(`<b>Scansione #${index + 1}</b><br>${formatDate(loc.scanned_at)}`)
                    .addTo(map);
                bounds.extend([loc.latitude, loc.longitude]);
            });
            
            map.fitBounds(bounds, { padding: [50, 50] });
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function formatDate(dateString) {
            if (!dateString) return 'Mai';
            const date = new Date(dateString);
            return date.toLocaleString('it-IT');
        }
        
        function downloadQr(objectId) {
            window.open(`${API_BASE}/objects/${objectId}/download`, '_blank');
        }
        
        function purchaseLabel(objectId, objectName) {
            // Redirect to dashboard with payment modal
            window.location.href = `/dashboard?purchase=${objectId}`;
        }
    </script>
    
    <style>
        .object-info-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-sm);
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-item label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 0.25rem;
        }
        
        .info-item .code {
            font-family: monospace;
            font-size: 1.125rem;
            color: var(--primary-color);
        }
        
        .info-item .status.purchased {
            color: var(--secondary-color);
        }
        
        .info-item .status.not-purchased {
            color: var(--warning-color);
        }
        
        .description {
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }
        
        .description label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            display: block;
            margin-bottom: 0.5rem;
        }
        
        .map-section-full {
            background: white;
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow-sm);
        }
        
        .map-container-large {
            height: 400px;
            border-radius: var(--radius);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        
        .location-history {
            border-top: 1px solid var(--border-color);
            padding-top: 1rem;
        }
        
        .location-history h3 {
            font-size: 1rem;
            margin-bottom: 1rem;
        }
        
        .history-list {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .history-item {
            display: flex;
            gap: 1rem;
            padding: 0.75rem;
            background: var(--bg-secondary);
            border-radius: var(--radius);
            font-size: 0.875rem;
        }
        
        .history-item .date {
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .history-item .coords {
            color: var(--text-secondary);
            font-family: monospace;
        }
        
        .history-item .accuracy {
            color: var(--text-light);
            margin-left: auto;
        }
        
        .category-badge {
            display: inline-block;
            background: var(--bg-secondary);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            text-transform: capitalize;
            margin-top: 0.5rem;
        }
        
        .header-actions {
            display: flex;
            gap: 1rem;
        }
    </style>
</body>
</html>
