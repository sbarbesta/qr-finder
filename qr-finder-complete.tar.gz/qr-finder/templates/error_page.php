<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/tracking.css">
</head>
<body class="tracking-page">
    <nav class="navbar simple-nav">
        <div class="container">
            <a href="/" class="logo">QR Finder</a>
        </div>
    </nav>

    <main class="tracking-main">
        <div class="container">
            <div class="tracking-card error-card">
                <div class="tracking-header">
                    <div class="error-icon">❌</div>
                    <h1>Si è verificato un errore</h1>
                    <p class="error-message"><?php echo $errorMessage; ?></p>
                </div>

                <div class="tracking-actions">
                    <p>Il codice QR che hai scannerizzato potrebbe non essere valido o essere scaduto.</p>
                    <div class="action-buttons">
                        <a href="/" class="btn-primary">Torna alla Home</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="simple-footer">
        <div class="container">
            <p>Powered by <a href="/">QR Finder</a></p>
        </div>
    </footer>
</body>
</html>
