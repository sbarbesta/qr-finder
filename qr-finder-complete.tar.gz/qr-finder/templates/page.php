<!DOCTYPE html>
<html lang="<?php echo $page['language'] ?? 'it'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page['title_it']); ?> - QR Finder</title>
    <meta name="description" content="<?php echo htmlspecialchars($page['meta_description_it'] ?? ''); ?>">
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        .page-content {
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .page-content h1 {
            font-size: 32px;
            margin-bottom: 20px;
            color: #1f2937;
        }
        
        .page-content h2 {
            font-size: 24px;
            margin: 30px 0 15px;
            color: #374151;
        }
        
        .page-content h3 {
            font-size: 20px;
            margin: 25px 0 10px;
            color: #4b5563;
        }
        
        .page-content p {
            margin-bottom: 15px;
            line-height: 1.7;
        }
        
        .page-content ul, .page-content ol {
            margin-bottom: 15px;
            padding-left: 25px;
        }
        
        .page-content li {
            margin-bottom: 8px;
        }
        
        .page-content a {
            color: #2563eb;
            text-decoration: none;
        }
        
        .page-content a:hover {
            text-decoration: underline;
        }
        
        .page-content blockquote {
            border-left: 4px solid #e5e7eb;
            padding-left: 20px;
            margin: 20px 0;
            color: #6b7280;
        }
        
        .page-content table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .page-content th, .page-content td {
            padding: 12px;
            border: 1px solid #e5e7eb;
            text-align: left;
        }
        
        .page-content th {
            background: #f9fafb;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a href="/" class="logo">QR Finder</a>
            <div class="nav-links">
                <a href="/">Home</a>
                <a href="/login">Accedi</a>
                <a href="/register" class="btn-primary">Registrati</a>
            </div>
        </div>
    </nav>

    <main class="page-content">
        <?php echo $page['content_it'] ?? ''; ?>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>QR Finder</h4>
                    <p>La soluzione intelligente per trovare i tuoi oggetti smarriti.</p>
                </div>
                <div class="footer-section">
                    <h4>Link Utili</h4>
                    <ul>
                        <li><a href="/page/chi-siamo">Chi Siamo</a></li>
                        <li><a href="/page/missione">Missione</a></li>
                        <li><a href="/page/termini-condizioni">Termini & Condizioni</a></li>
                        <li><a href="/page/privacy-policy">Privacy Policy</a></li>
                        <li><a href="/page/cookie-policy">Cookie Policy</a></li>
                        <li><a href="/page/contatti">Contatti</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contatti</h4>
                    <p>Email: support@qr-finder.com</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> QR Finder. Tutti i diritti riservati.</p>
            </div>
        </div>
    </footer>
</body>
</html>
