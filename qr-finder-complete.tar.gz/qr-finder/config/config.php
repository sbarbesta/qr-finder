<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(dirname(__DIR__));
$dotenv->safeLoad();

return [
    'database' => [
        'host' => $_ENV['DB_HOST'] ?? 'localhost',
        'name' => $_ENV['DB_NAME'] ?? 'qrfinder',
        'user' => $_ENV['DB_USER'] ?? 'root',
        'pass' => $_ENV['DB_PASS'] ?? '',
        'charset' => $_ENV['DB_CHARSET'] ?? 'utf8mb4',
    ],
    'app' => [
        'env' => $_ENV['APP_ENV'] ?? 'production',
        'debug' => filter_var($_ENV['APP_DEBUG'] ?? false, FILTER_VALIDATE_BOOLEAN),
        'url' => $_ENV['APP_URL'] ?? 'https://qr-finder.com',
        'name' => $_ENV['APP_NAME'] ?? 'QR Finder',
    ],
    'jwt' => [
        'secret' => $_ENV['JWT_SECRET'] ?? 'default-secret-change-this',
        'expire' => (int)($_ENV['JWT_EXPIRE'] ?? 86400),
    ],
    'stripe' => [
        'publishable_key' => $_ENV['STRIPE_PUBLISHABLE_KEY'] ?? '',
        'secret_key' => $_ENV['STRIPE_SECRET_KEY'] ?? '',
        'webhook_secret' => $_ENV['STRIPE_WEBHOOK_SECRET'] ?? '',
    ],
    'mail' => [
        'host' => $_ENV['MAIL_HOST'] ?? 'smtp.gmail.com',
        'port' => (int)($_ENV['MAIL_PORT'] ?? 587),
        'username' => $_ENV['MAIL_USERNAME'] ?? '',
        'password' => $_ENV['MAIL_PASSWORD'] ?? '',
        'encryption' => $_ENV['MAIL_ENCRYPTION'] ?? 'tls',
        'from_address' => $_ENV['MAIL_FROM_ADDRESS'] ?? 'noreply@qr-finder.com',
        'from_name' => $_ENV['MAIL_FROM_NAME'] ?? 'QR Finder',
    ],
    'qr' => [
        'size' => (int)($_ENV['QR_CODE_SIZE'] ?? 300),
        'margin' => (int)($_ENV['QR_CODE_MARGIN'] ?? 10),
    ],
    'pricing' => [
        'label_price_cents' => (int)($_ENV['LABEL_PRICE_CENTS'] ?? 500),
        'currency' => $_ENV['CURRENCY'] ?? 'eur',
    ],
];
