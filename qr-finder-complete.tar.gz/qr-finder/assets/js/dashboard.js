// Dashboard JavaScript

const API_BASE = '/api';
let currentObjectId = null;
let stripe = null;
let cardElement = null;
let map = null;
let markers = [];

// Check authentication on load
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    initDashboard();
});

async function checkAuth() {
    const token = localStorage.getItem('session_token');
    
    if (!token) {
        window.location.href = '/login';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/auth/me`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (!data.success) {
            localStorage.removeItem('session_token');
            localStorage.removeItem('user');
            window.location.href = '/login';
            return;
        }
        
        // Update user name in UI
        document.getElementById('user-name').textContent = data.data.first_name;
        
    } catch (error) {
        console.error('Auth check failed:', error);
    }
}

function initDashboard() {
    loadObjects();
    loadNotifications();
    initMap();
    setupEventListeners();
    setupStripe();
}

function setupEventListeners() {
    // Add object modal
    document.getElementById('add-object-btn').addEventListener('click', () => {
        document.getElementById('add-object-modal').style.display = 'flex';
    });
    
    document.querySelector('#add-object-modal .close-btn').addEventListener('click', closeAddModal);
    document.getElementById('cancel-add').addEventListener('click', closeAddModal);
    
    document.getElementById('add-object-form').addEventListener('submit', handleAddObject);
    
    // QR modal
    document.querySelector('#qr-modal .close-btn').addEventListener('click', closeQrModal);
    document.getElementById('purchase-label-btn').addEventListener('click', openPaymentModal);
    
    // Payment modal
    document.querySelector('#payment-modal .close-btn').addEventListener('click', closePaymentModal);
    document.getElementById('payment-form').addEventListener('submit', handlePayment);
    
    // Notifications
    document.getElementById('notifications-btn').addEventListener('click', toggleNotifications);
    document.getElementById('mark-all-read').addEventListener('click', markAllNotificationsRead);
    
    // User menu
    document.getElementById('user-menu-btn').addEventListener('click', toggleUserMenu);
    
    // Logout
    document.getElementById('logout-btn').addEventListener('click', handleLogout);
    
    // Close modals on outside click
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
}

function setupStripe() {
    // Stripe will be initialized when needed
}

async function loadObjects() {
    const token = localStorage.getItem('session_token');
    
    try {
        const response = await fetch(`${API_BASE}/objects`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderObjects(data.data);
            updateStats(data.data);
            updateMap(data.data);
        }
    } catch (error) {
        console.error('Failed to load objects:', error);
    }
}

function renderObjects(objects) {
    const container = document.getElementById('objects-list');
    
    if (objects.length === 0) {
        container.innerHTML = '<div class="empty">Nessun oggetto. Aggiungi il tuo primo oggetto!</div>';
        return;
    }
    
    container.innerHTML = objects.map(obj => `
        <div class="object-card" data-id="${obj.id}">
            <div class="object-card-header">
                <div>
                    <h3>${escapeHtml(obj.name)}</h3>
                    <span class="category">${escapeHtml(obj.category)}</span>
                </div>
            </div>
            <span class="short-code">${obj.short_code}</span>
            <div class="status ${obj.label_purchased ? 'purchased' : 'not-purchased'}">
                ${obj.label_purchased ? '✓ Etichetta acquistata' : '⏳ Etichetta non acquistata'}
            </div>
            <div class="object-card-actions">
                ${!obj.label_purchased ? 
                    `<button class="btn-primary btn-small" onclick="purchaseLabel(${obj.id}, '${escapeHtml(obj.name)}')">Acquista</button>` :
                    `<button class="btn-secondary btn-small" onclick="downloadQr(${obj.id})">Scarica</button>`
                }
                <button class="btn-secondary btn-small" onclick="viewMap(${obj.id})">Mappa</button>
            </div>
        </div>
    `).join('');
}

function updateStats(objects) {
    document.getElementById('total-objects').textContent = objects.length;
    document.getElementById('tracked-objects').textContent = objects.filter(o => o.scan_count > 0).length;
}

function initMap() {
    map = L.map('objects-map').setView([41.9028, 12.4964], 5); // Center on Italy
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
}

function updateMap(objects) {
    // Clear existing markers
    markers.forEach(marker => map.removeLayer(marker));
    markers = [];
    
    const locations = objects.filter(obj => obj.last_scanned_at && obj.latitude && obj.longitude);
    
    if (locations.length === 0) {
        return;
    }
    
    const bounds = L.latLngBounds();
    
    locations.forEach(obj => {
        const marker = L.marker([obj.latitude, obj.longitude])
            .bindPopup(`<b>${escapeHtml(obj.name)}</b><br>Scannerizzato: ${formatDate(obj.last_scanned_at)}`)
            .addTo(map);
        
        markers.push(marker);
        bounds.extend([obj.latitude, obj.longitude]);
    });
    
    map.fitBounds(bounds, { padding: [50, 50] });
}

async function handleAddObject(e) {
    e.preventDefault();
    
    const token = localStorage.getItem('session_token');
    const name = document.getElementById('object-name').value;
    const category = document.getElementById('object-category').value;
    const description = document.getElementById('object-description').value;
    
    try {
        const response = await fetch(`${API_BASE}/objects`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ name, category, description })
        });
        
        const data = await response.json();
        
        if (data.success) {
            closeAddModal();
            showQrModal(data.data);
            loadObjects(); // Refresh list
        } else {
            alert(data.error || 'Errore durante la creazione');
        }
    } catch (error) {
        console.error('Failed to add object:', error);
        alert('Errore di connessione');
    }
}

function showQrModal(objectData) {
    currentObjectId = objectData.id;
    document.getElementById('qr-image').src = objectData.qr_code_url;
    document.getElementById('qr-short-code').textContent = objectData.short_code;
    
    const purchaseBtn = document.getElementById('purchase-label-btn');
    const downloadBtn = document.getElementById('download-qr-btn');
    
    if (objectData.label_purchased) {
        purchaseBtn.style.display = 'none';
        downloadBtn.disabled = false;
    } else {
        purchaseBtn.style.display = 'block';
        downloadBtn.disabled = true;
    }
    
    document.getElementById('qr-modal').style.display = 'flex';
}

function closeAddModal() {
    document.getElementById('add-object-modal').style.display = 'none';
    document.getElementById('add-object-form').reset();
}

function closeQrModal() {
    document.getElementById('qr-modal').style.display = 'none';
    currentObjectId = null;
}

async function purchaseLabel(objectId, objectName) {
    currentObjectId = objectId;
    document.getElementById('payment-object-name').textContent = objectName;
    openPaymentModal();
}

function openPaymentModal() {
    if (!currentObjectId) return;
    
    closeQrModal();
    document.getElementById('payment-modal').style.display = 'flex';
    
    // Initialize Stripe Elements
    initStripeElements();
}

function closePaymentModal() {
    document.getElementById('payment-modal').style.display = 'none';
}

async function initStripeElements() {
    const token = localStorage.getItem('session_token');
    
    try {
        // Get payment intent
        const response = await fetch(`${API_BASE}/objects/${currentObjectId}/payment-intent`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (!data.success) {
            alert(data.error || 'Errore durante la creazione del pagamento');
            return;
        }
        
        // Initialize Stripe
        stripe = Stripe(data.data.publishable_key);
        const elements = stripe.elements();
        
        cardElement = elements.create('card', {
            style: {
                base: {
                    fontSize: '16px',
                    color: '#32325d',
                }
            }
        });
        
        cardElement.mount('#card-element');
        
        // Store client secret
        document.getElementById('payment-form').dataset.clientSecret = data.data.client_secret;
        
    } catch (error) {
        console.error('Stripe initialization failed:', error);
    }
}

async function handlePayment(e) {
    e.preventDefault();
    
    const clientSecret = e.target.dataset.clientSecret;
    const errorDiv = document.getElementById('card-errors');
    
    errorDiv.textContent = '';
    
    try {
        const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
            payment_method: {
                card: cardElement,
            }
        });
        
        if (error) {
            errorDiv.textContent = error.message;
        } else if (paymentIntent.status === 'succeeded') {
            closePaymentModal();
            alert('Pagamento completato! L\'etichetta è ora disponibile per il download.');
            loadObjects();
        }
    } catch (error) {
        console.error('Payment failed:', error);
        errorDiv.textContent = 'Errore durante il pagamento';
    }
}

async function downloadQr(objectId) {
    window.open(`${API_BASE}/objects/${objectId}/download`, '_blank');
}

function viewMap(objectId) {
    // Focus map on specific object
    window.location.href = `/dashboard/objects/${objectId}`;
}

// Notifications
async function loadNotifications() {
    const token = localStorage.getItem('session_token');
    
    try {
        const response = await fetch(`${API_BASE}/notifications/unread-count`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateNotificationBadge(data.data.count);
            document.getElementById('notifications-count').textContent = data.data.count;
        }
    } catch (error) {
        console.error('Failed to load notifications:', error);
    }
}

async function toggleNotifications() {
    const dropdown = document.getElementById('notifications-dropdown');
    
    if (dropdown.style.display === 'none') {
        dropdown.style.display = 'block';
        await loadNotificationList();
    } else {
        dropdown.style.display = 'none';
    }
}

async function loadNotificationList() {
    const token = localStorage.getItem('session_token');
    
    try {
        const response = await fetch(`${API_BASE}/notifications`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            renderNotifications(data.data);
        }
    } catch (error) {
        console.error('Failed to load notifications:', error);
    }
}

function renderNotifications(notifications) {
    const container = document.getElementById('notifications-list');
    
    if (notifications.length === 0) {
        container.innerHTML = '<p class="empty">Nessuna notifica</p>';
        return;
    }
    
    container.innerHTML = notifications.map(notif => `
        <div class="notification-item ${notif.is_read ? '' : 'unread'}" data-id="${notif.id}">
            <h5>${escapeHtml(notif.title)}</h5>
            <p>${escapeHtml(notif.message)}</p>
        </div>
    `).join('');
}

function updateNotificationBadge(count) {
    const badge = document.getElementById('notification-count');
    
    if (count > 0) {
        badge.textContent = count > 99 ? '99+' : count;
        badge.style.display = 'block';
    } else {
        badge.style.display = 'none';
    }
}

async function markAllNotificationsRead() {
    const token = localStorage.getItem('session_token');
    
    try {
        const response = await fetch(`${API_BASE}/notifications/read-all`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateNotificationBadge(0);
            loadNotificationList();
        }
    } catch (error) {
        console.error('Failed to mark notifications as read:', error);
    }
}

// User Menu
function toggleUserMenu() {
    const dropdown = document.getElementById('user-dropdown');
    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
}

async function handleLogout(e) {
    e.preventDefault();
    
    const token = localStorage.getItem('session_token');
    
    try {
        await fetch(`${API_BASE}/auth/logout`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
    } catch (error) {
        console.error('Logout failed:', error);
    }
    
    localStorage.removeItem('session_token');
    localStorage.removeItem('user');
    window.location.href = '/';
}

// Utilities
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    if (!dateString) return 'Mai';
    const date = new Date(dateString);
    return date.toLocaleString('it-IT');
}
