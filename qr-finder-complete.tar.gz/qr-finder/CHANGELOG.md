# Changelog

Tutte le modifiche importanti a questo progetto saranno documentate in questo file.

## [1.0.0] - 2024-02-19

### Aggiunto
- Sistema di autenticazione completo (registrazione, login, logout)
- Verifica email per nuovi account
- Reset password via email
- Generazione QR code univoci per ogni oggetto
- Short URL per il tracciamento (formato: /r/XXXXXXXX)
- Integrazione Stripe per pagamenti
- Geolocalizzazione quando il QR viene scannerizzato
- Notifiche email quando gli oggetti vengono trovati
- Sistema di notifiche in-app
- Dashboard utente con gestione oggetti
- Mappa interattiva con Leaflet + OpenStreetMap
- Visualizzazione cronologia posizioni
- Download QR code (dopo acquisto etichetta)
- Pagina pubblica per chi trova gli oggetti
- Form di contatto per i trovanti
- API RESTful completa
- Supporto Docker
- Script di installazione automatica

### Sicurezza
- Password hashate con bcrypt
- JWT per autenticazione
- Prepared statements per prevenire SQL injection
- Output escaping per prevenire XSS
- CSRF protection
- Session management sicuro

## Note

- Versione iniziale del progetto QR Finder
- Stack tecnologico: PHP 8.1+, MariaDB, Composer
- Frontend: HTML5, CSS3, JavaScript vanilla
- Mappe: Leaflet.js con OpenStreetMap
- Pagamenti: Stripe
- Email: PHPMailer con SMTP
