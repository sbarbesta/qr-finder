-- QR Finder Admin Panel - Additional Tables

-- Countries table
CREATE TABLE countries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code CHAR(2) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    name_it VARCHAR(100),
    phone_code VARCHAR(5),
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert common countries
INSERT INTO countries (code, name, name_it, phone_code) VALUES
('IT', 'Italy', 'Italia', '+39'),
('US', 'United States', 'Stati Uniti', '+1'),
('GB', 'United Kingdom', 'Regno Unito', '+44'),
('FR', 'France', 'Francia', '+33'),
('DE', 'Germany', 'Germania', '+49'),
('ES', 'Spain', 'Spagna', '+34'),
('CH', 'Switzerland', 'Svizzera', '+41'),
('AT', 'Austria', 'Austria', '+43'),
('BE', 'Belgium', 'Belgio', '+32'),
('NL', 'Netherlands', 'Paesi Bassi', '+31'),
('PT', 'Portugal', 'Portogallo', '+351'),
('IE', 'Ireland', 'Irlanda', '+353'),
('DK', 'Denmark', 'Danimarca', '+45'),
('SE', 'Sweden', 'Svezia', '+46'),
('NO', 'Norway', 'Norvegia', '+47'),
('FI', 'Finland', 'Finlandia', '+358'),
('PL', 'Poland', 'Polonia', '+48'),
('CZ', 'Czech Republic', 'Repubblica Ceca', '+420'),
('HU', 'Hungary', 'Ungheria', '+36'),
('RO', 'Romania', 'Romania', '+40'),
('BG', 'Bulgaria', 'Bulgaria', '+359'),
('HR', 'Croatia', 'Croazia', '+385'),
('SI', 'Slovenia', 'Slovenia', '+386'),
('SK', 'Slovakia', 'Slovacchia', '+421'),
('GR', 'Greece', 'Grecia', '+30'),
('RU', 'Russia', 'Russia', '+7'),
('UA', 'Ukraine', 'Ucraina', '+380'),
('TR', 'Turkey', 'Turchia', '+90'),
('CA', 'Canada', 'Canada', '+1'),
('AU', 'Australia', 'Australia', '+61'),
('JP', 'Japan', 'Giappone', '+81'),
('CN', 'China', 'Cina', '+86'),
('IN', 'India', 'India', '+91'),
('BR', 'Brazil', 'Brasile', '+55'),
('MX', 'Mexico', 'Messico', '+52'),
('AR', 'Argentina', 'Argentina', '+54'),
('ZA', 'South Africa', 'Sudafrica', '+27'),
('EG', 'Egypt', 'Egitto', '+20'),
('IL', 'Israel', 'Israele', '+972'),
('AE', 'United Arab Emirates', 'Emirati Arabi', '+971'),
('SA', 'Saudi Arabia', 'Arabia Saudita', '+966');

-- Update users table with additional fields
ALTER TABLE users 
ADD COLUMN nickname VARCHAR(50) NULL AFTER last_name,
ADD COLUMN city VARCHAR(100) NULL AFTER phone,
ADD COLUMN province VARCHAR(100) NULL AFTER city,
ADD COLUMN country_code CHAR(2) NULL AFTER province,
ADD COLUMN postal_code VARCHAR(20) NULL AFTER country_code,
ADD COLUMN address TEXT NULL AFTER postal_code,
ADD COLUMN is_admin BOOLEAN DEFAULT FALSE AFTER is_active,
ADD COLUMN avatar VARCHAR(500) NULL AFTER is_admin,
ADD COLUMN language VARCHAR(5) DEFAULT 'it' AFTER avatar,
ADD COLUMN newsletter_subscribed BOOLEAN DEFAULT TRUE AFTER language,
ADD COLUMN last_login_at DATETIME NULL AFTER updated_at,
ADD COLUMN login_count INT DEFAULT 0 AFTER last_login_at,
ADD INDEX idx_country_code (country_code),
ADD INDEX idx_is_admin (is_admin),
ADD INDEX idx_nickname (nickname),
ADD INDEX idx_city (city),
ADD INDEX idx_newsletter (newsletter_subscribed),
ADD FOREIGN KEY (country_code) REFERENCES countries(code) ON DELETE SET NULL;

-- Admin profiles table
CREATE TABLE admin_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(255),
    verification_code VARCHAR(10),
    verification_code_expires DATETIME,
    login_notifications BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Site settings table
CREATE TABLE site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_group VARCHAR(50) DEFAULT 'general',
    is_json BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_group (setting_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO site_settings (setting_key, setting_value, setting_group) VALUES
-- SEO Settings
('seo_title_it', 'QR Finder - Trova i tuoi oggetti smarriti', 'seo'),
('seo_title_en', 'QR Finder - Find your lost items', 'seo'),
('seo_description_it', 'QR Finder ti aiuta a ritrovare chiavi, smartphone, biciclette e altri oggetti personali. Genera QR code univoci e ricevi notifiche quando vengono trovati.', 'seo'),
('seo_description_en', 'QR Finder helps you find keys, smartphones, bicycles and other personal items. Generate unique QR codes and get notified when they are found.', 'seo'),
('seo_keywords_it', 'qr code, trova oggetti, chiavi smarrite, tracciamento, geolocalizzazione', 'seo'),
('seo_keywords_en', 'qr code, find items, lost keys, tracking, geolocation', 'seo'),

-- Branding Settings
('site_logo', '', 'branding'),
('site_favicon', '', 'branding'),
('site_header_image', '', 'branding'),
('primary_color', '#2563eb', 'branding'),
('secondary_color', '#10b981', 'branding'),
('background_color', '#ffffff', 'branding'),
('text_color', '#1f2937', 'branding'),
('link_color', '#2563eb', 'branding'),
('footer_background', '#111827', 'branding'),
('footer_text_color', '#ffffff', 'branding'),

-- Email Settings
('smtp_host', 'smtp.gmail.com', 'email'),
('smtp_port', '587', 'email'),
('smtp_username', '', 'email'),
('smtp_password', '', 'email'),
('smtp_encryption', 'tls', 'email'),
('smtp_from_email', 'noreply@qr-finder.com', 'email'),
('smtp_from_name', 'QR Finder', 'email'),
('smtp_auth', 'true', 'email');

-- Static pages table
CREATE TABLE pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(100) NOT NULL,
    title_it VARCHAR(255) NOT NULL,
    title_en VARCHAR(255),
    content_it LONGTEXT,
    content_en LONGTEXT,
    meta_description_it TEXT,
    meta_description_en TEXT,
    is_published BOOLEAN DEFAULT TRUE,
    show_in_footer BOOLEAN DEFAULT TRUE,
    footer_order INT DEFAULT 0,
    created_by INT,
    updated_by INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_slug (slug),
    INDEX idx_published (is_published),
    INDEX idx_footer (show_in_footer, footer_order),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default pages
INSERT INTO pages (slug, title_it, title_en, content_it, content_en, show_in_footer, footer_order) VALUES
('chi-siamo', 'Chi Siamo', 'About Us', 
'<h2>Chi Siamo</h2><p>QR Finder è una piattaforma innovativa dedicata al recupero di oggetti smarriti.</p>', 
'<h2>About Us</h2><p>QR Finder is an innovative platform dedicated to recovering lost items.</p>', 
TRUE, 1),

('missione', 'La Nostra Missione', 'Our Mission', 
'<h2>La Nostra Missione</h2><p>Aiutare le persone a ritrovare i loro oggetti personali in modo semplice e veloce.</p>', 
'<h2>Our Mission</h2><p>Helping people find their personal belongings in a simple and fast way.</p>', 
TRUE, 2),

('termini-condizioni', 'Termini & Condizioni', 'Terms & Conditions', 
'<h2>Termini & Condizioni</h2><p>Utilizzando QR Finder accetti i seguenti termini e condizioni...</p>', 
'<h2>Terms & Conditions</h2><p>By using QR Finder you agree to the following terms and conditions...</p>', 
TRUE, 3),

('privacy-policy', 'Privacy Policy', 'Privacy Policy', 
'<h2>Privacy Policy</h2><p>La tua privacy è importante per noi. Questa policy spiega come raccogliamo e utilizziamo i tuoi dati...</p>', 
'<h2>Privacy Policy</h2><p>Your privacy is important to us. This policy explains how we collect and use your data...</p>', 
TRUE, 4),

('cookie-policy', 'Cookie Policy', 'Cookie Policy', 
'<h2>Cookie Policy</h2><p>Questo sito utilizza cookie per migliorare l\'esperienza utente...</p>', 
'<h2>Cookie Policy</h2><p>This website uses cookies to improve user experience...</p>', 
TRUE, 5),

('contatti', 'Contatti', 'Contact', 
'<h2>Contattaci</h2><p>Hai domande o suggerimenti? Contattaci usando il modulo qui sotto.</p>', 
'<h2>Contact Us</h2><p>Have questions or suggestions? Contact us using the form below.</p>', 
TRUE, 6);

-- Email templates table
CREATE TABLE email_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_key VARCHAR(100) NOT NULL UNIQUE,
    subject_it VARCHAR(255) NOT NULL,
    subject_en VARCHAR(255),
    body_it LONGTEXT,
    body_en LONGTEXT,
    variables TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default email templates
INSERT INTO email_templates (template_key, subject_it, subject_en, body_it, body_en, variables) VALUES
('welcome', 'Benvenuto su QR Finder!', 'Welcome to QR Finder!', 
'<h2>Ciao {{first_name}},</h2><p>Benvenuto su QR Finder!</p>', 
'<h2>Hi {{first_name}},</h2><p>Welcome to QR Finder!</p>', 
'first_name,email'),

('newsletter', 'Newsletter QR Finder', 'QR Finder Newsletter', 
'<h2>Ciao {{first_name}},</h2><p>Ecco le ultime novità da QR Finder...</p>', 
'<h2>Hi {{first_name}},</h2><p>Here are the latest news from QR Finder...</p>', 
'first_name,content'),

('admin_verification', 'Codice di verifica Admin', 'Admin Verification Code', 
'<h2>Codice di Verifica</h2><p>Il tuo codice di verifica è: <strong>{{code}}</strong></p><p>Questo codice scade tra 10 minuti.</p>', 
'<h2>Verification Code</h2><p>Your verification code is: <strong>{{code}}</strong></p><p>This code expires in 10 minutes.</p>', 
'code');

-- Newsletter subscribers table
CREATE TABLE newsletter_subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    language VARCHAR(5) DEFAULT 'it',
    is_active BOOLEAN DEFAULT TRUE,
    subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    unsubscribed_at DATETIME,
    unsubscribe_token VARCHAR(255),
    INDEX idx_active (is_active),
    INDEX idx_language (language)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Newsletter campaigns table
CREATE TABLE newsletter_campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_it VARCHAR(255) NOT NULL,
    subject_en VARCHAR(255),
    content_it LONGTEXT,
    content_en LONGTEXT,
    sent_by INT,
    sent_at DATETIME,
    recipients_count INT DEFAULT 0,
    opened_count INT DEFAULT 0,
    clicked_count INT DEFAULT 0,
    status ENUM('draft', 'sending', 'sent', 'failed') DEFAULT 'draft',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sent_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_sent_at (sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin activity log
CREATE TABLE admin_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact messages table (for contact form)
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    replied_at DATETIME,
    replied_by INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (replied_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_is_read (is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create admin user (password: admin123)
INSERT INTO users (email, password_hash, first_name, last_name, nickname, email_verified, is_active, is_admin, language) 
VALUES (
    'admin@qr-finder.com', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'Admin', 
    'User',
    'admin',
    TRUE, 
    TRUE,
    TRUE,
    'it'
);

-- Create admin profile
INSERT INTO admin_profiles (user_id) VALUES (LAST_INSERT_ID());
