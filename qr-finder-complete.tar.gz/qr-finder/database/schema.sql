-- QR Finder Database Schema
-- MariaDB/MySQL

CREATE DATABASE IF NOT EXISTS qrfinder 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE qrfinder;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(255),
    reset_token VARCHAR(255),
    reset_token_expires DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_email (email),
    INDEX idx_verification_token (verification_token),
    INDEX idx_reset_token (reset_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Objects/Items table
CREATE TABLE objects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category ENUM('keys', 'smartphone', 'bicycle', 'wallet', 'laptop', 'tablet', 'bag', 'pet', 'other') DEFAULT 'other',
    short_code VARCHAR(20) NOT NULL UNIQUE,
    qr_code_path VARCHAR(500),
    label_purchased BOOLEAN DEFAULT FALSE,
    label_purchase_date DATETIME,
    stripe_payment_intent VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_short_code (short_code),
    INDEX idx_user_id (user_id),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- QR Code scans table (tracking)
CREATE TABLE qr_scans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    object_id INT NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    accuracy FLOAT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    scanned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    notification_sent BOOLEAN DEFAULT FALSE,
    notification_sent_at DATETIME,
    FOREIGN KEY (object_id) REFERENCES objects(id) ON DELETE CASCADE,
    INDEX idx_object_id (object_id),
    INDEX idx_scanned_at (scanned_at),
    INDEX idx_location (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications table
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    object_id INT,
    scan_id INT,
    type ENUM('email', 'push', 'sms') DEFAULT 'email',
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (object_id) REFERENCES objects(id) ON DELETE SET NULL,
    FOREIGN KEY (scan_id) REFERENCES qr_scans(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_sent_at (sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payments table
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    object_id INT,
    stripe_payment_intent VARCHAR(255) NOT NULL,
    stripe_customer_id VARCHAR(255),
    amount_cents INT NOT NULL,
    currency VARCHAR(3) DEFAULT 'eur',
    status ENUM('pending', 'succeeded', 'failed', 'refunded') DEFAULT 'pending',
    paid_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (object_id) REFERENCES objects(id) ON DELETE SET NULL,
    INDEX idx_stripe_payment_intent (stripe_payment_intent),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sessions table for user authentication
CREATE TABLE user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(255) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    user_agent TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session_token (session_token),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact messages table (for found items)
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    object_id INT NOT NULL,
    scan_id INT,
    finder_name VARCHAR(255),
    finder_email VARCHAR(255),
    finder_phone VARCHAR(20),
    message TEXT,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_read BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (object_id) REFERENCES objects(id) ON DELETE CASCADE,
    FOREIGN KEY (scan_id) REFERENCES qr_scans(id) ON DELETE SET NULL,
    INDEX idx_object_id (object_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create views for common queries
CREATE VIEW object_locations AS
SELECT 
    o.id AS object_id,
    o.name AS object_name,
    o.short_code,
    o.user_id,
    u.email AS user_email,
    u.first_name,
    u.last_name,
    qs.latitude,
    qs.longitude,
    qs.accuracy,
    qs.scanned_at,
    qs.notification_sent
FROM objects o
JOIN users u ON o.user_id = u.id
LEFT JOIN qr_scans qs ON o.id = qs.object_id
WHERE qs.id = (
    SELECT id FROM qr_scans 
    WHERE object_id = o.id 
    ORDER BY scanned_at DESC 
    LIMIT 1
);

-- Insert default data
INSERT INTO users (email, password_hash, first_name, last_name, email_verified, is_active) 
VALUES (
    'admin@qr-finder.com', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: password
    'Admin', 
    'User', 
    TRUE, 
    TRUE
);
